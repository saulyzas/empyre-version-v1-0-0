<?php
/**
 * admin_setup.php — one-time bootstrap to claim the first admin account.
 *
 * SECURITY MODEL:
 *   - If at least one admin already exists, this page refuses to do anything
 *     and shows a message pointing the user to the admin panel.
 *   - If no admins exist yet, the page shows a form asking for:
 *       * Username of an EXISTING player (must already be registered)
 *       * That player's password (re-verified for safety)
 *     On submit, the player is promoted to admin.
 *   - After successful promotion, the user is redirected to /admin.php
 *
 * Once the first admin exists, they can promote other players from
 * admin_players.php. This file can be deleted after first use — but
 * it's safe to keep (it just refuses to do anything once an admin exists).
 */
require_once __DIR__ . '/app/lib/helpers.php';
require_once __DIR__ . '/app/lib/admin_helpers.php';
init_session();

// If an admin already exists, refuse to run.
if (admin_count() > 0) {
    $already_set_up = true;
} else {
    $already_set_up = false;
}

$error   = '';
$success = '';

if (!$already_set_up && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please fill in both fields.';
    } else {
        $player = db()->fetch("SELECT * FROM players WHERE username = ?", [$username]);
        if (!$player || !password_verify($password, $player['password_hash'])) {
            $error = 'Invalid username or password.';
        } elseif ((int)$player['is_banned'] === 1) {
            $error = 'This account is banned and cannot be promoted.';
        } else {
            // Promote to admin
            db()->query("UPDATE players SET is_admin = 1 WHERE id = ?", [$player['id']]);
            // Log in as this player (in case they weren't already)
            $_SESSION['player_id'] = $player['id'];

            // Audit log
            try {
                db()->insert('reports', [
                    'player_id' => $player['id'],
                    'title'     => '[ADMIN] Account promoted to admin via admin_setup.php',
                    'body'      => "User {$player['username']} (ID {$player['id']}) was promoted to admin via the one-time setup script.",
                    'category'  => 'admin',
                ]);
            } catch (Throwable $e) {}

            $success = "Player \"{$player['username']}\" has been promoted to admin. Redirecting to admin panel...";
            header('Refresh: 2; URL=' . url('/admin.php'));
        }
    }
}

$page_title = 'Admin Setup';
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:560px;margin:0 auto;">
    <div class="card-header">🛠️ Admin Setup</div>

    <?php if ($already_set_up): ?>
        <div class="alert alert-info">
            ✅ An admin account already exists on this server.
            The one-time setup script has done its job and is now disabled.
        </div>
        <p style="font-size:13px;color:var(--c-text-soft);">
            If you're an admin, log in and visit the admin panel directly.
            You can safely delete this file (<code>admin_setup.php</code>) — it's
            no longer needed.
        </p>
        <p style="text-align:center;margin-top:16px;">
            <?php if (is_admin()): ?>
            <a href="<?= url('/admin.php') ?>" class="btn btn-gold">🔧 Open Admin Panel</a>
            <?php else: ?>
            <a href="<?= url('/login.php') ?>" class="btn btn-blue">Login</a>
            <?php endif; ?>
        </p>

    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= e($success) ?></div>

    <?php else: ?>
        <div class="alert alert-info" style="margin-bottom:16px;">
            👋 <strong>First-time setup.</strong> No admin accounts exist yet.
            Use this form to promote an <strong>existing player</strong> to admin.
            The player must already be registered (visit
            <a href="<?= url('/register.php') ?>">Register</a> first if needed).
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Username (existing player)</label>
                <input type="text" name="username" class="form-control" required
                       value="<?= e($_POST['username'] ?? '') ?>"
                       placeholder="e.g. your in-game username">
            </div>
            <div class="form-group">
                <label>Password (verify identity)</label>
                <input type="password" name="password" class="form-control" required
                       placeholder="Re-enter the player's password">
            </div>
            <button type="submit" class="btn btn-gold btn-lg" style="width:100%;">
                🔧 Promote to Admin
            </button>
        </form>

        <div style="margin-top:16px;padding:10px;background:#fce4e4;border-left:4px solid #8e2a26;font-size:12px;border-radius:4px;">
            <strong>⚠️ Security note:</strong> Once promoted, this player will have
            full administrative access to the server — including the ability to
            delete other players, give themselves gold, see private data, etc.
            Only promote an account you trust.
        </div>

        <p style="font-size:11px;color:var(--c-text-soft);margin-top:12px;">
            💡 After the first admin is set up, this page becomes read-only and
            further admin promotions must be done from the admin panel.
            You can delete this file at any time after setup.
        </p>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
