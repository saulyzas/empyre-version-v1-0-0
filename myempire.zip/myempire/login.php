<?php
require_once __DIR__ . '/app/lib/helpers.php';
require_once __DIR__ . '/app/lib/admin_helpers.php';
init_session();

if (current_player_id()) {
    redirect('/village.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $player = db()->fetch("SELECT * FROM players WHERE username = ?", [$username]);
    if (!$player || !password_verify($password, $player['password_hash'])) {
        $error = 'Invalid username or password.';
    } elseif ((int)$player['is_banned'] === 1) {
        // Banned players cannot log in.
        $reason = $player['banned_reason'] ? ' Reason: ' . $player['banned_reason'] : '';
        $error = '🚫 This account has been banned.' . $reason;
    } else {
        $_SESSION['player_id'] = $player['id'];
        db()->query("UPDATE players SET last_login = ? WHERE id = ?", [date('Y-m-d H:i:s'), $player['id']]);
        // Redirect admins to the admin panel, regular users to their village.
        if ((int)$player['is_admin'] === 1) {
            redirect('/admin.php');
        } else {
            redirect('/village.php');
        }
    }
}

$page_title = 'Login';
require __DIR__ . '/app/views/header.php';
?>
<div class="auth-form card">
    <h1>Login</h1>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required
                   value="<?= e($_POST['username'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-green btn-lg" style="width: 100%;">Sign In</button>
    </form>

    <p style="text-align:center; margin-top:12px;">
        New player? <a href="<?= url('/register.php') ?>">Register</a>
    </p>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
