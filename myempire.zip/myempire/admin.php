<?php
/**
 * admin.php — Admin dashboard.
 *
 * Shows:
 *   - Quick server stats (registered, online, banned, admins)
 *   - Quick action links to other admin pages
 *   - Recent admin log entries (category='admin' reports)
 *   - Database table sizes overview
 *   - Quick broadcast form
 */
require_once __DIR__ . '/app/lib/helpers.php';
require_once __DIR__ . '/app/lib/admin_helpers.php';
init_session();
require_admin();

// Fetch server stats (already exists in helpers.php)
$stats = get_server_stats();

// Admin-specific stats
$admin_count   = (int)db()->fetchColumn("SELECT COUNT(*) FROM players WHERE is_admin = 1");
$banned_count  = (int)db()->fetchColumn("SELECT COUNT(*) FROM players WHERE is_banned = 1");

// Recent admin log entries
$admin_logs = db()->fetchAll(
    "SELECT * FROM reports WHERE category = 'admin'
     ORDER BY created_at DESC, id DESC LIMIT 15"
);

// Table sizes (row counts) for the database overview
$table_sizes = [];
$tables_to_count = [
    'players', 'villages', 'resources', 'resource_fields', 'buildings',
    'build_queue', 'training_queue', 'research_queue', 'unit_research',
    'troops', 'movements', 'resource_movements', 'trade_offers',
    'reports', 'heroes', 'map_cells',
];
foreach ($tables_to_count as $tbl) {
    try {
        $cnt = (int)db()->fetchColumn("SELECT COUNT(*) FROM {$tbl}");
        $table_sizes[$tbl] = $cnt;
    } catch (Throwable $e) {
        // Table might not exist
        $table_sizes[$tbl] = null;
    }
}

// Handle broadcast POST
$broadcast_msg = '';
$broadcast_err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'broadcast') {
    $subject = $_POST['subject'] ?? '';
    $body    = $_POST['body'] ?? '';
    $r = admin_broadcast($subject, $body);
    if ($r['ok']) {
        $broadcast_msg = "Broadcast sent to {$r['sent']} player(s).";
    } else {
        $broadcast_err = $r['error'];
    }
}

$page_title = 'Admin';
require __DIR__ . '/app/views/header.php';
?>

<style>
.admin-nav {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 10px;
    margin-bottom: 20px;
}
.admin-nav a {
    display: block;
    padding: 14px 10px;
    background: linear-gradient(180deg, #fff8d6 0%, #f4ead5 100%);
    border: 2px solid var(--c-outline);
    border-radius: 8px;
    text-align: center;
    text-decoration: none;
    color: var(--c-wood-dk);
    font-weight: bold;
    font-size: 13px;
    box-shadow: 0 2px 0 var(--c-outline);
    transition: transform 0.15s;
}
.admin-nav a:hover { transform: translateY(-2px); text-decoration: none; }
.admin-nav a .icon { font-size: 24px; display: block; margin-bottom: 4px; }

.stat-box-large {
    background: linear-gradient(180deg, #fff8d6 0%, #f4ead5 100%);
    border: 2px solid var(--c-outline);
    border-radius: 8px;
    padding: 16px 12px;
    text-align: center;
    box-shadow: 0 2px 0 var(--c-outline);
}
.stat-box-large .num {
    font-family: Georgia, serif;
    font-size: 32px;
    font-weight: bold;
    color: var(--c-wood-dk);
    line-height: 1;
}
.stat-box-large .lbl {
    font-size: 11px;
    color: var(--c-text-soft);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-top: 4px;
}
.stat-box-large.danger .num { color: #8e2a26; }
.stat-box-large.success .num { color: #4a7a3a; }
.stat-box-large.gold .num { color: var(--c-gold-dk); }
</style>

<div class="card">
    <div class="card-header" style="background:linear-gradient(135deg,#8e2a26,#5a1a18);color:#fff;">
        🔧 Admin Panel — <?= e(GAME_NAME) ?>
    </div>

    <p style="font-size:12px;color:var(--c-text-soft);margin-bottom:16px;">
        Logged in as <strong><?= e(current_player()['username']) ?></strong> ·
        Server time: <?= date('Y-m-d H:i:s') ?> ·
        Server speed: <?= (int)GAME_SERVER_SPEED ?>x
    </p>

    <!-- ============================================================
         Quick navigation
         ============================================================ -->
    <h3 style="color:var(--c-wood-dk);font-size:14px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">
        📂 Management
    </h3>
    <div class="admin-nav">
        <a href="<?= url('/admin_players.php') ?>">
            <span class="icon">👥</span>
            Players
        </a>
        <a href="<?= url('/admin_villages.php') ?>">
            <span class="icon">🏘️</span>
            Villages
        </a>
        <a href="<?= url('/admin_maintenance.php') ?>">
            <span class="icon">🛠️</span>
            Maintenance
        </a>
        <a href="<?= url('/stats.php') ?>">
            <span class="icon">🏆</span>
            Rankings
        </a>
        <a href="<?= url('/map.php') ?>">
            <span class="icon">🗺️</span>
            World Map
        </a>
        <a href="<?= url('/migrate.php') ?>">
            <span class="icon">📦</span>
            Run Migrations
        </a>
    </div>

    <!-- ============================================================
         Server overview stats
         ============================================================ -->
    <h3 style="color:var(--c-wood-dk);font-size:14px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;margin-top:20px;">
        📊 Server Overview
    </h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;">
        <div class="stat-box-large">
            <div class="num"><?= number_format($stats['total_players']) ?></div>
            <div class="lbl">Total Players</div>
        </div>
        <div class="stat-box-large success">
            <div class="num"><?= number_format($stats['online_now']) ?></div>
            <div class="lbl">Online Now</div>
        </div>
        <div class="stat-box-large">
            <div class="num"><?= number_format($stats['active_today']) ?></div>
            <div class="lbl">Active Today</div>
        </div>
        <div class="stat-box-large gold">
            <div class="num"><?= $admin_count ?></div>
            <div class="lbl">Admins</div>
        </div>
        <div class="stat-box-large danger">
            <div class="num"><?= $banned_count ?></div>
            <div class="lbl">Banned</div>
        </div>
        <div class="stat-box-large">
            <div class="num"><?= number_format($stats['total_villages']) ?></div>
            <div class="lbl">Villages</div>
        </div>
        <div class="stat-box-large">
            <div class="num"><?= number_format($stats['total_troops']) ?></div>
            <div class="lbl">Troops</div>
        </div>
    </div>

    <!-- ============================================================
         Tribe breakdown
         ============================================================ -->
    <div style="margin-top:16px;padding:10px;background:#fff;border:1px solid var(--c-outline);border-radius:6px;">
        <strong style="font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">Tribe Distribution</strong>
        <div style="display:flex;gap:14px;font-size:12px;margin-top:6px;flex-wrap:wrap;">
            <span><img src="<?= img_url('tribes/roman.png') ?>" width="16" height="16" alt="" style="vertical-align:middle;"> Romans: <?= $stats['tribe_counts']['roman'] ?></span>
            <span><img src="<?= img_url('tribes/gaul.png') ?>" width="16" height="16" alt="" style="vertical-align:middle;"> Gauls: <?= $stats['tribe_counts']['gaul'] ?></span>
            <span><img src="<?= img_url('tribes/teuton.png') ?>" width="16" height="16" alt="" style="vertical-align:middle;"> Teutons: <?= $stats['tribe_counts']['teuton'] ?></span>
        </div>
    </div>

    <!-- ============================================================
         Quick broadcast form
         ============================================================ -->
    <h3 style="color:var(--c-wood-dk);font-size:14px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;margin-top:20px;">
        📢 Broadcast System Message
    </h3>
    <?php if ($broadcast_msg): ?>
    <div class="alert alert-success"><?= e($broadcast_msg) ?></div>
    <?php endif; ?>
    <?php if ($broadcast_err): ?>
    <div class="alert alert-error"><?= e($broadcast_err) ?></div>
    <?php endif; ?>
    <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:12px;border-radius:6px;">
        <input type="hidden" name="action" value="broadcast">
        <div class="form-group">
            <label style="font-size:12px;">Subject (short title)</label>
            <input type="text" name="subject" class="form-control" maxlength="120" required
                   placeholder="e.g. Server restart in 30 minutes">
        </div>
        <div class="form-group">
            <label style="font-size:12px;">Message (sent to every player as a report)</label>
            <textarea name="body" class="form-control" rows="3" required
                      placeholder="Type your announcement here..."></textarea>
        </div>
        <button type="submit" class="btn btn-gold">📢 Send to All Players</button>
    </form>

    <!-- ============================================================
         Database tables overview
         ============================================================ -->
    <h3 style="color:var(--c-wood-dk);font-size:14px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;margin-top:20px;">
        🗄️ Database Tables
    </h3>
    <table class="data" style="font-size:12px;">
        <thead>
            <tr>
                <th>Table</th>
                <th style="text-align:right;">Rows</th>
                <th>Table</th>
                <th style="text-align:right;">Rows</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $entries = [];
        foreach ($table_sizes as $tbl => $cnt) {
            $entries[] = [$tbl, $cnt];
        }
        // Split into two columns
        $half = (int)ceil(count($entries) / 2);
        $left = array_slice($entries, 0, $half);
        $right = array_slice($entries, $half);
        $max_rows = max(count($left), count($right));
        for ($i = 0; $i < $max_rows; $i++):
            $l = $left[$i] ?? ['', null];
            $r = $right[$i] ?? ['', null];
        ?>
        <tr>
            <td>
                <code><?= e($l[0]) ?></code>
                <?php if ($l[1] === null): ?><span style="color:#8e2a26;font-size:10px;">(missing)</span><?php endif; ?>
            </td>
            <td style="text-align:right;"><?= $l[1] === null ? '—' : number_format($l[1]) ?></td>
            <td>
                <?php if ($r[0] !== ''): ?>
                <code><?= e($r[0]) ?></code>
                <?php if ($r[1] === null): ?><span style="color:#8e2a26;font-size:10px;">(missing)</span><?php endif; ?>
                <?php endif; ?>
            </td>
            <td style="text-align:right;"><?= $r[1] === null ? '—' : ($r[0] === '' ? '' : number_format($r[1])) ?></td>
        </tr>
        <?php endfor; ?>
        </tbody>
    </table>

    <!-- ============================================================
         Recent admin log
         ============================================================ -->
    <h3 style="color:var(--c-wood-dk);font-size:14px;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;margin-top:20px;">
        📝 Recent Admin Actions (audit log)
    </h3>
    <?php if (empty($admin_logs)): ?>
    <p style="font-size:13px;color:var(--c-text-soft);padding:12px;background:#fff;border:1px solid var(--c-outline);border-radius:6px;">
        No admin actions logged yet.
    </p>
    <?php else: ?>
    <table class="data" style="font-size:11px;">
        <thead>
            <tr>
                <th style="width:140px;">When</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($admin_logs as $log): ?>
        <tr>
            <td style="color:var(--c-text-soft);"><?= e($log['created_at']) ?></td>
            <td>
                <strong><?= e($log['title']) ?></strong>
                <pre style="margin:4px 0 0;padding:6px;background:#f4ead5;border-radius:3px;font-size:10px;white-space:pre-wrap;"><?= e($log['body']) ?></pre>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
