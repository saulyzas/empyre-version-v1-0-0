<?php
/**
 * admin_maintenance.php — Database maintenance & cleanup.
 *
 * Actions:
 *   - Recalculate population + capacity for all villages
 *   - Cleanup orphaned data (movements/buildings/troops referencing deleted villages)
 *   - Cleanup expired trade offers
 *   - Vacuum/optimise the SQLite database
 *   - View database file size + path
 *   - Clear old reports (older than X days)
 */
require_once __DIR__ . '/app/lib/helpers.php';
require_once __DIR__ . '/app/lib/admin_helpers.php';
init_session();
require_admin();

$action_msg = '';
$action_err = '';
$action_log = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'recalc_all':
            $r = admin_recalc_all();
            admin_log('Recalculated all villages', "Villages: {$r['villages']}, populations set: {$r['population_set']}, capacities set: {$r['capacity_set']}");
            $action_msg = "Recalculated population + capacity for {$r['villages']} villages.";
            $action_log[] = "Villages processed: {$r['villages']}";
            $action_log[] = "Populations updated: {$r['population_set']}";
            $action_log[] = "Capacities updated: {$r['capacity_set']}";
            break;

        case 'cleanup_orphans':
            $r = admin_cleanup_orphans();
            admin_log('Cleaned up orphaned data', json_encode($r));
            $action_msg = 'Orphan cleanup completed.';
            foreach ($r as $table => $status) {
                $action_log[] = "{$table}: " . ($status === -1 ? 'cleanup ran' : "{$status} rows");
            }
            break;

        case 'expire_trade_offers':
            $now = date('Y-m-d H:i:s');
            try {
                db()->query("UPDATE trade_offers SET status = 'expired' WHERE status = 'active' AND expires_at < ?", [$now]);
                $action_msg = 'Expired trade offers have been marked as expired.';
                admin_log('Marked expired trade offers', "Cutoff: {$now}");
            } catch (Throwable $e) {
                $action_err = 'Error: ' . $e->getMessage();
            }
            break;

        case 'clear_old_reports':
            $days = max(1, (int)($_POST['days'] ?? 30));
            $cutoff = date('Y-m-d H:i:s', time() - $days * 86400);
            try {
                // Keep admin audit logs (category='admin') — only delete general/trade/combat
                db()->query(
                    "DELETE FROM reports WHERE category != 'admin' AND created_at < ?",
                    [$cutoff]
                );
                $action_msg = "Reports older than {$days} days have been deleted (admin logs preserved).";
                admin_log('Cleared old reports', "Older than {$days} days (cutoff {$cutoff}). Admin logs preserved.");
            } catch (Throwable $e) {
                $action_err = 'Error: ' . $e->getMessage();
            }
            break;

        case 'vacuum_sqlite':
            try {
                db()->pdo()->exec('VACUUM');
                $action_msg = 'SQLite VACUUM completed — database file compacted.';
                admin_log('VACUUM', 'Compacted SQLite database file.');
            } catch (Throwable $e) {
                $action_err = 'VACUUM failed: ' . $e->getMessage() . ' (only works on SQLite).';
            }
            break;

        case 'process_all_queues':
            // Force-process all build/training/research/movement queues across all villages.
            // Useful for catching up after a server downtime.
            try {
                $villages = db()->fetchAll("SELECT id FROM villages");
                $cnt = 0;
                foreach ($villages as $v) {
                    process_build_queue($v['id']);
                    $cnt++;
                }
                $action_msg = "Processed queues for {$cnt} villages.";
                admin_log('Force-processed queues', "Villages: {$cnt}");
            } catch (Throwable $e) {
                $action_err = 'Error: ' . $e->getMessage();
            }
            break;

        default:
            $action_err = 'Unknown action.';
    }
}

// Database info
$db_path = defined('DB_PATH') ? DB_PATH : '';
$db_size = '';
if ($db_path && file_exists($db_path)) {
    $bytes = filesize($db_path);
    $db_size = $bytes >= 1048576
        ? number_format($bytes / 1048576, 2) . ' MB'
        : number_format($bytes / 1024, 1) . ' KB';
}
$driver = db()->pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);

$page_title = 'Admin — Maintenance';
require __DIR__ . '/app/views/header.php';
?>

<div class="card">
    <div class="card-header" style="background:linear-gradient(135deg,#8e2a26,#5a1a18);color:#fff;">
        🛠️ Admin — Database Maintenance
    </div>

    <p style="font-size:12px;">
        <a href="<?= url('/admin.php') ?>">← Back to Admin Panel</a>
    </p>

    <?php if ($action_msg): ?>
    <div class="alert alert-success">
        <strong>✅ <?= e($action_msg) ?></strong>
        <?php if (!empty($action_log)): ?>
        <ul style="margin:6px 0 0 18px;font-size:11px;">
            <?php foreach ($action_log as $line): ?><li><?= e($line) ?></li><?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($action_err): ?>
    <div class="alert alert-error"><?= e($action_err) ?></div>
    <?php endif; ?>

    <!-- ============================================================
         Database info
         ============================================================ -->
    <h3 style="font-size:13px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">🗄️ Database</h3>
    <table class="data" style="font-size:12px;margin-bottom:18px;">
        <tr><th style="width:30%;">Driver</th><td><code><?= e($driver) ?></code></td></tr>
        <?php if ($driver === 'sqlite'): ?>
        <tr><th>SQLite file path</th><td><code><?= e($db_path) ?></code></td></tr>
        <tr><th>File size</th><td><?= e($db_size) ?></td></tr>
        <?php elseif ($driver === 'mysql'): ?>
        <tr><th>Host</th><td><code><?= e(DB_HOST) ?>:<?= e(DB_PORT) ?></code></td></tr>
        <tr><th>Database</th><td><code><?= e(DB_NAME) ?></code></td></tr>
        <?php endif; ?>
    </table>

    <!-- ============================================================
         Maintenance actions
         ============================================================ -->
    <h3 style="font-size:13px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">🔧 Maintenance Actions</h3>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;">

        <!-- Recalc all -->
        <form method="POST" style="background:#fff;border:2px solid var(--c-outline);padding:12px;border-radius:6px;"
              onsubmit="return confirm('Recalculate population and capacity for all villages?');">
            <input type="hidden" name="action" value="recalc_all">
            <h4 style="margin:0 0 4px;color:var(--c-wood-dk);">🔄 Recalculate All Villages</h4>
            <p style="font-size:11px;color:var(--c-text-soft);margin:4px 0 8px;">
                Recompute population (based on buildings + fields) and warehouse/granary capacity for every village in the database. Use after manual DB edits or migrations.
            </p>
            <button type="submit" class="btn btn-sm btn-blue" style="width:100%;">🔄 Recalculate Now</button>
        </form>

        <!-- Cleanup orphans -->
        <form method="POST" style="background:#fff;border:2px solid var(--c-outline);padding:12px;border-radius:6px;"
              onsubmit="return confirm('Clean up orphaned data? This will DELETE movements/buildings/troops that reference non-existent villages. Safe but irreversible.');">
            <input type="hidden" name="action" value="cleanup_orphans">
            <h4 style="margin:0 0 4px;color:var(--c-wood-dk);">🧹 Cleanup Orphaned Data</h4>
            <p style="font-size:11px;color:var(--c-text-soft);margin:4px 0 8px;">
                Delete orphaned rows (movements, resource_movements, troops, buildings, resource_fields, reports) that reference deleted villages or players. Run periodically to keep the DB clean.
            </p>
            <button type="submit" class="btn btn-sm btn-red" style="width:100%;">🧹 Cleanup Now</button>
        </form>

        <!-- Expire trade offers -->
        <form method="POST" style="background:#fff;border:2px solid var(--c-outline);padding:12px;border-radius:6px;">
            <input type="hidden" name="action" value="expire_trade_offers">
            <h4 style="margin:0 0 4px;color:var(--c-wood-dk);">⌛ Expire Old Trade Offers</h4>
            <p style="font-size:11px;color:var(--c-text-soft);margin:4px 0 8px;">
                Mark all trade offers past their expiry timestamp as <code>expired</code>. Usually runs automatically when offers are viewed, but this catches any missed ones.
            </p>
            <button type="submit" class="btn btn-sm btn-blue" style="width:100%;">⌛ Expire Now</button>
        </form>

        <!-- Process all queues -->
        <form method="POST" style="background:#fff;border:2px solid var(--c-outline);padding:12px;border-radius:6px;"
              onsubmit="return confirm('Force-process all queues (build/training/research/movements) for every village? Use after server downtime to catch up.');">
            <input type="hidden" name="action" value="process_all_queues">
            <h4 style="margin:0 0 4px;color:var(--c-wood-dk);">⚡ Process All Queues</h4>
            <p style="font-size:11px;color:var(--c-text-soft);margin:4px 0 8px;">
                Force-process build / training / research / movement queues for every village. Useful after server downtime — finishes any items that should have completed while the server was offline.
            </p>
            <button type="submit" class="btn btn-sm btn-gold" style="width:100%;">⚡ Process Now</button>
        </form>

        <!-- Clear old reports -->
        <form method="POST" style="background:#fff;border:2px solid var(--c-outline);padding:12px;border-radius:6px;"
              onsubmit="return confirm('Delete old reports? Admin audit logs (category=admin) will be preserved.');">
            <input type="hidden" name="action" value="clear_old_reports">
            <h4 style="margin:0 0 4px;color:var(--c-wood-dk);">🗑️ Clear Old Reports</h4>
            <p style="font-size:11px;color:var(--c-text-soft);margin:4px 0 8px;">
                Delete reports older than the specified number of days. Admin audit logs (category=admin) are always preserved.
            </p>
            <div style="display:flex;gap:6px;align-items:center;margin-bottom:6px;">
                <label style="font-size:11px;">Older than</label>
                <input type="number" name="days" class="form-control" value="30" min="1" max="3650" style="width:80px;font-size:11px;padding:2px;">
                <span style="font-size:11px;">days</span>
            </div>
            <button type="submit" class="btn btn-sm btn-red" style="width:100%;">🗑️ Clear Old Reports</button>
        </form>

        <!-- VACUUM (SQLite only) -->
        <?php if ($driver === 'sqlite'): ?>
        <form method="POST" style="background:#fff;border:2px solid var(--c-outline);padding:12px;border-radius:6px;"
              onsubmit="return confirm('VACUUM the SQLite database? This compacts the file and may take a few seconds.');">
            <input type="hidden" name="action" value="vacuum_sqlite">
            <h4 style="margin:0 0 4px;color:var(--c-wood-dk);">🗜️ VACUUM Database</h4>
            <p style="font-size:11px;color:var(--c-text-soft);margin:4px 0 8px;">
                Compact the SQLite database file (reclaims space from deleted rows). Only works on SQLite — equivalent to <code>OPTIMIZE TABLE</code> on MySQL.
            </p>
            <button type="submit" class="btn btn-sm btn-gold" style="width:100%;">🗜️ VACUUM Now</button>
        </form>
        <?php endif; ?>
    </div>

    <!-- ============================================================
         Migration reminder
         ============================================================ -->
    <div style="margin-top:18px;padding:12px;background:#fff8d6;border-left:4px solid var(--c-gold-dk);border-radius:4px;font-size:12px;">
        <strong>📦 Need to run schema migrations?</strong>
        Visit <a href="<?= url('/migrate.php') ?>">migrate.php</a> to apply pending schema updates (new columns, new tables, etc.). The migration script is idempotent — safe to run multiple times.
    </div>

    <!-- ============================================================
         Safety warnings
         ============================================================ -->
    <div style="margin-top:14px;padding:10px;background:#fce4e4;border-left:4px solid #8e2a26;border-radius:4px;font-size:12px;">
        <strong>⚠️ Safety notes:</strong>
        <ul style="margin:4px 0 0 18px;">
            <li>All maintenance actions are logged to the admin audit trail (visible on the main admin panel).</li>
            <li>"Cleanup Orphaned Data" deletes rows permanently — make sure you have a backup if unsure.</li>
            <li>"Clear Old Reports" preserves admin audit logs but deletes trade/combat/general reports older than the cutoff.</li>
            <li>For production servers, take a database backup before running cleanup operations.</li>
        </ul>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
