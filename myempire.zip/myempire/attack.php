<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

// Get target coordinates
$to_x = (int)($_GET['x'] ?? 0);
$to_y = (int)($_GET['y'] ?? 0);

// Find target village
$target = db()->fetch(
    "SELECT v.*, p.username, p.tribe AS player_tribe
     FROM villages v JOIN players p ON p.id = v.player_id
     WHERE v.x = ? AND v.y = ?",
    [$to_x, $to_y]
);

$page_title = 'Attack';
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:600px;margin:0 auto;">
    <div class="card-header">⚔️ Attack Coordinates (<?= $to_x ?>|<?= $to_y ?>)</div>

    <?php if (!$target): ?>
    <div class="alert alert-info">No village found at these coordinates.</div>
    <p style="text-align:center;"><a href="<?= url('/map.php') ?>">← Back to Map</a></p>
    <?php else: ?>
    <p>Target: <strong><?= e($target['name']) ?></strong> (<?= e($target['username']) ?>, <?= e(ucfirst($target['player_tribe'])) ?>)</p>

    <?php
    $my_player = current_player();
    $my_tribe = $my_player['tribe'];
    $my_troops = get_village_troops($village['id']);
    $my_units = $GLOBALS['UNITS'][$my_tribe] ?? [];
    ?>

    <?php if (empty($my_troops)): ?>
    <div class="alert alert-info">
        You have no troops to attack with. Train some at the <a href="<?= url('/troops.php') ?>">Troops</a> page.
    </div>
    <?php else: ?>
    <form method="POST" action="<?= url('/send_troops.php') ?>">
        <input type="hidden" name="to_x" value="<?= $to_x ?>">
        <input type="hidden" name="to_y" value="<?= $to_y ?>">
        <input type="hidden" name="mission" value="attack">

        <table class="data" style="font-size:12px;">
            <thead>
                <tr><th>Unit</th><th>Attack</th><th>Carry</th><th>Have</th><th>Send</th></tr>
            </thead>
            <tbody>
            <?php foreach ($my_troops as $t):
                $u = $my_units[$t['unit_type']] ?? null;
                if (!$u) continue;
                $carry = $GLOBALS['UNIT_CARRY_CAPACITY'][$t['unit_type']] ?? 0;
            ?>
            <tr>
                <td>
                    <img src="<?= img_url("troops/{$my_tribe}_{$t['unit_type']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e($u['name']) ?>
                </td>
                <td><?= (int)$u['attack'] ?></td>
                <td><?= $carry ?></td>
                <td><?= (int)$t['count'] ?></td>
                <td>
                    <input type="number" name="troops[<?= e($t['unit_type']) ?>]" min="0" max="<?= (int)$t['count'] ?>" value="0" style="width:60px;padding:2px;" class="form-control">
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <div style="margin-top:12px;padding:8px;background:#fff8d6;border-left:4px solid #f0c34b;font-size:12px;">
            <strong>Your tribe (<?= ucfirst($my_tribe) ?>) loot bonus:</strong>
            <?= $GLOBALS['TRIBE_LOOT_MULTIPLIER'][$my_tribe] * 100 ?>% of total carry capacity.
            <?php if ($my_tribe === 'teuton'): ?>
            Teutons are the best raiders — they take 100% of what their troops can carry.
            <?php elseif ($my_tribe === 'roman'): ?>
            Romans take 80% of carry capacity.
            <?php else: ?>
            Gauls take 70% of carry capacity.
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-red btn-lg" style="margin-top:12px;width:100%;">⚔ Launch Attack</button>
    </form>
    <?php endif; ?>

    <p style="text-align:center;margin-top:16px;">
        <a href="<?= url('/map.php') . '?x=' . $to_x . '&y=' . $to_y ?>">← Back to Map</a>
        <?php if ($target): ?>
        | <a href="<?= url('/player.php') . '?id=' . (int)$target['player_id'] ?>">View Player Profile</a>
        <?php endif; ?>
    </p>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
