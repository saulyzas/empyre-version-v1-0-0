<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);
$buildings = get_buildings($village['id']);
$queue = get_build_queue($village['id']);

// Build lookup: position => building
$buildings_by_pos = [];
foreach ($buildings as $b) $buildings_by_pos[$b['position']] = $b;

// 20 slots total (0 = village center / Main Building)
$total_slots = 20;

$page_title = 'Village';
require __DIR__ . '/app/views/header.php';
?>

<div class="grid grid-2">
    <div>
        <div class="card">
            <div class="card-header">
                <?= e($village['name']) ?>
                <span style="font-weight:normal;color:var(--c-text-soft);font-size:13px;">(<?= (int)$village['x'] ?>|<?= (int)$village['y'] ?>)</span>
            </div>

            <div style="display:flex;gap:12px;font-size:12px;color:var(--c-text-soft);margin-bottom:12px;flex-wrap:wrap;">
                <span><img src="<?= img_url('misc/loyalty.png') ?>" width="14" height="14" alt=""> Loyalty: <?= (int)$village['loyalty'] ?>%</span>
                <?php if ($village['is_capital']): ?>
                <span><img src="<?= img_url('misc/capital.png') ?>" width="14" height="14" alt=""> Capital</span>
                <?php endif; ?>
            </div>

            <!-- Village grid: 20 slots -->
            <div class="village-grid">
                <?php
                // Build a lookup of queued builds by position
                $queue_by_pos = [];
                foreach ($queue as $q) {
                    if ($q['target_kind'] === 'building') {
                        $queue_by_pos[$q['position']] = $q;
                    }
                }
                ?>
                <?php for ($i = 0; $i < $total_slots; $i++):
                    $b = $buildings_by_pos[$i] ?? null;
                    $queued = $queue_by_pos[$i] ?? null;
                    if ($b && $b['building_type']):
                        $img = "buildings/{$b['building_type']}.png";
                ?>
                <a href="<?= url('/building.php') . '?id=' . $i ?>" class="village-slot occupied">
                    <img src="<?= img_url($img) ?>" alt="<?= e($b['building_type']) ?>">
                    <span class="slot-level"><?= (int)$b['level'] ?></span>
                </a>
                <?php elseif ($queued): ?>
                <a href="<?= url('/building.php') . '?id=' . $i ?>" class="village-slot occupied" style="background:rgba(240,195,75,0.3);border-style:dashed;" title="Building <?= e(ucfirst(str_replace('_',' ',$queued['target_type']))) ?>">
                    <img src="<?= img_url("buildings/{$queued['target_type']}.png") ?>" alt="" style="opacity:0.5;">
                    <span class="slot-level" style="background:#4a7a3a;color:#fff;">⏳</span>
                </a>
                <?php else: ?>
                <a href="<?= url('/build.php') . '?id=' . $i ?>" class="village-slot">
                    <img src="<?= img_url('ui/slot_empty.png') ?>" alt="Empty slot">
                </a>
                <?php endif; ?>
                <?php endfor; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">Building Queue</div>
            <?php if (empty($queue)): ?>
            <p style="color:var(--c-text-soft);">The queue is currently empty.</p>
            <?php else: ?>
            <?php foreach ($queue as $item): ?>
            <div class="queue-item">
                <img src="<?= img_url('ui/queue_icon.png') ?>" width="20" height="20" alt="">
                <span class="queue-name">
                    <?= e(ucfirst(str_replace('_', ' ', $item['target_type']))) ?> → Level <?= (int)$item['target_level'] ?>
                </span>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($item['finishes_at']) ?>">...</span>
                <a href="<?= url('/cancel_build.php') ?>?id=<?= (int)$item['id'] ?>" class="queue-cancel" onclick="return confirm('Cancel this build?')">✕</a>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <div class="panel">
            <div class="panel-title">Villages</div>
            <ul style="list-style:none;">
                <li>
                    <a href="<?= url('/village.php') ?>"><?= e($village['name']) ?></a><br>
                    <span style="font-size:11px;color:var(--c-text-soft);"><?= (int)$village['x'] ?>|<?= (int)$village['y'] ?></span>
                </li>
            </ul>
        </div>

        <div class="panel">
            <div class="panel-title">Buildings</div>
            <?php if (empty($buildings)): ?>
            <p style="font-size:11px;color:var(--c-text-soft);">No buildings yet.</p>
            <?php else: ?>
            <ul style="list-style:none;font-size:12px;">
                <?php foreach ($buildings as $b): ?>
                <li>
                    <a href="<?= url('/building.php') . '?id=' . (int)$b['position'] ?>">
                        <?= e(ucfirst(str_replace('_', ' ', $b['building_type']))) ?> (Lv <?= (int)$b['level'] ?>)
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>

        <div class="panel">
            <div class="panel-title">Quick Actions</div>
            <a href="<?= url('/resources.php') ?>" class="btn btn-green btn-sm" style="display:block;margin-bottom:4px;">Manage Fields</a>
            <a href="<?= url('/troops.php') ?>" class="btn btn-red btn-sm" style="display:block;margin-bottom:4px;">Train Troops</a>
            <a href="<?= url('/marketplace.php') ?>" class="btn btn-gold btn-sm" style="display:block;margin-bottom:4px;">🏪 Marketplace</a>
            <a href="<?= url('/map.php') ?>" class="btn btn-blue btn-sm" style="display:block;margin-bottom:4px;">Open World Map</a>
            <a href="<?= url('/hero.php') ?>" class="btn btn-gold btn-sm" style="display:block;">Hero Mansion</a>
        </div>

        <div class="panel">
            <div class="panel-title">Tips</div>
            <ul style="font-size:11px;padding-left:14px;">
                <li>Click an empty slot to build a new structure.</li>
                <li>Click an existing building to upgrade it.</li>
                <li>Build a Warehouse to store more wood/clay/iron.</li>
                <li>Build a Granary to store more crop.</li>
                <li>Build a Barracks to start training troops.</li>
            </ul>
        </div>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
