<?php
/**
 * Header partial - shown on all authenticated pages.
 *
 * Contains the main navigation bar with links to every gameplay screen:
 *   Fields · Village · Troops · Map · Ranks · Reports · Hero
 *
 * The header still shows the brand (linked to home), player name, gold,
 * server speed, server time, a logout link, and the resource bar.
 */
require_once __DIR__ . '/../lib/helpers.php';
init_session();

$player = current_player();
$village = current_village();
if ($village) {
    process_build_queue($village['id']);
    $resources = update_resources($village['id']);
    $production = production_per_hour($village['id']);
}
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Update the player's last_activity timestamp (throttled to once per minute).
// This powers the "online now" / "active today" statistics on the landing page.
if ($player) {
    update_last_activity();
}

// Count unread reports for the Reports badge
$unread_reports = 0;
if ($player) {
    $unread_reports = (int)db()->fetchColumn(
        "SELECT COUNT(*) FROM reports WHERE player_id = ? AND is_read = 0",
        [$player['id']]
    );
}

// Main navigation items (top bar of every authenticated page).
$nav_items = [
    'resources' => ['title' => 'Fields',  'icon' => 'wheat',  'img' => 'misc/crop.png'],
    'village'   => ['title' => 'Village', 'icon' => 'house',  'img' => 'buildings/main_building.png'],
    'troops'    => ['title' => 'Troops',  'icon' => 'sword',  'img' => 'troops/roman_legionnaire.png'],
    'map'       => ['title' => 'Map',     'icon' => 'map',    'img' => 'map/grass.png'],
    'stats'     => ['title' => 'Ranks',   'icon' => 'chart',  'img' => 'ui/level_badge_3.png'],
    'reports'   => ['title' => 'Reports', 'icon' => 'file',   'img' => 'ui/queue_icon.png', 'badge' => $unread_reports],
    'hero'      => ['title' => 'Hero',    'icon' => 'star',   'img' => 'misc/hero_icon.png'],
    'faq'       => ['title' => 'FAQ',     'icon' => 'help',   'img' => 'ui/level_badge_1.png'],
];

// Admin link is shown only to admins — appended after the regular nav items.
// We lazy-load admin_helpers.php only when needed (to avoid loading it for
// every regular page view).
$show_admin_link = false;
if ($player) {
    require_once __DIR__ . '/../lib/admin_helpers.php';
    $show_admin_link = is_admin();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(GAME_NAME) ?><?= isset($page_title) ? " - " . e($page_title) : "" ?></title>
    <link rel="stylesheet" href="<?= CSS_URL ?>/style.css?v=<?= GAME_VERSION ?>">
</head>
<body>
<header class="game-header">
    <!-- Top bar -->
    <div class="header-topbar">
        <div class="brand"><a href="<?= url('/') ?>"><?= e(GAME_NAME) ?></a></div>
        <?php if ($player): ?>
        <div class="topbar-right">
            <span class="player-name"><?= e($player['username']) ?></span>
            <?php
            // Show gold if logged in
            $gold = (int)db()->fetchColumn("SELECT gold FROM players WHERE id = ?", [$player['id']]);
            ?>
            <span class="gold-badge" title="Gold coins" style="background:linear-gradient(135deg,#f0c34b,#b88e28);color:#2a1f15;padding:2px 8px;border-radius:4px;border:1px solid #8c6f1a;font-weight:bold;font-size:11px;">₲ <?= $gold ?></span>
            <a href="<?= url('/logout.php') ?>" class="btn-link btn-logout">Logout</a>
            <span class="speed-badge" title="Server speed"><?= (int)GAME_SERVER_SPEED ?>x</span>
            <span class="server-time" id="server-time"><?= date('H:i:s') ?></span>
        </div>
        <?php else: ?>
        <div class="topbar-right">
            <a href="<?= url('/login.php') ?>" class="btn-link">Login</a>
            <a href="<?= url('/register.php') ?>" class="btn-link">Register</a>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($player): ?>
    <!-- Main navigation links -->
    <nav class="header-nav">
        <?php foreach ($nav_items as $page => $item): ?>
        <a href="<?= url('/' . $page . '.php') ?>" class="nav-icon <?= $current_page === $page ? 'nav-active' : '' ?>" title="<?= e($item['title']) ?>">
            <img src="<?= img_url($item['img']) ?>" alt="<?= e($item['title']) ?>" width="22" height="22">
            <?php if (!empty($item['badge']) && $item['badge'] > 0): ?>
            <span style="position:absolute;top:-4px;right:-4px;background:var(--c-red);color:#fff;font-size:10px;font-weight:bold;padding:1px 5px;border-radius:8px;border:1px solid var(--c-outline);min-width:14px;text-align:center;"><?= (int)$item['badge'] ?></span>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
        <?php if ($show_admin_link): ?>
        <a href="<?= url('/admin.php') ?>" class="nav-icon <?= $current_page === 'admin' || strpos($current_page, 'admin_') === 0 ? 'nav-active' : '' ?>" title="Admin Panel" style="background:linear-gradient(135deg,#8e2a26,#5a1a18);border-radius:4px;">
            <span style="font-size:18px;color:#f0c34b;font-weight:bold;line-height:22px;">★</span>
        </a>
        <?php endif; ?>
    </nav>

    <!-- Resource bar -->
    <div class="header-resources">
        <div class="res-item" title="Wood">
            <span class="res-icon res-wood"></span>
            <span class="res-value" data-res="wood"><?= isset($resources) ? (int)$resources['wood'] : 0 ?></span>
            <span class="res-cap">/<?= isset($resources) ? $resources['wood_cap'] : 0 ?></span>
        </div>
        <div class="res-item" title="Clay">
            <span class="res-icon res-clay"></span>
            <span class="res-value" data-res="clay"><?= isset($resources) ? (int)$resources['clay'] : 0 ?></span>
            <span class="res-cap">/<?= isset($resources) ? $resources['clay_cap'] : 0 ?></span>
        </div>
        <div class="res-item" title="Iron">
            <span class="res-icon res-iron"></span>
            <span class="res-value" data-res="iron"><?= isset($resources) ? (int)$resources['iron'] : 0 ?></span>
            <span class="res-cap">/<?= isset($resources) ? $resources['iron_cap'] : 0 ?></span>
        </div>
        <div class="res-item" title="Crop">
            <span class="res-icon res-crop"></span>
            <span class="res-value" data-res="crop"><?= isset($resources) ? (int)$resources['crop'] : 0 ?></span>
            <span class="res-cap">/<?= isset($resources) ? $resources['crop_cap'] : 0 ?></span>
        </div>
        <div class="res-item" title="Population">
            <img src="<?= img_url('misc/population.png') ?>" alt="Pop" width="16" height="16">
            <span class="res-value"><?= (int)$player['population'] ?></span>
        </div>
        <!-- Hidden production rates for JS -->
        <span id="prod-wood" style="display:none"><?= $production['wood'] ?? 0 ?></span>
        <span id="prod-clay" style="display:none"><?= $production['clay'] ?? 0 ?></span>
        <span id="prod-iron" style="display:none"><?= $production['iron'] ?? 0 ?></span>
        <span id="prod-crop" style="display:none"><?= $production['crop'] ?? 0 ?></span>
    </div>
    <?php endif; ?>
</header>

<main class="game-main">
