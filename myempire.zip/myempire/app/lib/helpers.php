<?php
/**
 * MYEMPIRE - Helper functions
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/error_handler.php';

// ---- Session & Auth ----
function init_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params(['lifetime' => SESSION_LIFETIME, 'path' => '/', 'httponly' => true]);
        session_start();
    }
}

function current_player_id() {
    return $_SESSION['player_id'] ?? null;
}

function current_player() {
    $pid = current_player_id();
    if (!$pid) return null;
    static $cache = null;
    if ($cache === null || $cache['id'] != $pid) {
        $cache = db()->fetch("SELECT * FROM players WHERE id = ?", [$pid]);
    }
    return $cache;
}

function current_village() {
    $pid = current_player_id();
    if (!$pid) return null;
    static $cache = null;
    if ($cache === null || $cache['player_id'] != $pid) {
        $cache = db()->fetch("SELECT * FROM villages WHERE player_id = ? ORDER BY is_capital DESC, id ASC LIMIT 1", [$pid]);
    }
    return $cache;
}

function require_login() {
    if (!current_player_id()) {
        redirect('/login.php');
    }
}

// ============================================================
// PLAYER ACTIVITY TRACKING + SERVER STATISTICS
// ============================================================
// last_activity is updated whenever an authenticated player loads
// any page (called from header.php). We use it to determine:
//   - Online now      (active within last 5 minutes)
//   - Active today    (active within last 24 hours)
//   - Active this week(active within last 7 days)
// To avoid hammering the DB on every page load, we throttle updates
// to at most once per 60 seconds per player.

define('ONLINE_THRESHOLD_SECONDS',    5 * 60);   // 5 minutes
define('ACTIVE_TODAY_THRESHOLD_HOURS', 24);      // 24 hours
define('ACTIVE_WEEK_THRESHOLD_DAYS',    7);      // 7 days
define('ACTIVITY_UPDATE_THROTTLE_SEC', 60);      // 1 minute

// Update last_activity for the current player (throttled).
// Safe to call on every page load.
function update_last_activity() {
    $pid = current_player_id();
    if (!$pid) return;

    // Read current last_activity from cached player record.
    // We need a fresh read here (don't trust the static cache) because
    // the cached copy may be stale across requests.
    $row = db()->fetch("SELECT last_activity FROM players WHERE id = ?", [$pid]);
    if (!$row) return;

    $now = time();
    $last_ts = $row['last_activity'] ? strtotime($row['last_activity']) : 0;
    if ($last_ts && ($now - $last_ts) < ACTIVITY_UPDATE_THROTTLE_SEC) {
        // Throttled — too soon since last update.
        return;
    }

    db()->query(
        "UPDATE players SET last_activity = ? WHERE id = ?",
        [date('Y-m-d H:i:s', $now), $pid]
    );
}

// Returns an array of server-wide statistics for display on index.php,
// stats.php, and other landing pages.
//
//   total_players        — total registered players
//   online_now           — players active within last 5 minutes
//   active_today         — players active within last 24 hours
//   active_this_week     — players active within last 7 days
//   total_villages       — total villages founded
//   total_troops         — total troops across all villages
//   newest_player        — most recently registered player (assoc array)
//   top_player           — highest-population player (assoc array)
//   online_players_list  — short list of online_now players (id, username, tribe)
//   tribe_counts         — ['roman' => N, 'gaul' => N, 'teuton' => N]
function get_server_stats() {
    $stats = [
        'total_players'      => 0,
        'online_now'         => 0,
        'active_today'       => 0,
        'active_this_week'   => 0,
        'total_villages'     => 0,
        'total_troops'       => 0,
        'newest_player'      => null,
        'top_player'         => null,
        'online_players_list'=> [],
        'tribe_counts'       => ['roman' => 0, 'gaul' => 0, 'teuton' => 0],
    ];

    try {
        // Total players
        $stats['total_players'] = (int)db()->fetchColumn("SELECT COUNT(*) FROM players");

        // Online now (active within ONLINE_THRESHOLD_SECONDS)
        $online_cutoff = date('Y-m-d H:i:s', time() - ONLINE_THRESHOLD_SECONDS);
        $stats['online_now'] = (int)db()->fetchColumn(
            "SELECT COUNT(*) FROM players WHERE last_activity IS NOT NULL AND last_activity >= ?",
            [$online_cutoff]
        );

        // Active today (24h)
        $today_cutoff = date('Y-m-d H:i:s', time() - ACTIVE_TODAY_THRESHOLD_HOURS * 3600);
        $stats['active_today'] = (int)db()->fetchColumn(
            "SELECT COUNT(*) FROM players WHERE last_activity IS NOT NULL AND last_activity >= ?",
            [$today_cutoff]
        );

        // Active this week (7d)
        $week_cutoff = date('Y-m-d H:i:s', time() - ACTIVE_WEEK_THRESHOLD_DAYS * 86400);
        $stats['active_this_week'] = (int)db()->fetchColumn(
            "SELECT COUNT(*) FROM players WHERE last_activity IS NOT NULL AND last_activity >= ?",
            [$week_cutoff]
        );

        // Total villages
        try {
            $stats['total_villages'] = (int)db()->fetchColumn("SELECT COUNT(*) FROM villages");
        } catch (Throwable $e) { /* table might not exist */ }

        // Total troops
        try {
            $stats['total_troops'] = (int)db()->fetchColumn(
                "SELECT COALESCE(SUM(count), 0) FROM troops"
            );
        } catch (Throwable $e) { /* table might not exist */ }

        // Newest player
        $newest = db()->fetch(
            "SELECT id, username, tribe, created_at FROM players ORDER BY created_at DESC, id DESC LIMIT 1"
        );
        if ($newest) $stats['newest_player'] = $newest;

        // Top player (by population)
        $top = db()->fetch(
            "SELECT id, username, tribe, population FROM players ORDER BY population DESC, id ASC LIMIT 1"
        );
        if ($top) $stats['top_player'] = $top;

        // Online players list (limit to 8 for the panel)
        $stats['online_players_list'] = db()->fetchAll(
            "SELECT id, username, tribe, last_activity
             FROM players
             WHERE last_activity IS NOT NULL AND last_activity >= ?
             ORDER BY last_activity DESC
             LIMIT 8",
            [$online_cutoff]
        );

        // Tribe counts
        $tribe_rows = db()->fetchAll(
            "SELECT tribe, COUNT(*) AS cnt FROM players GROUP BY tribe"
        );
        foreach ($tribe_rows as $tr) {
            $stats['tribe_counts'][$tr['tribe']] = (int)$tr['cnt'];
        }
    } catch (Throwable $e) {
        // If any query fails (e.g. column not yet migrated), return zeros.
    }

    return $stats;
}

// Helper: format "time ago" — e.g. "3 minutes ago", "just now", "2 hours ago".
function time_ago($datetime_str) {
    if (!$datetime_str) return 'never';
    $ts = strtotime($datetime_str);
    if (!$ts) return 'never';
    $diff = time() - $ts;
    if ($diff < 60) return 'just now';
    if ($diff < 3600) {
        $m = max(1, (int)($diff / 60));
        return $m . ' minute' . ($m > 1 ? 's' : '') . ' ago';
    }
    if ($diff < 86400) {
        $h = (int)($diff / 3600);
        return $h . ' hour' . ($h > 1 ? 's' : '') . ' ago';
    }
    if ($diff < 86400 * 7) {
        $d = (int)($diff / 86400);
        return $d . ' day' . ($d > 1 ? 's' : '') . ' ago';
    }
    return date('Y-m-d', $ts);
}

// ============================================================
// REPORT FORMATTING + CATEGORISATION HELPERS
// ============================================================
// These power the cleaner reports.php UI:
//   - format_resources_block()  — pretty-print a wood/clay/iron/crop block
//   - categorize_report()       — split combat reports into 'attack' (outgoing)
//                                 vs 'defense' (incoming) for the 3-tab UI

// Pretty-print a resource block (used in report bodies).
// Returns a multi-line string suitable for a <pre>-style report body.
function format_resources_block($wood, $clay, $iron, $crop) {
    $wood = (int)$wood;
    $clay = (int)$clay;
    $iron = (int)$iron;
    $crop = (int)$crop;
    $total = $wood + $clay + $iron + $crop;
    $lines = [];
    $lines[] = "  Wood  : " . number_format($wood);
    $lines[] = "  Clay  : " . number_format($clay);
    $lines[] = "  Iron  : " . number_format($iron);
    $lines[] = "  Crop  : " . number_format($crop);
    $lines[] = "  ─────────────";
    $lines[] = "  Total : " . number_format($total);
    return implode("\n", $lines);
}

// Categorise a report into one of: 'attack', 'defense', 'resources', 'admin', 'other'.
// Used by reports.php to split combat reports into outgoing (attack) and
// incoming (defense) tabs without needing a schema change.
//
// Heuristics:
//   - category='trade'                       → 'resources'
//   - category='admin'                       → 'admin'
//   - category='combat' + title patterns:
//       "Incoming attack", "Defense of",
//       "VILLAGE ATTACKED", "VILLAGE DEFENDED",
//       "Defeat at" + body contains "was attacked" or "VILLAGE ATTACKED"
//                                              → 'defense'
//       everything else combat                → 'attack'
//   - otherwise                               → 'other'
function categorize_report($report) {
    $title = $report['title']  ?? '';
    $body  = $report['body']   ?? '';
    $cat   = $report['category'] ?? 'general';

    if ($cat === 'trade')     return 'resources';
    if ($cat === 'admin')     return 'admin';

    if ($cat === 'combat') {
        // Clearly incoming (defense) titles
        if (strpos($title, 'Incoming attack') !== false) return 'defense';
        if (strpos($title, 'Defense of')      !== false) return 'defense';
        if (strpos($title, 'VILLAGE ATTACKED') !== false) return 'defense';
        if (strpos($title, 'VILLAGE DEFENDED') !== false) return 'defense';
        // The "Defeat at" title is used both for attacker losing AND defender
        // losing. Disambiguate via the body content.
        if (strpos($title, 'Defeat at') !== false) {
            if (strpos($body, 'VILLAGE ATTACKED') !== false
             || strpos($body, 'was attacked')     !== false
             || strpos($body, 'all defending troops perished') !== false) {
                return 'defense';
            }
            return 'attack';
        }
        // Anything else combat-related (Victory, Attack sent, RAID) = outgoing
        return 'attack';
    }
    return 'other';
}

// ---- Output helpers ----
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    // Auto-prefix with BASE_PATH so it works in subdirectories (e.g. /myempire/)
    if (defined('BASE_PATH') && strpos($path, '/') === 0 && strpos($path, '//') !== 0) {
        $path = BASE_PATH . $path;
    }
    header("Location: $path");
    exit;
}

/**
 * Generate a URL with the BASE_PATH prefix.
 * Example: url('/login.php') -> '/myempire/login.php'
 */
function url($path = '') {
    if (empty($path)) return BASE_PATH ?: '/';
    // Already absolute URL (http://...) — return as-is
    if (preg_match('#^https?://#', $path)) return $path;
    // Ensure leading slash
    if ($path[0] !== '/') $path = '/' . $path;
    return BASE_PATH . $path;
}

function json_response($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function img_url($path) {
    return IMG_URL . '/' . ltrim($path, '/');
}

// ---- Resource production ----
function production_per_hour($village_id) {
    global $FIELD_PRODUCTION;
    $fields = db()->fetchAll(
        "SELECT field_type, level FROM resource_fields WHERE village_id = ?",
        [$village_id]
    );
    $prod = ['wood' => 0, 'clay' => 0, 'iron' => 0, 'crop' => 0];
    foreach ($fields as $f) {
        $level = min(MAX_RESOURCE_LEVEL, max(0, $f['level']));
        $rate = $FIELD_PRODUCTION[$level] ?? 0;
        $rate *= GAME_SERVER_SPEED;
        switch ($f['field_type']) {
            case 'woodcutter': $prod['wood']  += $rate; break;
            case 'claypit':    $prod['clay']  += $rate; break;
            case 'ironmine':   $prod['iron']  += $rate; break;
            case 'cropland':   $prod['crop']  += $rate; break;
        }
    }
    // Subtract population consumption (1 crop per population per hour).
    // This is the standard Travian mechanic — every villager eats 1 crop/hour.
    $village = db()->fetch("SELECT player_id FROM villages WHERE id = ?", [$village_id]);
    $player = db()->fetch("SELECT population FROM players WHERE id = ?", [$village['player_id']]);
    $prod['crop'] = max(0, $prod['crop'] - ($player['population'] ?? 0));
    return $prod;
}

// ---- Update resource stockpile based on time elapsed ----
function update_resources($village_id) {
    $res = db()->fetch("SELECT * FROM resources WHERE village_id = ?", [$village_id]);
    if (!$res) {
        // No resources row — auto-create one (safety net for villages created
        // without the SQL trigger or with a broken trigger).
        ensure_village_data($village_id);
        $res = db()->fetch("SELECT * FROM resources WHERE village_id = ?", [$village_id]);
        if (!$res) return null;
    }

    $now = new DateTime('now');
    $last = new DateTime($res['last_update']);
    $diff = $now->getTimestamp() - $last->getTimestamp();
    if ($diff <= 0) return $res;

    $prod = production_per_hour($village_id);
    $per_second = [
        'wood' => $prod['wood'] / 3600.0,
        'clay' => $prod['clay'] / 3600.0,
        'iron' => $prod['iron'] / 3600.0,
        'crop' => $prod['crop'] / 3600.0,
    ];

    $new = [
        'wood' => min($res['wood_cap'], $res['wood'] + $per_second['wood'] * $diff),
        'clay' => min($res['clay_cap'], $res['clay'] + $per_second['clay'] * $diff),
        'iron' => min($res['iron_cap'], $res['iron'] + $per_second['iron'] * $diff),
        'crop' => min($res['crop_cap'], $res['crop'] + $per_second['crop'] * $diff),
    ];

    db()->update('resources', [
        'wood' => $new['wood'],
        'clay' => $new['clay'],
        'iron' => $new['iron'],
        'crop' => $new['crop'],
        'last_update' => $now->format('Y-m-d H:i:s'),
    ], 'village_id = :wv', ['wv' => $village_id]);

    $res['wood'] = $new['wood'];
    $res['clay'] = $new['clay'];
    $res['iron'] = $new['iron'];
    $res['crop'] = $new['crop'];
    return $res;
}

// ---- Recalculate warehouse/granary capacity based on building levels ----
// Warehouse levels increase wood/clay/iron capacity.
// Granary levels increase crop capacity.
// Formula: base_cap + (sum_of_warehouse_levels * WAREHOUSE_PER_LEVEL) for wood/clay/iron,
//          base_cap + (sum_of_granary_levels * GRANARY_PER_LEVEL) for crop.
function recalculate_capacity($village_id) {
    $buildings = db()->fetchAll(
        "SELECT building_type, level FROM buildings WHERE village_id = ?",
        [$village_id]
    );
    $warehouse_level = 0;
    $granary_level = 0;
    foreach ($buildings as $b) {
        if ($b['building_type'] === 'warehouse') $warehouse_level += (int)$b['level'];
        if ($b['building_type'] === 'granary')   $granary_level += (int)$b['level'];
    }

    $wcap = defined('WAREHOUSE_BASE_CAP') ? WAREHOUSE_BASE_CAP : 800;
    $gcap = defined('GRANARY_BASE_CAP') ? GRANARY_BASE_CAP : 800;
    $wpl  = defined('WAREHOUSE_PER_LEVEL') ? WAREHOUSE_PER_LEVEL : 800;
    $gpl  = defined('GRANARY_PER_LEVEL') ? GRANARY_PER_LEVEL : 800;

    // Base capacity + (warehouse levels × per-level bonus)
    $new_wood_cap = $wcap + ($warehouse_level * $wpl);
    $new_clay_cap = $wcap + ($warehouse_level * $wpl);
    $new_iron_cap = $wcap + ($warehouse_level * $wpl);
    $new_crop_cap = $gcap + ($granary_level * $gpl);

    db()->update('resources', [
        'wood_cap' => $new_wood_cap,
        'clay_cap' => $new_clay_cap,
        'iron_cap' => $new_iron_cap,
        'crop_cap' => $new_crop_cap,
    ], 'village_id = :wv', ['wv' => $village_id]);

    return [
        'wood_cap' => $new_wood_cap,
        'clay_cap' => $new_clay_cap,
        'iron_cap' => $new_iron_cap,
        'crop_cap' => $new_crop_cap,
    ];
}

// ---- Ensure a village has all required initialization data ----
// Creates resources row, 18 resource fields, and main building if missing.
// This is the PRIMARY initialization path (called from register.php).
// The SQL trigger trg_init_village serves as a backup.
function ensure_village_data($village_id) {
    $sr = defined('STARTING_RESOURCES') ? STARTING_RESOURCES : 800;

    // --- Resources row ---
    $res = db()->fetch("SELECT village_id FROM resources WHERE village_id = ?", [$village_id]);
    if (!$res) {
        $wcap = defined('WAREHOUSE_BASE_CAP') ? WAREHOUSE_BASE_CAP : 800;
        $gcap = defined('GRANARY_BASE_CAP') ? GRANARY_BASE_CAP : 800;
        $now = date('Y-m-d H:i:s');
        try {
            db()->insert('resources', [
                'village_id' => $village_id,
                'wood' => $sr, 'clay' => $sr, 'iron' => $sr, 'crop' => $sr,
                'wood_cap' => $wcap, 'clay_cap' => $wcap,
                'iron_cap' => $wcap, 'crop_cap' => $gcap,
                'last_update' => $now,
            ]);
        } catch (Throwable $e) {
            // Already exists (trigger may have created it) — ignore duplicate key error
        }
    }

    // --- 18 Resource fields ---
    $field_count = (int)db()->fetchColumn(
        "SELECT COUNT(*) FROM resource_fields WHERE village_id = ?",
        [$village_id]
    );
    if ($field_count === 0) {
        $fields_data = [
            ['woodcutter', 0], ['woodcutter', 1], ['woodcutter', 2], ['woodcutter', 3],
            ['claypit',    4], ['claypit',    5], ['claypit',    6], ['claypit',    7],
            ['ironmine',   8], ['ironmine',   9], ['ironmine',  10], ['ironmine',  11],
            ['cropland',  12], ['cropland',  13], ['cropland',  14], ['cropland',  15],
            ['cropland',  16], ['cropland',  17],
        ];
        foreach ($fields_data as [$type, $pos]) {
            try {
                db()->insert('resource_fields', [
                    'village_id' => $village_id,
                    'field_type' => $type,
                    'position'   => $pos,
                    'level'      => 0,
                ]);
            } catch (Throwable $e) {
                // Already exists — ignore
            }
        }
    }

    // --- Main building ---
    $main = db()->fetch(
        "SELECT id FROM buildings WHERE village_id = ? AND building_type = 'main_building'",
        [$village_id]
    );
    if (!$main) {
        try {
            db()->insert('buildings', [
                'village_id'    => $village_id,
                'position'      => 0,
                'building_type' => 'main_building',
                'level'         => 1,
            ]);
        } catch (Throwable $e) {
            // Already exists — ignore
        }
    }

    // Recalculate population after initialization
    recalculate_population($village_id);

    // Recalculate warehouse/granary capacity after initialization
    // (sets correct caps based on any existing warehouse/granary buildings;
    // if none exist yet, uses base_cap as default)
    recalculate_capacity($village_id);
}

// ---- Process build queue (finish items whose time has come) ----
function process_build_queue($village_id) {
    $now = date('Y-m-d H:i:s');
    $finished = db()->fetchAll(
        "SELECT * FROM build_queue WHERE village_id = ? AND finishes_at <= ? ORDER BY finishes_at ASC",
        [$village_id, $now]
    );
    foreach ($finished as $item) {
        if ($item['target_kind'] === 'field') {
            // Update resource_fields
            db()->query(
                "UPDATE resource_fields SET level = ? WHERE village_id = ? AND position = ?",
                [$item['target_level'], $village_id, $item['position']]
            );
        } else {
            // Update buildings
            $existing = db()->fetch(
                "SELECT id FROM buildings WHERE village_id = ? AND position = ?",
                [$village_id, $item['position']]
            );
            if ($existing) {
                db()->query(
                    "UPDATE buildings SET level = ?, building_type = ? WHERE id = ?",
                    [$item['target_level'], $item['target_type'], $existing['id']]
                );
            } else {
                db()->insert('buildings', [
                    'village_id' => $village_id,
                    'position' => $item['position'],
                    'building_type' => $item['target_type'],
                    'level' => $item['target_level'],
                ]);
            }
        }
        db()->query("DELETE FROM build_queue WHERE id = ?", [$item['id']]);

        // Recalculate population after each completed build
        recalculate_population($village_id);

        // Recalculate warehouse/granary capacity after each completed build
        // (in case a warehouse or granary was built/upgraded)
        recalculate_capacity($village_id);
    }

    // Also process training queue (troops)
    process_training_queue($village_id);

    // And process research queue (Academy)
    process_research_queue($village_id);

    // And process troop movements
    process_movements($village_id);

    // And process resource shipments (marketplace)
    process_resource_movements($village_id);
}

// ---- Recalculate village population based on fields + buildings ----
function recalculate_population($village_id) {
    global $BUILDING_POPULATION, $FIELD_POPULATION_PER_LEVEL;

    // Sum field levels × field population cost
    $field_pop = (int)db()->fetchColumn(
        "SELECT COALESCE(SUM(level * ?), 0) FROM resource_fields WHERE village_id = ?",
        [$FIELD_POPULATION_PER_LEVEL, $village_id]
    );

    // Sum building levels × building population cost
    $buildings = db()->fetchAll(
        "SELECT building_type, level FROM buildings WHERE village_id = ?",
        [$village_id]
    );
    $building_pop = 0;
    foreach ($buildings as $b) {
        $per_level = $BUILDING_POPULATION[$b['building_type']] ?? 1;
        $building_pop += $b['level'] * $per_level;
    }

    $total = $field_pop + $building_pop;

    // Update players table (population is stored per player, not per village — but we use player's first village here for simplicity)
    $village = db()->fetch("SELECT player_id FROM villages WHERE id = ?", [$village_id]);
    if ($village) {
        db()->query("UPDATE players SET population = ? WHERE id = ?", [$total, $village['player_id']]);
    }
    return $total;
}

// ---- Get current build queue ----
function get_build_queue($village_id) {
    return db()->fetchAll(
        "SELECT * FROM build_queue WHERE village_id = ? ORDER BY finishes_at ASC",
        [$village_id]
    );
}

// ---- Get current resource fields ----
function get_resource_fields($village_id) {
    return db()->fetchAll(
        "SELECT * FROM resource_fields WHERE village_id = ? ORDER BY position ASC",
        [$village_id]
    );
}

// ---- Get current buildings ----
function get_buildings($village_id) {
    return db()->fetchAll(
        "SELECT * FROM buildings WHERE village_id = ? ORDER BY position ASC",
        [$village_id]
    );
}

// ---- Calculate build cost ----
function calc_field_cost($field_type, $next_level) {
    global $FIELD_BASE_COST;
    $base = $FIELD_BASE_COST[$field_type] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
    return build_cost($base, $next_level);
}

function calc_building_cost($building_type, $next_level) {
    global $BUILDING_BASE_COST;
    $base = $BUILDING_BASE_COST[$building_type] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
    return build_cost($base, $next_level);
}

function calc_field_time($next_level, $main_building_level = 1) {
    global $FIELD_BASE_TIME;
    $base = $FIELD_BASE_TIME ?? 60;
    return build_time_seconds($base, $next_level, $main_building_level);
}

function calc_building_time($building_type, $next_level, $main_building_level = 1) {
    global $BUILDING_BASE_TIME;
    $base = $BUILDING_BASE_TIME[$building_type] ?? 600;
    return build_time_seconds($base, $next_level, $main_building_level);
}

// ---- Terrain generation for map ----
function terrain_for_cell($x, $y) {
    // Deterministic terrain based on coordinates
    $hash = crc32(serialize([$x, $y])) % 100;
    if ($hash < 50) return 'grass';
    if ($hash < 70) return 'forest';
    if ($hash < 85) return 'mountain';
    if ($hash < 95) return 'desert';
    return 'water';
}

// ---- Terrain descriptions / flavor text for cell.php ----
// Shown when the player inspects an empty (unoccupied) cell on the map.
$GLOBALS['TERRAIN_DESCRIPTIONS'] = [
    'grass' => [
        'name'    => 'Grassland',
        'short'   => 'A flat, fertile meadow — perfect for a new settlement.',
        'long'    => 'Endless rolling grass sways in the wind. The soil here is dark and rich, promising good harvests to anyone who tames this land. A few wild flowers dot the meadow, and the only sounds are crickets and distant birds. No one has claimed this valley yet.',
        'production_bonus' => '+15% crop production (if settled)',
    ],
    'forest' => [
        'name'    => 'Forest',
        'short'   => 'A dense woodland — source of timber and game.',
        'long'    => 'Tall pines and oaks crowd together, their canopy blocking most of the sunlight. Wild boar and deer roam freely here, and the forest floor is thick with fallen leaves and moss. Woodcutters would find endless work in these woods.',
        'production_bonus' => '+15% wood production (if settled)',
    ],
    'mountain' => [
        'name'    => 'Mountain',
        'short'   => 'A rocky mountain — rich in iron ore.',
        'long'    => 'Snow-capped peaks rise sharply against the sky. The slopes are treacherous, but experienced miners can see the dark veins of iron ore running through the rock. Mountain goats pick their way along narrow ledges, and the wind howls through the passes.',
        'production_bonus' => '+15% iron production (if settled)',
    ],
    'desert' => [
        'name'    => 'Desert',
        'short'   => 'A scorching desert — harsh, but rich in clay deposits.',
        'long'    => 'Rolling sand dunes stretch to the horizon. The midday sun beats down mercilessly, and the only shade comes from rare rock formations. Beneath the sand, layers of fine clay wait to be quarried. Few dare to settle here, but those who do become masters of the desert trade.',
        'production_bonus' => '+15% clay production (if settled)',
    ],
    'water' => [
        'name'    => 'Water',
        'short'   => 'A deep lake — impassable for settlers.',
        'long'    => 'Clear water reflects the sky, broken only by the gentle ripple of waves. Fish jump occasionally, and reeds grow thick along the shore. No village can be founded on water — but it makes a natural barrier against invaders, and fishermen from nearby villages sometimes cast their nets here.',
        'production_bonus' => 'Cannot be settled',
    ],
];

// Helper: get terrain description array for a cell
function terrain_description($x, $y) {
    $t = terrain_for_cell($x, $y);
    return $GLOBALS['TERRAIN_DESCRIPTIONS'][$t] ?? [
        'name' => 'Unknown', 'short' => '', 'long' => '', 'production_bonus' => ''
    ];
}


// ---- Format helpers ----
function format_seconds($sec) {
    $sec = (int)$sec;
    $h = intdiv($sec, 3600);
    $m = intdiv($sec % 3600, 60);
    $s = $sec % 60;
    if ($h > 0) return sprintf('%dh %02dm %02ds', $h, $m, $s);
    if ($m > 0) return sprintf('%dm %02ds', $m, $s);
    return sprintf('%ds', $s);
}

function format_number($n) {
    return number_format((int)$n, 0, ',', '.');
}

// Convert a 'Y-m-d H:i:s' string (in PHP timezone) to Unix epoch milliseconds.
// Used for data-finishes-at attributes so JS timers work regardless of browser timezone.
function js_timestamp($datetime_str) {
    if (!$datetime_str) return 0;
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $datetime_str);
    return $dt ? $dt->getTimestamp() * 1000 : 0;
}

// ---- Enqueue build ----
function enqueue_build($village_id, $kind, $target_type, $position, $target_level, $cost, $time_sec) {
    // Check queue size
    $queue_count = db()->fetchColumn(
        "SELECT COUNT(*) FROM build_queue WHERE village_id = ?",
        [$village_id]
    );
    if ($queue_count >= BUILD_QUEUE_SIZE) {
        return ['ok' => false, 'error' => 'Build queue is full'];
    }

    // For buildings, check prerequisites and uniqueness
    if ($kind === 'building') {
        // Prerequisites
        $prereq = check_building_prerequisites($target_type, $village_id);
        if (!$prereq['ok']) {
            return ['ok' => false, 'error' => $prereq['error']];
        }

        // Uniqueness: if this is a new building (target_level == 1) and it's a unique
        // building type, check that no other slot has the same type.
        // (If target_level > 1, this is an upgrade of an existing building — allow it.)
        if ($target_level === 1 && building_already_exists($target_type, $village_id, $position)) {
            $name = ucfirst(str_replace('_', ' ', $target_type));
            return ['ok' => false, 'error' => "You already have a $name in this village. Each village can have only one."];
        }

        // Check max level
        global $BUILDING_MAX_LEVEL;
        $max_level = $BUILDING_MAX_LEVEL[$target_type] ?? MAX_BUILDING_LEVEL;
        if ($target_level > $max_level) {
            return ['ok' => false, 'error' => 'Maximum level reached'];
        }
    }

    // Check resources
    $res = update_resources($village_id);
    foreach ($cost as $r => $amt) {
        if ($res[$r] < $amt) {
            return ['ok' => false, 'error' => 'Not enough ' . $r];
        }
    }

    // Deduct resources
    db()->update('resources', [
        'wood' => max(0, $res['wood'] - ($cost['wood'] ?? 0)),
        'clay' => max(0, $res['clay'] - ($cost['clay'] ?? 0)),
        'iron' => max(0, $res['iron'] - ($cost['iron'] ?? 0)),
        'crop' => max(0, $res['crop'] - ($cost['crop'] ?? 0)),
    ], 'village_id = :wv', ['wv' => $village_id]);

    // Compute finish time.
    // We use DateTime so the timestamp stays in PHP's configured timezone
    // (date_default_timezone_set in config.php) — this avoids strtotime()
    // misinterpreting the stored string as UTC.
    $last = db()->fetchColumn(
        "SELECT MAX(finishes_at) FROM build_queue WHERE village_id = ?",
        [$village_id]
    );
    $now_ts = time();
    if ($last) {
        // Parse stored timestamp as a wall-clock time in the current PHP timezone.
        $last_dt = DateTime::createFromFormat('Y-m-d H:i:s', $last);
        $base = $last_dt ? max($last_dt->getTimestamp(), $now_ts) : $now_ts;
    } else {
        $base = $now_ts;
    }
    $finishes = date('Y-m-d H:i:s', $base + $time_sec);

    db()->insert('build_queue', [
        'village_id' => $village_id,
        'target_kind' => $kind,
        'target_type' => $target_type,
        'position' => $position,
        'target_level' => $target_level,
        'finishes_at' => $finishes,
    ]);

    return ['ok' => true];
}

// ============================================================
// ACADEMY — troop research queue
// ============================================================
// Research is per-VILLAGE (each Academy conducts its own research).
// A unit that has been researched in village A is NOT automatically
// available in village B — each village must research its own troops.
//
// Two persistence tables:
//   - research_queue : in-progress research projects (one row per project)
//   - unit_research  : completed research (one row per researched unit_type
//                      per village). Used as a fast lookup to check whether
//                      a unit is unlocked for training.

function get_research_queue($village_id) {
    return db()->fetchAll(
        "SELECT * FROM research_queue WHERE village_id = ? ORDER BY finishes_at ASC",
        [$village_id]
    );
}

// Get all unit_types that have been fully researched in this village.
// Returns associative array: [unit_type => true, ...]
function get_researched_units($village_id) {
    static $cache = [];
    if (isset($cache[$village_id])) return $cache[$village_id];
    try {
        $rows = db()->fetchAll(
            "SELECT unit_type FROM unit_research WHERE village_id = ?",
            [$village_id]
        );
    } catch (Throwable $e) {
        // Table might not exist yet (before migration) — treat as empty.
        $rows = [];
    }
    $cache[$village_id] = [];
    foreach ($rows as $r) $cache[$village_id][$r['unit_type']] = true;
    return $cache[$village_id];
}

// Boolean: has this village researched the given unit_type?
function is_unit_researched($village_id, $unit_type) {
    $researched = get_researched_units($village_id);
    return !empty($researched[$unit_type]);
}

// Check whether a unit can be trained in the village right now.
// Returns ['ok' => true] or ['ok' => false, 'error' => '...', 'reason' => 'research'|'building'|'invalid'].
//
// Per spec: troop training happens ONLY inside buildings. Each military
// building trains a specific category of units:
//   - barracks  → infantry
//   - stable    → cavalry
//   - workshop  → siege engines (ram, catapult/trebuchet)
//   - residence → colonists (settlers)
//
// This function uses the $BUILDING_UNITS map (config.php) to look up which
// building trains a given unit_type. It also accepts an optional
// $building_type parameter — when set, the function additionally verifies
// that the unit is trainable in THAT specific building (used by building.php
// to ensure POSTs come from the correct building page).
function check_unit_training_eligibility($village_id, $unit_type, $player = null, $building_type = null) {
    if (!$player) $player = current_player();
    if (!$player) return ['ok' => false, 'error' => 'Not logged in', 'reason' => 'invalid'];
    $tribe = $player['tribe'];

    // Look up the unit's stats (works for tribe units + colonist).
    $stats = get_unit_stats($unit_type);
    if (!$stats) {
        return ['ok' => false, 'error' => 'Unknown unit type: ' . $unit_type, 'reason' => 'invalid'];
    }

    // Determine which building trains this unit.
    $required_building = building_for_unit($unit_type);
    if (!$required_building) {
        return ['ok' => false, 'error' => 'No building trains this unit.', 'reason' => 'invalid'];
    }

    // If called from a specific building page, verify the unit belongs to it.
    if ($building_type !== null && $building_type !== $required_building) {
        return [
            'ok' => false,
            'error' => 'This unit is trained at the ' . ucfirst($required_building) . ', not here.',
            'reason' => 'invalid',
        ];
    }

    // Check the required building exists at level ≥ 1.
    $buildings = get_buildings($village_id);
    $required_level = 0;
    foreach ($buildings as $b) {
        if ($b['building_type'] === $required_building) {
            $required_level = max($required_level, (int)$b['level']);
        }
    }
    if ($required_level < 1) {
        return [
            'ok' => false,
            'error' => 'You need a ' . ucfirst($required_building) . ' to train this unit.',
            'reason' => 'building',
        ];
    }

    // Colonists don't require Academy research — they're always available
    // once you have a Residence. Skip the research gate for them.
    if ($unit_type !== 'colonist') {
        // If this unit requires Academy research, check it has been researched.
        if (unit_requires_research($tribe, $unit_type)) {
            if (!is_unit_researched($village_id, $unit_type)) {
                return [
                    'ok' => false,
                    'error' => ucfirst(str_replace('_',' ',$unit_type)) . ' must be researched at the Academy before it can be trained.',
                    'reason' => 'research',
                ];
            }
        }
    }

    return ['ok' => true, 'required_building' => $required_building, 'building_level' => $required_level];
}

// Check the prerequisites for researching a unit at the Academy.
// Returns ['ok' => true] or ['ok' => false, 'error' => '...', 'missing' => [...]].
function check_unit_research_prerequisites($village_id, $unit_type, $player = null) {
    global $UNIT_RESEARCH_CONFIG, $UNITS;
    if (!$player) $player = current_player();
    if (!$player) return ['ok' => false, 'error' => 'Not logged in'];
    $tribe = $player['tribe'];

    // Validate unit belongs to this tribe and requires research
    if (!isset($UNITS[$tribe][$unit_type])) {
        return ['ok' => false, 'error' => 'Invalid unit for your tribe'];
    }
    if (!unit_requires_research($tribe, $unit_type)) {
        return ['ok' => false, 'error' => 'This unit does not require research.'];
    }
    $cfg = $UNIT_RESEARCH_CONFIG[$unit_type] ?? null;
    if (!$cfg) return ['ok' => false, 'error' => 'Research not configured for this unit.'];

    // Academy must exist at the required level
    $academy_level = 0;
    foreach (get_buildings($village_id) as $b) {
        if ($b['building_type'] === 'academy') $academy_level = max($academy_level, (int)$b['level']);
    }
    if ($academy_level < 1) {
        return ['ok' => false, 'error' => 'You need an Academy to conduct research.'];
    }
    if ($academy_level < $cfg['academy_level']) {
        return ['ok' => false, 'error' => 'Academy level ' . $cfg['academy_level'] . ' required (you have ' . $academy_level . ').'];
    }

    // Already researched?
    if (is_unit_researched($village_id, $unit_type)) {
        return ['ok' => false, 'error' => 'This unit has already been researched.'];
    }

    // Already in the research queue?
    $in_queue = db()->fetch(
        "SELECT id FROM research_queue WHERE village_id = ? AND unit_type = ?",
        [$village_id, $unit_type]
    );
    if ($in_queue) {
        return ['ok' => false, 'error' => 'This unit is already being researched.'];
    }

    // Required prior research
    $missing = [];
    foreach ($cfg['requires'] as $req_unit) {
        if (!is_unit_researched($village_id, $req_unit)) {
            $missing[] = ucfirst(str_replace('_',' ',$req_unit));
        }
    }
    if (!empty($missing)) {
        return ['ok' => false, 'error' => 'Missing prerequisite research: ' . implode(', ', $missing), 'missing' => $missing];
    }

    return ['ok' => true, 'academy_level' => $academy_level];
}

// Enqueue a research project for a unit at the Academy.
// Returns ['ok' => true] or ['ok' => false, 'error' => '...'].
function enqueue_research($village_id, $unit_type) {
    global $UNIT_RESEARCH_CONFIG;
    $player = current_player();
    if (!$player) return ['ok' => false, 'error' => 'Not logged in'];
    $tribe = $player['tribe'];

    // Validate
    if (!isset($UNIT_RESEARCH_CONFIG[$unit_type])) {
        return ['ok' => false, 'error' => 'Invalid research target.'];
    }

    // Check prerequisites (academy level, prior research, not already done)
    $check = check_unit_research_prerequisites($village_id, $unit_type, $player);
    if (!$check['ok']) return $check;
    $academy_level = $check['academy_level'];

    // Check resources
    $cost = $UNIT_RESEARCH_CONFIG[$unit_type]['cost'];
    $res = update_resources($village_id);
    foreach (['wood','clay','iron','crop'] as $r) {
        if ($res[$r] < $cost[$r]) {
            return ['ok' => false, 'error' => 'Not enough ' . $r];
        }
    }

    // Deduct resources
    db()->update('resources', [
        'wood'  => max(0, $res['wood']  - $cost['wood']),
        'clay'  => max(0, $res['clay']  - $cost['clay']),
        'iron'  => max(0, $res['iron']  - $cost['iron']),
        'crop'  => max(0, $res['crop']  - $cost['crop']),
    ], 'village_id = :wv', ['wv' => $village_id]);

    // Compute finish time (chain after last research in this village)
    $base_time = $UNIT_RESEARCH_CONFIG[$unit_type]['time'];
    $time_sec  = research_time_seconds($base_time, $academy_level);

    $last = db()->fetchColumn(
        "SELECT MAX(finishes_at) FROM research_queue WHERE village_id = ?",
        [$village_id]
    );
    $now_ts = time();
    if ($last) {
        $last_dt = DateTime::createFromFormat('Y-m-d H:i:s', $last);
        $base = $last_dt ? max($last_dt->getTimestamp(), $now_ts) : $now_ts;
    } else {
        $base = $now_ts;
    }
    $finishes = date('Y-m-d H:i:s', $base + $time_sec);

    db()->insert('research_queue', [
        'village_id'  => $village_id,
        'unit_type'   => $unit_type,
        'finishes_at' => $finishes,
    ]);

    // NOTE: No report is created for research start/complete — only attack,
    // defense, and resource-sending reports are kept to minimise SQL load.
    // The player can see research progress directly on the Academy page.

    return ['ok' => true, 'finishes_at' => $finishes];
}

// Process the research queue — complete any finished projects.
function process_research_queue($village_id) {
    $now = date('Y-m-d H:i:s');
    try {
        $finished = db()->fetchAll(
            "SELECT * FROM research_queue WHERE village_id = ? AND finishes_at <= ? ORDER BY finishes_at ASC",
            [$village_id, $now]
        );
    } catch (Throwable $e) {
        return; // table might not exist yet
    }
    foreach ($finished as $item) {
        // Mark the unit as researched (insert into unit_research, ignore duplicates)
        try {
            db()->insert('unit_research', [
                'village_id' => $village_id,
                'unit_type'  => $item['unit_type'],
            ]);
        } catch (Throwable $e) {
            // Already exists — fine
        }
        // Remove from queue
        db()->query("DELETE FROM research_queue WHERE id = ?", [$item['id']]);
        // NOTE: No report — research completion is visible on the Academy page.
    }
}

// Get the current Academy level for a village (0 if not built).
function get_academy_level($village_id) {
    $level = 0;
    foreach (get_buildings($village_id) as $b) {
        if ($b['building_type'] === 'academy') $level = max($level, (int)$b['level']);
    }
    return $level;
}

// ============================================================
// TROOP TRAINING QUEUE
// ============================================================

function get_training_queue($village_id) {
    return db()->fetchAll(
        "SELECT * FROM training_queue WHERE village_id = ? ORDER BY finishes_at ASC",
        [$village_id]
    );
}

function process_training_queue($village_id) {
    $now = date('Y-m-d H:i:s');
    $finished = db()->fetchAll(
        "SELECT * FROM training_queue WHERE village_id = ? AND finishes_at <= ? ORDER BY finishes_at ASC",
        [$village_id, $now]
    );
    foreach ($finished as $item) {
        // Add troops to village
        $existing = db()->fetch(
            "SELECT id, count FROM troops WHERE village_id = ? AND unit_type = ?",
            [$village_id, $item['unit_type']]
        );
        if ($existing) {
            db()->query(
                "UPDATE troops SET count = count + ? WHERE id = ?",
                [$item['count'], $existing['id']]
            );
        } else {
            db()->insert('troops', [
                'village_id' => $village_id,
                'unit_type'  => $item['unit_type'],
                'count'      => $item['count'],
            ]);
        }
        db()->query("DELETE FROM training_queue WHERE id = ?", [$item['id']]);
    }
}

// Enqueue training of N units of a type.
// Returns ['ok' => true] or ['ok' => false, 'error' => '...'].
//
// $building_type — optional. When set, the unit must be trainable at that
// building (validated by check_unit_training_eligibility). This is how
// building.php ensures a POST from the Barracks can't train cavalry, etc.
function enqueue_training($village_id, $unit_type, $count, $building_level = 1, $building_type = null) {
    global $UNIT_TRAIN_TIME;
    $player = current_player();
    if (!$player) return ['ok' => false, 'error' => 'Not logged in'];

    // Look up unit stats (handles tribe units + colonist).
    $unit = get_unit_stats($unit_type);
    if (!$unit) {
        return ['ok' => false, 'error' => 'Invalid unit type'];
    }

    // ---- Eligibility gate ----
    // Validates: unit exists, belongs to a building, building exists at level ≥ 1,
    // Academy research completed (for non-colonist units), and (if $building_type
    // is passed) that the unit belongs to THAT specific building.
    $eligibility = check_unit_training_eligibility($village_id, $unit_type, $player, $building_type);
    if (!$eligibility['ok']) {
        return ['ok' => false, 'error' => $eligibility['error'], 'reason' => $eligibility['reason'] ?? 'invalid'];
    }
    // Use the real building level from eligibility check (more reliable than caller-provided).
    $building_level = $eligibility['building_level'];

    $count = max(1, (int)$count);
    $base_time = $UNIT_TRAIN_TIME[$unit_type] ?? 240;
    $per_unit_time = training_time_seconds($base_time, $building_level);
    $total_time = $per_unit_time * $count;

    // Check resources
    $res = update_resources($village_id);
    $cost = [];
    foreach (['wood','clay','iron','crop'] as $r) {
        $cost[$r] = ($unit['cost'][$r] ?? 0) * $count;
        if ($res[$r] < $cost[$r]) {
            return ['ok' => false, 'error' => 'Not enough ' . $r];
        }
    }

    // Deduct
    db()->update('resources', [
        'wood' => max(0, $res['wood'] - $cost['wood']),
        'clay' => max(0, $res['clay'] - $cost['clay']),
        'iron' => max(0, $res['iron'] - $cost['iron']),
        'crop' => max(0, $res['crop'] - $cost['crop']),
    ], 'village_id = :wv', ['wv' => $village_id]);

    // Compute finish time (chain after last training in this village)
    $last = db()->fetchColumn(
        "SELECT MAX(finishes_at) FROM training_queue WHERE village_id = ?",
        [$village_id]
    );
    $now_ts = time();
    if ($last) {
        $last_dt = DateTime::createFromFormat('Y-m-d H:i:s', $last);
        $base = $last_dt ? max($last_dt->getTimestamp(), $now_ts) : $now_ts;
    } else {
        $base = $now_ts;
    }
    $finishes = date('Y-m-d H:i:s', $base + $total_time);

    db()->insert('training_queue', [
        'village_id'  => $village_id,
        'unit_type'   => $unit_type,
        'count'       => $count,
        'finishes_at' => $finishes,
    ]);

    return ['ok' => true];
}

// ============================================================
// TROOP MOVEMENTS (attacks + reinforcements)
// ============================================================

function get_village_troops($village_id) {
    return db()->fetchAll(
        "SELECT * FROM troops WHERE village_id = ? AND count > 0 ORDER BY unit_type",
        [$village_id]
    );
}

function get_movements($village_id) {
    // Outgoing + incoming (only in-progress — completed ones are hidden)
    $outgoing = db()->fetchAll(
        "SELECT m.*, v.name AS target_name, p.username AS target_player
         FROM movements m
         JOIN villages v ON v.id = m.to_village_id
         JOIN players p ON p.id = v.player_id
         WHERE m.from_village_id = ? AND m.status = 'in_progress'
         ORDER BY m.arrives_at ASC",
        [$village_id]
    );
    $incoming = db()->fetchAll(
        "SELECT m.*, v.name AS source_name, p.username AS source_player
         FROM movements m
         JOIN villages v ON v.id = m.from_village_id
         JOIN players p ON p.id = v.player_id
         WHERE m.to_village_id = ? AND m.status = 'in_progress'
         ORDER BY m.arrives_at ASC",
        [$village_id]
    );
    return ['outgoing' => $outgoing, 'incoming' => $incoming];
}

function process_movements($village_id) {
    $now = date('Y-m-d H:i:s');
    // Find all movements that have arrived (limited to this village as source or target)
    try {
        $arrived = db()->fetchAll(
            "SELECT * FROM movements
             WHERE (from_village_id = ? OR to_village_id = ?)
             AND arrives_at <= ? AND status = 'in_progress'
             ORDER BY arrives_at ASC",
            [$village_id, $village_id, $now]
        );
    } catch (Throwable $e) {
        // If the movements table is corrupt or missing, skip processing
        // rather than crashing the entire page.
        return;
    }
    foreach ($arrived as $move) {
        try {
            // Validate type field — skip invalid records
            if (!in_array($move['type'], ['attack', 'reinforcement', 'return'], true)) {
                // Delete the invalid record so it doesn't keep causing errors
                db()->query("DELETE FROM movements WHERE id = ?", [$move['id']]);
                continue;
            }
            // Decode troops JSON
            $troops = json_decode($move['troops_json'], true) ?: [];
            if ($move['type'] === 'attack') {
            // Simple resolution: attacker wins if total attack > defender's total defense
            // For now: just send all attackers home with whatever survives (50%)
            // and add 50% of defender losses.
            $defender_troops = get_village_troops($move['to_village_id']);
            // Resolve combat (very simplified)
            $attacker_power = 0;
            foreach ($troops as $type => $n) {
                $stats = find_unit_stats($type);
                $attacker_power += $stats['attack'] * $n;
            }
            $defender_power = 0;
            foreach ($defender_troops as $dt) {
                $stats = find_unit_stats($dt['unit_type']);
                $defender_power += $stats['def_inf'] * $dt['count'];
            }
            // Winner keeps 50%, loser loses all
            if ($attacker_power > $defender_power) {
                // Attacker wins — return with 50% troops, steal loot
                $survivors = [];
                $total_carry = 0;
                foreach ($troops as $type => $n) {
                    $survivors[$type] = (int)ceil($n * 0.5);
                    // Add carry capacity of survivors
                    $carry_per_unit = $GLOBALS['UNIT_CARRY_CAPACITY'][$type] ?? 0;
                    $total_carry += $survivors[$type] * $carry_per_unit;
                }

                // Get attacker's tribe for loot multiplier
                $from_vil_tribe = db()->fetch(
                    "SELECT p.tribe FROM villages v JOIN players p ON p.id = v.player_id WHERE v.id = ?",
                    [$move['from_village_id']]
                );
                $tribe = $from_vil_tribe['tribe'] ?? 'roman';
                $loot_mult = $GLOBALS['TRIBE_LOOT_MULTIPLIER'][$tribe] ?? 0.7;
                $max_loot = (int)round($total_carry * $loot_mult);

                // Steal resources up to max_loot total, distributed evenly
                $res = update_resources($move['to_village_id']);
                $available = $res['wood'] + $res['clay'] + $res['iron'] + $res['crop'];
                $actual_loot_total = min($max_loot, $available);

                if ($actual_loot_total > 0 && $available > 0) {
                    $ratio = $actual_loot_total / $available;
                    $loot = [
                        'wood' => floor($res['wood'] * $ratio),
                        'clay' => floor($res['clay'] * $ratio),
                        'iron' => floor($res['iron'] * $ratio),
                        'crop' => floor($res['crop'] * $ratio),
                    ];
                } else {
                    $loot = ['wood' => 0, 'clay' => 0, 'iron' => 0, 'crop' => 0];
                }

                db()->update('resources', [
                    'wood' => max(0, $res['wood'] - $loot['wood']),
                    'clay' => max(0, $res['clay'] - $loot['clay']),
                    'iron' => max(0, $res['iron'] - $loot['iron']),
                    'crop' => max(0, $res['crop'] - $loot['crop']),
                ], 'village_id = :wv', ['wv' => $move['to_village_id']]);
                // Remove all defender troops (they lost)
                db()->query("DELETE FROM troops WHERE village_id = ?", [$move['to_village_id']]);
                // Create return movement
                // Use DateTime for correct timezone handling
                $start_dt = DateTime::createFromFormat('Y-m-d H:i:s', $move['started_at']);
                $arrive_dt = DateTime::createFromFormat('Y-m-d H:i:s', $move['arrives_at']);
                $travel_time = $start_dt && $arrive_dt
                    ? $arrive_dt->getTimestamp() - $start_dt->getTimestamp()
                    : 60;  // fallback
                $return_at = date('Y-m-d H:i:s', time() + $travel_time);
                db()->insert('movements', [
                    'from_village_id' => $move['to_village_id'],
                    'to_village_id'   => $move['from_village_id'],
                    'type'            => 'return',
                    'troops_json'     => json_encode($survivors),
                    'loot_json'       => json_encode($loot),
                    'started_at'      => $now,
                    'arrives_at'      => $return_at,
                    'status'          => 'in_progress',
                ]);
                // Send report to attacker
                $from_vil = db()->fetch("SELECT player_id, name, x, y FROM villages WHERE id = ?", [$move['from_village_id']]);
                $to_vil   = db()->fetch("SELECT player_id, name, x, y FROM villages WHERE id = ?", [$move['to_village_id']]);
                $loot_total = $loot['wood'] + $loot['clay'] + $loot['iron'] + $loot['crop'];
                $attacker_player = db()->fetch("SELECT username FROM players WHERE id = ?", [$from_vil['player_id']]);

                $body  = "⚔️  RAID SUCCESS\n";
                $body .= "═══════════════════════════════\n\n";
                $body .= "Target village : {$to_vil['name']} ({$to_vil['x']}|{$to_vil['y']})\n";
                $body .= "Attacker       : {$attacker_player['username']} ({$tribe})\n";
                $body .= "Loot bonus     : " . ($loot_mult * 100) . "%\n\n";
                $body .= "─── Battle ───\n";
                $body .= "Attacker power : {$attacker_power}\n";
                $body .= "Defender power : {$defender_power}\n";
                $body .= "Result         : VICTORY — 50% of troops survived\n\n";
                $body .= "─── Looted ───\n";
                $body .= format_resources_block($loot['wood'], $loot['clay'], $loot['iron'], $loot['crop']);
                $body .= "\n\nYour surviving troops are returning home with the loot.";

                db()->insert('reports', [
                    'player_id' => $from_vil['player_id'],
                    'title'     => '⚔️ Victory at ' . $to_vil['name'],
                    'body'      => $body,
                    'category'  => 'combat',
                ]);
                if ($to_vil['player_id'] != $from_vil['player_id']) {
                    $body2  = "🛡️  VILLAGE ATTACKED\n";
                    $body2 .= "═══════════════════════════════\n\n";
                    $body2 .= "Your village   : {$to_vil['name']} ({$to_vil['x']}|{$to_vil['y']})\n";
                    $body2 .= "Attacker       : {$attacker_player['username']} ({$tribe})\n\n";
                    $body2 .= "─── Battle ───\n";
                    $body2 .= "Attacker power : {$attacker_power}\n";
                    $body2 .= "Defender power : {$defender_power}\n";
                    $body2 .= "Result         : DEFEAT — all defending troops perished\n\n";
                    $body2 .= "─── Resources stolen ───\n";
                    $body2 .= format_resources_block($loot['wood'], $loot['clay'], $loot['iron'], $loot['crop']);
                    $body2 .= "\n\nRebuild your defenses and consider asking allies for reinforcements.";

                    db()->insert('reports', [
                        'player_id' => $to_vil['player_id'],
                        'title'     => '🛡️ Defeat at ' . $to_vil['name'],
                        'body'      => $body2,
                        'category'  => 'combat',
                    ]);
                }
            } else {
                // Defender wins — all attackers die
                // Remove all attacker troops (they were already removed when movement started)
                // Defender keeps 50%
                foreach ($defender_troops as $dt) {
                    $survivors = (int)ceil($dt['count'] * 0.5);
                    db()->query("UPDATE troops SET count = ? WHERE id = ?", [$survivors, $dt['id']]);
                }
                $from_vil = db()->fetch("SELECT player_id, name, x, y FROM villages WHERE id = ?", [$move['from_village_id']]);
                $to_vil   = db()->fetch("SELECT player_id, name, x, y FROM villages WHERE id = ?", [$move['to_village_id']]);
                $attacker_player = db()->fetch("SELECT username, tribe FROM players WHERE id = ?", [$from_vil['player_id']]);

                // Report to attacker: raid failed
                $body  = "⚔️  RAID FAILED\n";
                $body .= "═══════════════════════════════\n\n";
                $body .= "Target village : {$to_vil['name']} ({$to_vil['x']}|{$to_vil['y']})\n\n";
                $body .= "─── Battle ───\n";
                $body .= "Attacker power : {$attacker_power}\n";
                $body .= "Defender power : {$defender_power}\n";
                $body .= "Result         : DEFEAT — all attacking troops perished\n\n";
                $body .= "No loot was gained. Better luck next time.";

                db()->insert('reports', [
                    'player_id' => $from_vil['player_id'],
                    'title'     => '💀 Defeat at ' . $to_vil['name'],
                    'body'      => $body,
                    'category'  => 'combat',
                ]);
                if ($to_vil['player_id'] != $from_vil['player_id']) {
                    // Report to defender: village defended
                    $body2  = "🛡️  VILLAGE DEFENDED\n";
                    $body2 .= "═══════════════════════════════\n\n";
                    $body2 .= "Your village   : {$to_vil['name']} ({$to_vil['x']}|{$to_vil['y']})\n";
                    $body2 .= "Attacker       : {$attacker_player['username']} ({$attacker_player['tribe']})\n\n";
                    $body2 .= "─── Battle ───\n";
                    $body2 .= "Attacker power : {$attacker_power}\n";
                    $body2 .= "Defender power : {$defender_power}\n";
                    $body2 .= "Result         : VICTORY — 50% of defending troops survived\n\n";
                    $body2 .= "No resources were lost. The attacker fled empty-handed.";

                    db()->insert('reports', [
                        'player_id' => $to_vil['player_id'],
                        'title'     => '🛡️ Defense of ' . $to_vil['name'],
                        'body'      => $body2,
                        'category'  => 'combat',
                    ]);
                }
            }
        } elseif ($move['type'] === 'reinforcement') {
            // Add troops to target village
            foreach ($troops as $type => $n) {
                $existing = db()->fetch(
                    "SELECT id, count FROM troops WHERE village_id = ? AND unit_type = ?",
                    [$move['to_village_id'], $type]
                );
                if ($existing) {
                    db()->query("UPDATE troops SET count = count + ? WHERE id = ?", [$n, $existing['id']]);
                } else {
                    db()->insert('troops', [
                        'village_id' => $move['to_village_id'],
                        'unit_type'  => $type,
                        'count'      => $n,
                    ]);
                }
            }
        } elseif ($move['type'] === 'return') {
            // Troops come home; add loot to source village (capped at warehouse/granary capacity)
            $loot = json_decode($move['loot_json'] ?? '{}', true) ?: [];
            $res = update_resources($move['to_village_id']);
            db()->update('resources', [
                'wood' => min($res['wood_cap'], $res['wood'] + ($loot['wood'] ?? 0)),
                'clay' => min($res['clay_cap'], $res['clay'] + ($loot['clay'] ?? 0)),
                'iron' => min($res['iron_cap'], $res['iron'] + ($loot['iron'] ?? 0)),
                'crop' => min($res['crop_cap'], $res['crop'] + ($loot['crop'] ?? 0)),
            ], 'village_id = :wv', ['wv' => $move['to_village_id']]);
            // Add troops back
            foreach ($troops as $type => $n) {
                $existing = db()->fetch(
                    "SELECT id, count FROM troops WHERE village_id = ? AND unit_type = ?",
                    [$move['to_village_id'], $type]
                );
                if ($existing) {
                    db()->query("UPDATE troops SET count = count + ? WHERE id = ?", [$n, $existing['id']]);
                } else {
                    db()->insert('troops', [
                        'village_id' => $move['to_village_id'],
                        'unit_type'  => $type,
                        'count'      => $n,
                    ]);
                }
            }
        }
        // Mark movement as completed
        db()->query("UPDATE movements SET status = 'completed' WHERE id = ?", [$move['id']]);
        } catch (Throwable $e) {
            // If processing a single movement fails (e.g. invalid data,
            // missing village reference), delete the broken record and
            // continue processing the rest rather than crashing the page.
            db()->query("DELETE FROM movements WHERE id = ?", [$move['id']]);
        }
    }
}

function find_unit_stats($unit_type) {
    // Delegate to the new helper (defined in config.php) which handles
    // both tribe-specific units AND the shared 'colonist' unit.
    return get_unit_stats($unit_type) ?: ['attack' => 0, 'def_inf' => 0, 'def_cav' => 0, 'speed' => 6];
}

// Send a movement (attack or reinforcement) from one village to another.
function send_movement($from_village_id, $to_x, $to_y, $type, $troops_to_send) {
    global $UNITS, $UNIT_TRAIN_TIME;

    // Find target village
    $target = db()->fetch("SELECT * FROM villages WHERE x = ? AND y = ?", [$to_x, $to_y]);
    if (!$target) return ['ok' => false, 'error' => 'No village at those coordinates'];

    // Validate troops and calculate speed (slowest unit)
    $source = db()->fetch("SELECT * FROM villages WHERE id = ?", [$from_village_id]);
    $player = db()->fetch("SELECT * FROM players WHERE id = ?", [$source['player_id']]);
    $tribe = $player['tribe'];

    $slowest_speed = PHP_INT_MAX;
    $troops_json = [];
    $total_troops = 0;
    foreach ($troops_to_send as $unit_type => $n) {
        $n = (int)$n;
        if ($n <= 0) continue;
        $stats = find_unit_stats($unit_type);
        if (!$stats) return ['ok' => false, 'error' => 'Unknown unit: ' . $unit_type];
        // Check we have this many
        $have = db()->fetch(
            "SELECT count FROM troops WHERE village_id = ? AND unit_type = ?",
            [$from_village_id, $unit_type]
        );
        if (!$have || $have['count'] < $n) {
            return ['ok' => false, 'error' => 'Not enough ' . $unit_type . ' (have ' . ($have['count'] ?? 0) . ', want ' . $n . ')'];
        }
        $slowest_speed = min($slowest_speed, $stats['speed']);
        $troops_json[$unit_type] = $n;
        $total_troops += $n;
    }
    if ($total_troops === 0) return ['ok' => false, 'error' => 'No troops selected'];

    // Deduct troops from source village
    foreach ($troops_json as $unit_type => $n) {
        db()->query(
            "UPDATE troops SET count = count - ? WHERE village_id = ? AND unit_type = ?",
            [$n, $from_village_id, $unit_type]
        );
        // Delete rows with 0 count in THIS village only to keep table clean
        db()->query("DELETE FROM troops WHERE village_id = ? AND count <= 0", [$from_village_id]);
    }

    // Calculate travel time
    $dist = distance_between($source['x'], $source['y'], $to_x, $to_y);
    $travel = movement_time_seconds($dist, $slowest_speed);

    $now_ts = time();
    $started = date('Y-m-d H:i:s', $now_ts);
    $arrives = date('Y-m-d H:i:s', $now_ts + $travel);

    db()->insert('movements', [
        'from_village_id' => $from_village_id,
        'to_village_id'   => $target['id'],
        'type'            => $type,  // 'attack' or 'reinforcement'
        'troops_json'     => json_encode($troops_json),
        'loot_json'       => '{}',
        'started_at'      => $started,
        'arrives_at'      => $arrives,
        'status'          => 'in_progress',
    ]);

    // NOTE: No "attack sent" or "incoming attack warning" reports are created
    // here. Per spec, reports are ONLY generated when an action RESOLVES —
    // the player sees outgoing/incoming movements on their Troops page
    // (Active Movements panel). Only the post-battle report (victory or
    // defeat, generated by process_movements when the attack lands) is kept.

    return ['ok' => true, 'arrives_at' => $arrives];
}

// ============================================================
// RESOURCE MOVEMENTS (Marketplace trades)
// ============================================================

function get_resource_movements($village_id) {
    $outgoing = db()->fetchAll(
        "SELECT rm.*, v.name AS target_name, p.username AS target_player
         FROM resource_movements rm
         JOIN villages v ON v.id = rm.to_village_id
         JOIN players p ON p.id = v.player_id
         WHERE rm.from_village_id = ? AND rm.status = 'in_progress'
         ORDER BY rm.arrives_at ASC",
        [$village_id]
    );
    $incoming = db()->fetchAll(
        "SELECT rm.*, v.name AS source_name, p.username AS source_player
         FROM resource_movements rm
         JOIN villages v ON v.id = rm.from_village_id
         JOIN players p ON p.id = v.player_id
         WHERE rm.to_village_id = ? AND rm.status = 'in_progress'
         ORDER BY rm.arrives_at ASC",
        [$village_id]
    );
    return ['outgoing' => $outgoing, 'incoming' => $incoming];
}

function process_resource_movements($village_id) {
    $now = date('Y-m-d H:i:s');
    $arrived = db()->fetchAll(
        "SELECT * FROM resource_movements
         WHERE (from_village_id = ? OR to_village_id = ?)
         AND arrives_at <= ? AND status = 'in_progress'
         ORDER BY arrives_at ASC",
        [$village_id, $village_id, $now]
    );
    foreach ($arrived as $ship) {
        // Add resources to target village (capped at warehouse/granary capacity)
        $res = update_resources($ship['to_village_id']);
        db()->update('resources', [
            'wood' => min($res['wood_cap'], $res['wood'] + $ship['wood']),
            'clay' => min($res['clay_cap'], $res['clay'] + $ship['clay']),
            'iron' => min($res['iron_cap'], $res['iron'] + $ship['iron']),
            'crop' => min($res['crop_cap'], $res['crop'] + $ship['crop']),
        ], 'village_id = :wv', ['wv' => $ship['to_village_id']]);
        db()->query("UPDATE resource_movements SET status = 'completed' WHERE id = ?", [$ship['id']]);

        // Send "resources arrived" report to receiver (always — even for self-sends)
        $to_vil = db()->fetch("SELECT player_id, name, x, y FROM villages WHERE id = ?", [$ship['to_village_id']]);
        $from_vil = db()->fetch("SELECT player_id, name FROM villages WHERE id = ?", [$ship['from_village_id']]);
        $total = $ship['wood'] + $ship['clay'] + $ship['iron'] + $ship['crop'];

        if ($to_vil) {
            $is_self = ($to_vil['player_id'] == $from_vil['player_id']);
            $body  = "📦  RESOURCES ARRIVED\n";
            $body .= "═══════════════════════════════\n\n";
            $body .= "Your village   : {$to_vil['name']} ({$to_vil['x']}|{$to_vil['y']})\n";
            $body .= "From           : {$from_vil['name']}";
            if ($is_self) $body .= " (your own village)";
            $body .= "\n\n";
            $body .= "─── Resources received ───\n";
            $body .= format_resources_block($ship['wood'], $ship['clay'], $ship['iron'], $ship['crop']);
            $body .= "\n\nResources have been added to your warehouse/granary.";

            db()->insert('reports', [
                'player_id' => $to_vil['player_id'],
                'title'     => '📦 Resources arrived at ' . $to_vil['name'],
                'body'      => $body,
                'category'  => 'trade',
            ]);
        }
    }
}

// Send resources from one village to another via marketplace.
// Returns ['ok' => true] or ['ok' => false, 'error' => '...']
function send_resources($from_village_id, $to_village_id, $wood, $clay, $iron, $crop) {
    global $MARKETPLACE_MERCHANTS_PER_LEVEL, $MARKETPLACE_MERCHANT_CAPACITY;

    // Find marketplace level in source village
    $buildings = get_buildings($from_village_id);
    $market_level = 0;
    foreach ($buildings as $b) {
        if ($b['building_type'] === 'marketplace') $market_level = max($market_level, (int)$b['level']);
    }
    if ($market_level < 1) {
        return ['ok' => false, 'error' => 'You need a Marketplace to send resources.'];
    }

    $wood = max(0, (int)$wood);
    $clay = max(0, (int)$clay);
    $iron = max(0, (int)$iron);
    $crop = max(0, (int)$crop);
    $total = $wood + $clay + $iron + $crop;
    if ($total <= 0) {
        return ['ok' => false, 'error' => 'No resources selected to send.'];
    }

    // Check merchant capacity
    $merchants_have = merchants_available($market_level);
    // Also subtract merchants currently on the road
    $merchants_in_use = (int)db()->fetchColumn(
        "SELECT COALESCE(SUM(merchants_used), 0) FROM resource_movements
         WHERE from_village_id = ? AND status = 'in_progress'",
        [$from_village_id]
    );
    $merchants_free = $merchants_have - $merchants_in_use;
    $capacity = merchant_total_capacity($merchants_free);
    if ($total > $capacity) {
        return ['ok' => false, 'error' => "Not enough merchant capacity. Need to send $total, can carry $capacity (free merchants: $merchants_free)."];
    }
    $merchants_needed = (int)ceil($total / $MARKETPLACE_MERCHANT_CAPACITY);
    if ($merchants_needed > $merchants_free) {
        return ['ok' => false, 'error' => "Not enough free merchants (need $merchants_needed, have $merchants_free free)."];
    }

    // Check resources available
    $res = update_resources($from_village_id);
    if ($res['wood'] < $wood || $res['clay'] < $clay || $res['iron'] < $iron || $res['crop'] < $crop) {
        return ['ok' => false, 'error' => 'Not enough resources in source village.'];
    }

    // Deduct from source
    db()->update('resources', [
        'wood' => max(0, $res['wood'] - $wood),
        'clay' => max(0, $res['clay'] - $clay),
        'iron' => max(0, $res['iron'] - $iron),
        'crop' => max(0, $res['crop'] - $crop),
    ], 'village_id = :wv', ['wv' => $from_village_id]);

    // Calculate travel time (merchants travel at 1 field/hour by default, modified by server speed)
    $from = db()->fetch("SELECT * FROM villages WHERE id = ?", [$from_village_id]);
    $to   = db()->fetch("SELECT * FROM villages WHERE id = ?", [$to_village_id]);
    if (!$to) return ['ok' => false, 'error' => 'Target village not found.'];

    $dist = distance_between($from['x'], $from['y'], $to['x'], $to['y']);
    if ($dist == 0) $dist = 1;  // same village edge case
    // Merchants travel at 12 fields/hour base (Travian default)
    $travel = movement_time_seconds($dist, 12);

    $now_ts = time();
    $started = date('Y-m-d H:i:s', $now_ts);
    $arrives = date('Y-m-d H:i:s', $now_ts + $travel);

    db()->insert('resource_movements', [
        'from_village_id' => $from_village_id,
        'to_village_id'   => $to_village_id,
        'wood'            => $wood,
        'clay'            => $clay,
        'iron'            => $iron,
        'crop'            => $crop,
        'merchants_used'  => $merchants_needed,
        'started_at'      => $started,
        'arrives_at'      => $arrives,
        'status'          => 'in_progress',
    ]);

    // NOTE: No "resources sent" or "incoming resources" reports are created
    // here. Per spec, the player only receives a report when the shipment
    // actually ARRIVES (handled by process_resource_movements). The sender
    // and receiver can both see the in-progress shipment on the Marketplace
    // page's "Active Shipments" panel.

    return ['ok' => true, 'arrives_at' => $arrives, 'merchants_used' => $merchants_needed];
}

// ============================================================
// NPC TRADE (resource redistribution for gold)
// ============================================================

// Redistribute resources via NPC merchant.
// $new_amounts = ['wood' => X, 'clay' => Y, 'iron' => Z, 'crop' => W]
// The TOTAL must equal current total (no resources created or destroyed).
// Costs 1 gold per trade (NPC_TRADE_GOLD_COST).
function npc_redistribute_resources($village_id, $new_amounts) {
    $res = update_resources($village_id);

    // Validate all 4 resources present
    foreach (['wood','clay','iron','crop'] as $r) {
        if (!isset($new_amounts[$r]) || $new_amounts[$r] < 0) {
            return ['ok' => false, 'error' => "Invalid $r amount"];
        }
    }

    // Check totals match
    $current_total = (int)($res['wood'] + $res['clay'] + $res['iron'] + $res['crop']);
    $new_total = (int)($new_amounts['wood'] + $new_amounts['clay'] + $new_amounts['iron'] + $new_amounts['crop']);
    if ($current_total !== $new_total) {
        return ['ok' => false, 'error' => "Total mismatch! Current: $current_total, New: $new_total. Total must be the same."];
    }

    // Check capacities
    foreach (['wood','clay','iron','crop'] as $r) {
        $cap_key = $r . '_cap';
        if ($new_amounts[$r] > $res[$cap_key]) {
            return ['ok' => false, 'error' => ucfirst($r) . " amount exceeds capacity (cap: {$res[$cap_key]})"];
        }
    }

    // Check player has gold
    $village = db()->fetch("SELECT player_id FROM villages WHERE id = ?", [$village_id]);
    $player = db()->fetch("SELECT gold FROM players WHERE id = ?", [$village['player_id']]);
    $cost = NPC_TRADE_GOLD_COST;
    if ($player['gold'] < $cost) {
        return ['ok' => false, 'error' => "Not enough gold. NPC trade costs $cost gold, you have {$player['gold']}"];
    }

    // Deduct gold
    db()->query("UPDATE players SET gold = gold - ? WHERE id = ?", [$cost, $village['player_id']]);

    // Apply new distribution
    db()->update('resources', [
        'wood' => $new_amounts['wood'],
        'clay' => $new_amounts['clay'],
        'iron' => $new_amounts['iron'],
        'crop' => $new_amounts['crop'],
    ], 'village_id = :wv', ['wv' => $village_id]);

    // NOTE: No report for NPC trades — reduces SQL load. The player can see
    // the new resource distribution directly in the header resource bar.

    return ['ok' => true, 'gold_spent' => $cost, 'old_total' => $current_total, 'new_total' => $new_total];
}

// ============================================================
// TRADE OFFERS (player-to-player resource swaps)
// ============================================================

// Get all active trade offers (excluding own)
function get_active_trade_offers($exclude_player_id = 0) {
    // First mark expired offers as expired
    $now = date('Y-m-d H:i:s');
    db()->query("UPDATE trade_offers SET status = 'expired' WHERE status = 'active' AND expires_at < ?", [$now]);

    return db()->fetchAll(
        "SELECT o.*, p.username, p.tribe, v.name AS village_name, v.x, v.y
         FROM trade_offers o
         JOIN players p ON p.id = o.player_id
         JOIN villages v ON v.id = o.village_id
         WHERE o.status = 'active' AND o.player_id != ?
         ORDER BY o.created_at DESC",
        [$exclude_player_id]
    );
}

// Get player's own offers (all statuses)
function get_my_trade_offers($player_id) {
    return db()->fetchAll(
        "SELECT o.*, v.name AS village_name, v.x, v.y
         FROM trade_offers o
         JOIN villages v ON v.id = o.village_id
         WHERE o.player_id = ?
         ORDER BY o.created_at DESC",
        [$player_id]
    );
}

// Create a new trade offer.
function create_trade_offer($village_id, $offer_resource, $offer_amount, $want_resource, $want_amount, $max_transport_hours = 24) {
    global $TRADE_OFFER_DURATION_HOURS;

    // Validate
    if (!in_array($offer_resource, ['wood','clay','iron','crop']) || !in_array($want_resource, ['wood','clay','iron','crop'])) {
        return ['ok' => false, 'error' => 'Invalid resource type'];
    }
    if ($offer_resource === $want_resource) {
        return ['ok' => false, 'error' => 'Cannot offer and want the same resource'];
    }
    $offer_amount = (int)$offer_amount;
    $want_amount = (int)$want_amount;
    if ($offer_amount <= 0 || $want_amount <= 0) {
        return ['ok' => false, 'error' => 'Amounts must be positive'];
    }

    // Check player has the offered resources
    $res = update_resources($village_id);
    if ($res[$offer_resource] < $offer_amount) {
        return ['ok' => false, 'error' => "Not enough $offer_resource. Have {$res[$offer_resource]}, need $offer_amount"];
    }

    // Deduct offered resources immediately (held in escrow)
    db()->update('resources', [
        $offer_resource => max(0, $res[$offer_resource] - $offer_amount),
    ], 'village_id = :wv', ['wv' => $village_id]);

    // Get player_id
    $village = db()->fetch("SELECT player_id FROM villages WHERE id = ?", [$village_id]);

    // Compute expiry
    $now_ts = time();
    $created = date('Y-m-d H:i:s', $now_ts);
    $expires = date('Y-m-d H:i:s', $now_ts + ($TRADE_OFFER_DURATION_HOURS * 3600));

    db()->insert('trade_offers', [
        'player_id'           => $village['player_id'],
        'village_id'          => $village_id,
        'offer_resource'      => $offer_resource,
        'offer_amount'        => $offer_amount,
        'want_resource'       => $want_resource,
        'want_amount'         => $want_amount,
        'max_transport_hours' => (int)$max_transport_hours,
        'expires_at'          => $expires,
    ]);

    return ['ok' => true, 'offer_id' => db()->pdo()->lastInsertId()];
}

// Accept a trade offer.
// The accepter sends want_amount of want_resource, receives offer_amount of offer_resource.
function accept_trade_offer($offer_id, $accepter_village_id) {
    // Refresh expired offers
    $now = date('Y-m-d H:i:s');
    db()->query("UPDATE trade_offers SET status = 'expired' WHERE status = 'active' AND expires_at < ?", [$now]);

    $offer = db()->fetch("SELECT * FROM trade_offers WHERE id = ? AND status = 'active'", [$offer_id]);
    if (!$offer) {
        return ['ok' => false, 'error' => 'Offer not found or no longer active'];
    }

    $accepter_village = db()->fetch("SELECT player_id FROM villages WHERE id = ?", [$accepter_village_id]);
    if ($accepter_village['player_id'] == $offer['player_id']) {
        return ['ok' => false, 'error' => 'Cannot accept your own offer'];
    }

    // Check accepter has enough of the wanted resource
    $res = update_resources($accepter_village_id);
    if ($res[$offer['want_resource']] < $offer['want_amount']) {
        return ['ok' => false, 'error' => "Not enough {$offer['want_resource']}. Need {$offer['want_amount']}, have {$res[$offer['want_resource']]}"];
    }

    // Check merchant capacity (need merchants to transport both ways)
    $buildings = get_buildings($accepter_village_id);
    $market_level = 0;
    foreach ($buildings as $b) {
        if ($b['building_type'] === 'marketplace') $market_level = max($market_level, (int)$b['level']);
    }
    if ($market_level < 1) {
        return ['ok' => false, 'error' => 'You need a Marketplace to accept offers'];
    }
    $merchants_have = merchants_available($market_level);
    $merchants_in_use = (int)db()->fetchColumn(
        "SELECT COALESCE(SUM(merchants_used), 0) FROM resource_movements
         WHERE from_village_id = ? AND status = 'in_progress'",
        [$accepter_village_id]
    );
    $merchants_free = $merchants_have - $merchants_in_use;
    // Need 1 merchant for the wanted resource (going TO offerer)
    if ($merchants_free < 1) {
        return ['ok' => false, 'error' => 'No free merchants available'];
    }

    // Calculate travel time from accepter to offerer
    $accepter_vil = db()->fetch("SELECT x, y FROM villages WHERE id = ?", [$accepter_village_id]);
    $offerer_vil = db()->fetch("SELECT x, y FROM villages WHERE id = ?", [$offer['village_id']]);
    $dist = distance_between($accepter_vil['x'], $accepter_vil['y'], $offerer_vil['x'], $offerer_vil['y']);

    // Check max_transport_hours
    $travel = movement_time_seconds($dist, 12); // 12 fields/hour merchant speed
    $max_transport_sec = $offer['max_transport_hours'] * 3600;
    if ($travel > $max_transport_sec) {
        return ['ok' => false, 'error' => 'Travel time exceeds the offerer\'s max transport time'];
    }

    // === Perform the trade ===
    // 1. Accepter sends want_resource to offerer (via resource_movements)
    $send_wood = $offer['want_resource'] === 'wood' ? $offer['want_amount'] : 0;
    $send_clay = $offer['want_resource'] === 'clay' ? $offer['want_amount'] : 0;
    $send_iron = $offer['want_resource'] === 'iron' ? $offer['want_amount'] : 0;
    $send_crop = $offer['want_resource'] === 'crop' ? $offer['want_amount'] : 0;

    // Deduct from accepter immediately (escrow)
    db()->update('resources', [
        $offer['want_resource'] => max(0, $res[$offer['want_resource']] - $offer['want_amount']),
    ], 'village_id = :wv', ['wv' => $accepter_village_id]);

    // Send the wanted resources to offerer via resource_movements
    $now_ts = time();
    $started = date('Y-m-d H:i:s', $now_ts);
    $arrives = date('Y-m-d H:i:s', $now_ts + $travel);
    db()->insert('resource_movements', [
        'from_village_id' => $accepter_village_id,
        'to_village_id'   => $offer['village_id'],
        'wood'            => $send_wood,
        'clay'            => $send_clay,
        'iron'            => $send_iron,
        'crop'            => $send_crop,
        'merchants_used'  => 1,
        'started_at'      => $started,
        'arrives_at'      => $arrives,
        'status'          => 'in_progress',
    ]);

    // 2. Send offered resources back to accepter (these were held in escrow)
    $back_wood = $offer['offer_resource'] === 'wood' ? $offer['offer_amount'] : 0;
    $back_clay = $offer['offer_resource'] === 'clay' ? $offer['offer_amount'] : 0;
    $back_iron = $offer['offer_resource'] === 'iron' ? $offer['offer_amount'] : 0;
    $back_crop = $offer['offer_resource'] === 'crop' ? $offer['offer_amount'] : 0;

    db()->insert('resource_movements', [
        'from_village_id' => $offer['village_id'],
        'to_village_id'   => $accepter_village_id,
        'wood'            => $back_wood,
        'clay'            => $back_clay,
        'iron'            => $back_iron,
        'crop'            => $back_crop,
        'merchants_used'  => 1,
        'started_at'      => $started,
        'arrives_at'      => $arrives,
        'status'          => 'in_progress',
    ]);

    // 3. Mark offer as accepted
    db()->query("UPDATE trade_offers SET status = 'accepted' WHERE id = ?", [$offer_id]);

    // 4. NOTE: No reports for trade offer acceptance — the actual resource
    // movements will generate "Resources sent" and "Resources arrived" reports
    // when they are processed. This avoids duplicate notifications and reduces
    // SQL load.

    return ['ok' => true, 'arrives_at' => $arrives];
}

// Cancel a trade offer (refunds the held resources to the offerer).
function cancel_trade_offer($offer_id, $player_id) {
    $offer = db()->fetch("SELECT * FROM trade_offers WHERE id = ? AND player_id = ?", [$offer_id, $player_id]);
    if (!$offer) {
        return ['ok' => false, 'error' => 'Offer not found or not yours'];
    }
    if ($offer['status'] !== 'active') {
        return ['ok' => false, 'error' => 'Offer is no longer active'];
    }

    // Refund held resources
    $res = update_resources($offer['village_id']);
    $cap_key = $offer['offer_resource'] . '_cap';
    $new_amount = min($res[$cap_key], $res[$offer['offer_resource']] + $offer['offer_amount']);
    db()->update('resources', [
        $offer['offer_resource'] => $new_amount,
    ], 'village_id = :wv', ['wv' => $offer['village_id']]);

    // Mark as cancelled
    db()->query("UPDATE trade_offers SET status = 'cancelled' WHERE id = ?", [$offer_id]);

    // NOTE: No report for offer cancellation — the player sees the offer
    // disappear from their "My Offers" list and resources return to the
    // warehouse immediately.

    return ['ok' => true];
}
