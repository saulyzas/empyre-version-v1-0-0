<?php
/**
 * MYEMPIRE — Admin helper functions.
 *
 * Provides:
 *   - is_admin($player_id)        — boolean
 *   - require_admin()             — gate; redirects non-admins to /login.php
 *   - is_banned($player_id)       — boolean (for login.php check)
 *   - admin_count()               — how many admins exist (for setup gate)
 *   - admin_log($action, $details)— write an entry to the reports table (category='admin')
 *   - admin_get_player($id)       — fetch a player row including admin/ban fields
 *   - admin_set_admin($id, $on)   — promote / demote
 *   - admin_ban($id, $reason)     — ban a player
 *   - admin_unban($id)            — unban a player
 *   - admin_award_gold($id, $amt) — give (or take) gold
 *   - admin_award_resources($village_id, $wood, $clay, $iron, $crop)
 *   - admin_delete_player($id)    — hard-delete a player and all their data
 *   - admin_delete_village($id)   — hard-delete a village
 *   - admin_rename_village($id, $new_name)
 *   - admin_set_loyalty($village_id, $loyalty)
 *   - admin_recalc_all()          — recalculate population + capacity for every village
 *
 * All admin pages should call require_admin() at the top.
 *
 * The first admin is created via admin_setup.php (one-time bootstrap).
 * After that, admins can promote other players from admin_players.php.
 */

require_once __DIR__ . '/helpers.php';

// Boolean: is this player an admin?
// Uses the current_player() cache — safe to call multiple times per request.
function is_admin($player_id = null) {
    if ($player_id === null) {
        $p = current_player();
    } else {
        // Bypass the static cache (which only tracks the session player).
        static $cache = [];
        if (isset($cache[$player_id])) return $cache[$player_id];
        $p = db()->fetch("SELECT is_admin FROM players WHERE id = ?", [$player_id]);
        $cache[$player_id] = $p ? (int)$p['is_admin'] === 1 : false;
        return $cache[$player_id];
    }
    if (!$p) return false;
    return (int)$p['is_admin'] === 1;
}

// Gate: call at the top of every admin page.
// Redirects non-admins back to the village page (or login if not logged in).
function require_admin() {
    require_login();
    if (!is_admin()) {
        // Silent redirect — don't reveal admin URLs to non-admins.
        redirect('/village.php');
    }
    // Also reject banned admins (safety net).
    $p = current_player();
    if (!empty($p['is_banned'])) {
        redirect('/logout.php');
    }
}

// Boolean: is this player banned?
function is_banned($player_id = null) {
    if ($player_id === null) {
        $p = current_player();
    } else {
        static $cache = [];
        if (isset($cache[$player_id])) return $cache[$player_id];
        $p = db()->fetch("SELECT is_banned FROM players WHERE id = ?", [$player_id]);
        $cache[$player_id] = $p ? (int)$p['is_banned'] === 1 : false;
        return $cache[$player_id];
    }
    if (!$p) return false;
    return (int)$p['is_banned'] === 1;
}

// How many admins exist? Used by admin_setup.php to gate first-time setup.
function admin_count() {
    try {
        return (int)db()->fetchColumn("SELECT COUNT(*) FROM players WHERE is_admin = 1");
    } catch (Throwable $e) {
        return 0;
    }
}

// Write an admin action to the reports table (category='admin') for auditing.
function admin_log($action, $details = '', $target_player_id = null) {
    $admin = current_player();
    if (!$admin) return;
    $title = "[ADMIN] {$admin['username']}: {$action}";
    $body = "Admin: {$admin['username']} (ID {$admin['id']})\nAction: {$action}\nDetails: {$details}";
    if ($target_player_id) {
        $body .= "\nTarget player ID: {$target_player_id}";
    }
    try {
        db()->insert('reports', [
            'player_id' => $admin['id'],
            'title'     => $title,
            'body'      => $body,
            'category'  => 'admin',
        ]);
    } catch (Throwable $e) { /* ignore */ }
}

// Fetch a player by ID, including admin/ban fields.
function admin_get_player($id) {
    return db()->fetch("SELECT * FROM players WHERE id = ?", [$id]);
}

// Promote or demote a player. Cannot demote yourself (safety).
function admin_set_admin($player_id, $on) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];
    if ((int)$player_id === (int)$admin['id'] && !$on) {
        return ['ok' => false, 'error' => 'You cannot demote yourself.'];
    }
    $target = admin_get_player($player_id);
    if (!$target) return ['ok' => false, 'error' => 'Player not found'];

    $new_val = $on ? 1 : 0;
    db()->query("UPDATE players SET is_admin = ? WHERE id = ?", [$new_val, $player_id]);

    admin_log(
        $on ? 'Promoted player to admin' : 'Demoted admin to player',
        "Target: {$target['username']} (ID {$player_id})",
        $player_id
    );
    return ['ok' => true];
}

// Ban a player (with reason).
function admin_ban($player_id, $reason) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];
    if ((int)$player_id === (int)$admin['id']) {
        return ['ok' => false, 'error' => 'You cannot ban yourself.'];
    }
    $target = admin_get_player($player_id);
    if (!$target) return ['ok' => false, 'error' => 'Player not found'];
    if ((int)$target['is_admin'] === 1) {
        return ['ok' => false, 'error' => 'Cannot ban an admin. Demote them first.'];
    }

    $reason = trim(substr($reason, 0, 250));
    db()->query("UPDATE players SET is_banned = 1, banned_reason = ? WHERE id = ?", [$reason, $player_id]);

    admin_log(
        'Banned player',
        "Target: {$target['username']} (ID {$player_id}) — Reason: {$reason}",
        $player_id
    );
    return ['ok' => true];
}

// Unban a player.
function admin_unban($player_id) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];
    $target = admin_get_player($player_id);
    if (!$target) return ['ok' => false, 'error' => 'Player not found'];

    db()->query("UPDATE players SET is_banned = 0, banned_reason = NULL WHERE id = ?", [$player_id]);

    admin_log(
        'Unbanned player',
        "Target: {$target['username']} (ID {$player_id})",
        $player_id
    );
    return ['ok' => true];
}

// Award (or deduct) gold from a player. $amt can be negative.
function admin_award_gold($player_id, $amt) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];
    $target = admin_get_player($player_id);
    if (!$target) return ['ok' => false, 'error' => 'Player not found'];

    $amt = (int)$amt;
    $new_gold = max(0, (int)$target['gold'] + $amt);
    db()->query("UPDATE players SET gold = ? WHERE id = ?", [$new_gold, $player_id]);

    admin_log(
        'Awarded gold',
        "Target: {$target['username']} (ID {$player_id}) — Amount: {$amt} (new total: {$new_gold})",
        $player_id
    );
    return ['ok' => true, 'new_gold' => $new_gold];
}

// Award (or deduct) resources to/from a village. Resources are capped at warehouse/granary capacity.
function admin_award_resources($village_id, $wood, $clay, $iron, $crop) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];

    $village = db()->fetch("SELECT * FROM villages WHERE id = ?", [$village_id]);
    if (!$village) return ['ok' => false, 'error' => 'Village not found'];

    $res = update_resources($village_id);
    $new = [
        'wood' => max(0, $res['wood'] + (int)$wood),
        'clay' => max(0, $res['clay'] + (int)$clay),
        'iron' => max(0, $res['iron'] + (int)$iron),
        'crop' => max(0, $res['crop'] + (int)$crop),
    ];
    // Cap at warehouse/granary
    $new['wood'] = min($new['wood'], $res['wood_cap']);
    $new['clay'] = min($new['clay'], $res['clay_cap']);
    $new['iron'] = min($new['iron'], $res['iron_cap']);
    $new['crop'] = min($new['crop'], $res['crop_cap']);

    db()->update('resources', $new, 'village_id = :wv', ['wv' => $village_id]);

    admin_log(
        'Awarded resources',
        "Village: {$village['name']} (ID {$village_id}) — Wood {$wood}, Clay {$clay}, Iron {$iron}, Crop {$crop}",
        $village['player_id']
    );
    return ['ok' => true, 'new_resources' => $new];
}

// Rename a village.
function admin_rename_village($village_id, $new_name) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];

    $new_name = trim(substr($new_name, 0, 60));
    if ($new_name === '') return ['ok' => false, 'error' => 'Name cannot be empty'];

    $village = db()->fetch("SELECT * FROM villages WHERE id = ?", [$village_id]);
    if (!$village) return ['ok' => false, 'error' => 'Village not found'];

    $old_name = $village['name'];
    db()->query("UPDATE villages SET name = ? WHERE id = ?", [$new_name, $village_id]);

    admin_log(
        'Renamed village',
        "Village ID {$village_id}: \"{$old_name}\" → \"{$new_name}\"",
        $village['player_id']
    );
    return ['ok' => true];
}

// Set village loyalty (0-100).
function admin_set_loyalty($village_id, $loyalty) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];

    $loyalty = max(0, min(100, (float)$loyalty));
    $village = db()->fetch("SELECT * FROM villages WHERE id = ?", [$village_id]);
    if (!$village) return ['ok' => false, 'error' => 'Village not found'];

    db()->query("UPDATE villages SET loyalty = ? WHERE id = ?", [$loyalty, $village_id]);

    admin_log(
        'Set village loyalty',
        "Village: {$village['name']} (ID {$village_id}) — Loyalty: {$loyalty}%",
        $village['player_id']
    );
    return ['ok' => true];
}

// Hard-delete a player and all their data (villages, troops, builds, etc.).
// ON DELETE CASCADE handles the related tables.
function admin_delete_player($player_id) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];
    if ((int)$player_id === (int)$admin['id']) {
        return ['ok' => false, 'error' => 'You cannot delete yourself.'];
    }
    $target = admin_get_player($player_id);
    if (!$target) return ['ok' => false, 'error' => 'Player not found'];
    if ((int)$target['is_admin'] === 1) {
        return ['ok' => false, 'error' => 'Cannot delete an admin. Demote them first.'];
    }

    $username = $target['username'];

    // Delete the player — FK ON DELETE CASCADE removes villages, troops, etc.
    db()->query("DELETE FROM players WHERE id = ?", [$player_id]);

    admin_log(
        'Deleted player',
        "Target: {$username} (ID {$player_id}) — all data removed"
    );
    return ['ok' => true];
}

// Hard-delete a village (keeps the player — they just lose that village).
function admin_delete_village($village_id) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];

    $village = db()->fetch("SELECT * FROM villages WHERE id = ?", [$village_id]);
    if (!$village) return ['ok' => false, 'error' => 'Village not found'];

    // Safety: don't allow deleting a player's only village.
    $village_count = (int)db()->fetchColumn(
        "SELECT COUNT(*) FROM villages WHERE player_id = ?",
        [$village['player_id']]
    );
    if ($village_count <= 1) {
        return ['ok' => false, 'error' => 'Cannot delete a player\'s only village. Delete the player instead.'];
    }

    $vname = $village['name'];
    $pid   = $village['player_id'];
    db()->query("DELETE FROM villages WHERE id = ?", [$village_id]);

    admin_log(
        'Deleted village',
        "Village: {$vname} (ID {$village_id}) — player ID {$pid}"
    );
    return ['ok' => true];
}

// Recalculate population + capacity for every village in the database.
// Useful after manual DB edits or migrations.
function admin_recalc_all() {
    $results = ['villages' => 0, 'population_set' => 0, 'capacity_set' => 0];
    try {
        $villages = db()->fetchAll("SELECT id FROM villages");
        $results['villages'] = count($villages);
        foreach ($villages as $v) {
            try {
                recalculate_population($v['id']);
                $results['population_set']++;
            } catch (Throwable $e) {}
            try {
                recalculate_capacity($v['id']);
                $results['capacity_set']++;
            } catch (Throwable $e) {}
        }
    } catch (Throwable $e) {}
    return $results;
}

// Clean up orphaned data (movements referencing deleted villages, etc.).
function admin_cleanup_orphans() {
    $results = [
        'orphaned_movements'         => 0,
        'orphaned_resource_movements'=> 0,
        'orphaned_troops'            => 0,
        'orphaned_buildings'         => 0,
        'orphaned_resource_fields'   => 0,
        'orphaned_reports'           => 0,
    ];

    $cleanups = [
        'orphaned_movements' =>
            "DELETE FROM movements
             WHERE from_village_id NOT IN (SELECT id FROM villages)
                OR to_village_id NOT IN (SELECT id FROM villages)",
        'orphaned_resource_movements' =>
            "DELETE FROM resource_movements
             WHERE from_village_id NOT IN (SELECT id FROM villages)
                OR to_village_id NOT IN (SELECT id FROM villages)",
        'orphaned_troops' =>
            "DELETE FROM troops WHERE village_id NOT IN (SELECT id FROM villages)",
        'orphaned_buildings' =>
            "DELETE FROM buildings WHERE village_id NOT IN (SELECT id FROM villages)",
        'orphaned_resource_fields' =>
            "DELETE FROM resource_fields WHERE village_id NOT IN (SELECT id FROM villages)",
        'orphaned_reports' =>
            "DELETE FROM reports WHERE player_id NOT IN (SELECT id FROM players)",
    ];

    foreach ($cleanups as $key => $sql) {
        try {
            db()->query($sql, []);
            // We can't easily get affected rows across both drivers, so just
            // mark it as "attempted".
            $results[$key] = -1; // -1 = "cleanup ran (count unknown)"
        } catch (Throwable $e) {}
    }
    return $results;
}

// Send a system message to ALL players (writes a report row to each).
function admin_broadcast($subject, $body) {
    $admin = current_player();
    if (!$admin) return ['ok' => false, 'error' => 'Not logged in'];

    $subject = trim(substr($subject, 0, 120));
    $body    = trim($body);
    if ($subject === '' || $body === '') {
        return ['ok' => false, 'error' => 'Subject and body are required'];
    }

    $players = db()->fetchAll("SELECT id FROM players");
    $sent = 0;
    foreach ($players as $p) {
        try {
            db()->insert('reports', [
                'player_id' => $p['id'],
                'title'     => '📢 ' . $subject,
                'body'      => "Message from the server admin ({$admin['username']}):\n\n{$body}",
                'category'  => 'general',
            ]);
            $sent++;
        } catch (Throwable $e) {}
    }

    admin_log(
        'Broadcast system message',
        "Subject: \"{$subject}\" — sent to {$sent} player(s)"
    );
    return ['ok' => true, 'sent' => $sent];
}
