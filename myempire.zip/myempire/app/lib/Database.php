<?php
/**
 * MYEMPIRE - Database connection
 *
 * Supports two drivers:
 *   - 'sqlite' (default): zero-config, single file in db/myempire.sqlite
 *   - 'mysql'  : use with MariaDB/MySQL — import sql/schema_mysql.sql first
 *
 * The driver is selected via DB_DRIVER constant (see app/config/config.php),
 * which reads the DB_DRIVER env var. To use MySQL, set DB_DRIVER=mysql in
 * a .env file (or in your web server's environment), then fill in
 * DB_HOST / DB_NAME / DB_USER / DB_PASS.
 */

require_once __DIR__ . '/../config/config.php';

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $driver = defined('DB_DRIVER') ? DB_DRIVER : 'auto';
        $connected = false;
        $errors = [];

        // Try the explicitly chosen driver first
        if ($driver === 'sqlite') {
            try {
                $this->connect_sqlite();
                $connected = true;
            } catch (Throwable $e) {
                $errors[] = 'SQLite: ' . $e->getMessage();
            }
        } elseif ($driver === 'mysql') {
            try {
                $this->connect_mysql();
                $connected = true;
            } catch (Throwable $e) {
                $errors[] = 'MySQL: ' . $e->getMessage();
            }
        } else {
            // 'auto' — try SQLite first (zero-config), then fall back to MySQL
            try {
                $this->connect_sqlite();
                $connected = true;
            } catch (Throwable $e) {
                $errors[] = 'SQLite: ' . $e->getMessage();
                // Fall back to MySQL
                try {
                    $this->connect_mysql();
                    $connected = true;
                } catch (Throwable $e2) {
                    $errors[] = 'MySQL: ' . $e2->getMessage();
                }
            }
        }

        if (!$connected) {
            throw new RuntimeException(
                "Could not connect to any database driver.\n\n" .
                "Attempted:\n  - " . implode("\n  - ", $errors) . "\n\n" .
                "To fix this:\n" .
                "  OPTION A — Enable SQLite:\n" .
                "    Open C:\\xampp\\php\\php.ini, remove the ';' from ;extension=pdo_sqlite and ;extension=sqlite3, restart Apache.\n" .
                "  OPTION B — Use MySQL (XAMPP has it ready):\n" .
                "    1. Start MySQL in XAMPP control panel\n" .
                "    2. Open http://localhost/phpmyadmin/ and create database 'myempire'\n" .
                "    3. Import sql/schema_mysql.sql into that database\n" .
                "    4. Reload this page"
            );
        }

        // ERRMODE_EXCEPTION may already be set in connect_sqlite(); ensure it for MySQL too.
        if ($this->pdo->getAttribute(PDO::ATTR_ERRMODE) !== PDO::ERRMODE_EXCEPTION) {
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    private function connect_sqlite() {
        // Check if PDO SQLite driver is available — if not, throw a simple
        // exception that auto-fallback can catch and try MySQL instead.
        if (!in_array('sqlite', PDO::getAvailableDrivers())) {
            throw new RuntimeException('PDO SQLite driver is not enabled in php.ini');
        }

        if (!is_dir(DB_DIR)) {
            mkdir(DB_DIR, 0775, true);
        }
        $is_new = !file_exists(DB_PATH);
        $this->pdo = new PDO(DB_DSN);
        // Set error mode to EXCEPTION early so schema errors are not silently ignored
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        if ($is_new) {
            // Disable foreign keys during schema loading so that seed data
            // (INSERT with id=0 placeholders) and trigger creation don't fail.
            // Foreign keys are re-enabled below.
            $this->pdo->exec('PRAGMA foreign_keys = OFF');
            $sql = file_get_contents(SQL_DIR . '/schema.sql');
            $this->pdo->exec($sql);
        }
        // Always enable foreign keys for normal operation
        $this->pdo->exec('PRAGMA foreign_keys = ON');
    }

    private function connect_mysql() {
        // Check if PDO MySQL driver is available
        if (!in_array('mysql', PDO::getAvailableDrivers())) {
            throw new RuntimeException(
                "PDO MySQL driver is not enabled in your PHP installation.\n" .
                "Open php.ini and uncomment:  extension=pdo_mysql\n" .
                "Then restart Apache."
            );
        }

        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
        );
        // Let PDOException propagate — auto-fallback catches it.
        // The final error message (if both SQLite and MySQL fail) is composed
        // in the constructor with full diagnostic info.
        $this->pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        // Force strict SQL mode off (avoids issues with DEFAULT 0 dates)
        $this->pdo->exec("SET sql_mode = 'NO_ENGINE_SUBSTITUTION'");
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function pdo() {
        return $this->pdo;
    }

    public function query($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function fetch($sql, $params = []) {
        return $this->query($sql, $params)->fetch();
    }

    public function fetchAll($sql, $params = []) {
        return $this->query($sql, $params)->fetchAll();
    }

    public function fetchColumn($sql, $params = []) {
        return $this->query($sql, $params)->fetchColumn();
    }

    public function insert($table, $data) {
        $cols = array_keys($data);
        $placeholders = array_map(fn($c) => ':' . $c, $cols);
        $sql = "INSERT INTO $table (" . implode(',', $cols) . ") VALUES (" . implode(',', $placeholders) . ")";
        $this->query($sql, $data);
        return $this->pdo->lastInsertId();
    }

    public function update($table, $data, $where, $where_params = []) {
        $set = [];
        foreach (array_keys($data) as $col) {
            $set[] = "$col = :$col";
        }
        $sql = "UPDATE $table SET " . implode(', ', $set) . " WHERE $where";
        $stmt = $this->query($sql, array_merge($data, $where_params));
        return $stmt->rowCount();
    }
}

// Helper function
function db() {
    return Database::getInstance();
}
