<?php
/**
 * MYEMPIRE - Application Configuration
 * Edit GAME_NAME to brand your game.
 */

// ---- Timezone (must match browser timezone so build queue timers work) ----
// Default: Europe/Vilnius (matches the system setting). Change to 'UTC' if your
// server and players are in different timezones.
date_default_timezone_set('Europe/Vilnius');

// ---- Branding (you can rename freely) ----
define('GAME_NAME',          'MYEMPIRE');
define('GAME_TAGLINE',       'Rule the Ancient World');
define('GAME_VERSION',       '1.0.0');
define('GAME_COPYRIGHT',     '© 2026 ' . GAME_NAME);
define('GAME_SERVER_SPEED',  5);  // 5x production speed

// ---- Paths (absolute) ----
define('ROOT_DIR',     dirname(__DIR__, 2));                 // /path/to/myempire
define('APP_DIR',      dirname(__DIR__));                    // /path/to/myempire/app
define('PUBLIC_DIR',   ROOT_DIR);                            // public files live at the project root
define('DB_DIR',       ROOT_DIR . '/db');                    // /path/to/myempire/db
define('SQL_DIR',      ROOT_DIR . '/sql');                   // /path/to/myempire/sql

// ---- Base URL auto-detection (so the app works in subdirectories like /myempire/) ----
// Compute the URL path prefix by comparing document root with project root.
$docRoot = isset($_SERVER['DOCUMENT_ROOT'])
    ? str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'], '/'))
    : '';
$projectRoot = str_replace('\\', '/', ROOT_DIR);
$basePath = '';
if ($docRoot && strpos($projectRoot, $docRoot) === 0) {
    $basePath = substr($projectRoot, strlen($docRoot));
} elseif ($docRoot && stripos($projectRoot, $docRoot) === 0) {
    // Windows case-insensitive fallback
    $basePath = substr($projectRoot, strlen($docRoot));
}
$basePath = rtrim($basePath, '/');
define('BASE_PATH', $basePath);

// Public asset URL prefixes (auto-prefixed with BASE_PATH so subdirs work)
define('IMG_URL',      BASE_PATH . '/img');
define('CSS_URL',      BASE_PATH . '/assets/css');
define('JS_URL',       BASE_PATH . '/assets/js');

// ---- Database ----
// Set DB_DRIVER to 'auto' (default, tries SQLite first then MySQL),
// 'sqlite' (zero-config, single file), or 'mysql' (MariaDB/MySQL).
// For MySQL, fill in DB_HOST / DB_NAME / DB_USER / DB_PASS below.
define('DB_DRIVER',    getenv('DB_DRIVER') ?: 'auto');   // 'auto', 'sqlite', or 'mysql'

// SQLite config (used when DB_DRIVER = 'sqlite')
define('DB_PATH',      DB_DIR . '/myempire.sqlite');
define('DB_DSN',       'sqlite:' . DB_PATH);

// MySQL / MariaDB config (used when DB_DRIVER = 'mysql')
// Tip: load these from a .env file via getenv() or hardcode for simple setups.
define('DB_HOST',      getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT',      getenv('DB_PORT') ?: '3306');
define('DB_NAME',      getenv('DB_NAME') ?: 'myempire');
define('DB_USER',      getenv('DB_USER') ?: 'root');
define('DB_PASS',      getenv('DB_PASS') ?: '');
define('DB_CHARSET',   'utf8mb4');

// ---- Session ----
define('SESSION_NAME', 'myempire_session');
define('SESSION_LIFETIME', 7 * 24 * 60 * 60);  // 7 days

// ---- Game balance ----
define('WAREHOUSE_BASE_CAP',    4000);    // base capacity per resource (wood/clay/iron) without any warehouse
define('WAREHOUSE_PER_LEVEL',   800);     // +800 per warehouse level
define('GRANARY_BASE_CAP',      4000);    // base crop capacity without any granary
define('GRANARY_PER_LEVEL',     800);     // +800 per granary level
define('STARTING_RESOURCES',    800);
define('MAX_RESOURCE_LEVEL',    10);
define('MAX_BUILDING_LEVEL',    20);
define('BUILD_QUEUE_SIZE',      2);

// ---- Tribes ----
$TRIBES = [
    'roman'  => ['name' => 'Romans',  'desc' => 'Balanced attackers and defenders. Best for beginners.'],
    'gaul'   => ['name' => 'Gauls',   'desc' => 'Fast cavalry and strong defense. Excellent merchants.'],
    'teuton' => ['name' => 'Teutons', 'desc' => 'Aggressive raiders. Cheap infantry, strong early game.'],
];

// ---- Quadrants ----
$QUADRANTS = [
    'NorthEast' => [1, 1],
    'NorthWest' => [-1, 1],
    'SouthEast' => [1, -1],
    'SouthWest' => [-1, -1],
];

// ---- Resource field layout (Travian-like) ----
// 18 fields in a hexagon layout
$FIELD_LAYOUT = [
    // position => [type, x_pct, y_pct]  (relative position on SVG)
    0  => ['woodcutter', 50, 12],
    1  => ['woodcutter', 28, 18],
    2  => ['woodcutter', 72, 18],
    3  => ['woodcutter', 14, 38],
    4  => ['claypit',    86, 38],
    5  => ['claypit',    22, 55],
    6  => ['claypit',    78, 55],
    7  => ['claypit',    30, 72],
    8  => ['ironmine',   70, 72],
    9  => ['ironmine',   38, 88],
    10 => ['ironmine',   62, 88],
    11 => ['ironmine',   50, 95],
    12 => ['cropland',   8,  78],
    13 => ['cropland',   92, 78],
    14 => ['cropland',   42, 28],
    15 => ['cropland',   58, 28],
    16 => ['cropland',   22, 78],
    17 => ['cropland',   78, 78],
];

// ---- Production per field level (units/hour at 1x speed) ----
// Level 0 still produces a small base amount (Travian default: 5/hour per field
// before server speed multiplier). This ensures new players get *some* income
// even before upgrading their first fields.
$FIELD_PRODUCTION = [
    0  => 5,     // base production (unupgraded field)
    1  => 40,
    2  => 70,
    3  => 110,
    4  => 160,
    5  => 220,
    6  => 290,
    7  => 370,
    8  => 460,
    9  => 560,
    10 => 700,
];

// ---- Build cost per level (in resources) ----
// Returns base cost; actual cost = base * (multiplier ^ level)
function build_cost($base, $level) {
    $mult = 1.6;
    $cost = [];
    foreach ($base as $res => $amount) {
        $cost[$res] = (int)round($amount * pow($mult, $level - 1));
    }
    return $cost;
}

$FIELD_BASE_COST = [
    'woodcutter' => ['wood' => 40, 'clay' => 100, 'iron' => 50, 'crop' => 60],
    'claypit'    => ['wood' => 80, 'clay' => 40, 'iron' => 80, 'crop' => 50],
    'ironmine'   => ['wood' => 100, 'clay' => 80, 'iron' => 30, 'crop' => 60],
    'cropland'   => ['wood' => 70, 'clay' => 90, 'iron' => 70, 'crop' => 20],
];

$BUILDING_BASE_COST = [
    'main_building' => ['wood' => 70,  'clay' => 90,  'iron' => 70,  'crop' => 20],
    'warehouse'     => ['wood' => 130, 'clay' => 160, 'iron' => 90,  'crop' => 40],
    'granary'       => ['wood' => 80,  'clay' => 100, 'iron' => 70,  'crop' => 20],
    'barracks'      => ['wood' => 210, 'clay' => 140, 'iron' => 260, 'crop' => 120],
    'stable'        => ['wood' => 260, 'clay' => 140, 'iron' => 220, 'crop' => 100],
    'workshop'      => ['wood' => 200, 'clay' => 460, 'iron' => 200, 'crop' => 100],
    'marketplace'   => ['wood' => 80,  'clay' => 70,  'iron' => 120, 'crop' => 70],
    'embassy'       => ['wood' => 180, 'clay' => 130, 'iron' => 150, 'crop' => 80],
    'rally_point'   => ['wood' => 110, 'clay' => 160, 'iron' => 90,  'crop' => 70],
    'hero_mansion'  => ['wood' => 210, 'clay' => 260, 'iron' => 260, 'crop' => 100],
    'smithy'        => ['wood' => 170, 'clay' => 200, 'iron' => 220, 'crop' => 90],
    'academy'       => ['wood' => 220, 'clay' => 320, 'iron' => 200, 'crop' => 100],
    'residence'     => ['wood' => 580, 'clay' => 460, 'iron' => 350, 'crop' => 130],
    'wall'          => ['wood' => 70,  'clay' => 90,  'iron' => 170, 'crop' => 70],
];

// ---- Build time (seconds) per level ----
// Server speed affects build time too (5x speed = 5x faster builds).
function build_time_seconds($base_seconds, $level, $main_building_level = 1) {
    $mult = 1.6;
    $factor = 1.0 - min(0.5, $main_building_level * 0.04);  // -4% per main building level, max -50%
    $time = $base_seconds * pow($mult, $level - 1) * $factor;
    return (int)round($time / GAME_SERVER_SPEED);
}

// ---- Training time (seconds) for troops ----
// Returns base training time in seconds for a unit at level 1.
// Higher Barracks/Stable levels reduce training time.
function training_time_seconds($base_seconds, $building_level = 1) {
    // -3% per building level, max -30%
    $factor = max(0.7, 1.0 - ($building_level * 0.03));
    return (int)round($base_seconds * $factor / GAME_SERVER_SPEED);
}

// ---- Population cost per building/level ----
// Each building type uses this many population points per level.
$BUILDING_POPULATION = [
    'main_building' => 1,
    'warehouse'     => 1,
    'granary'       => 1,
    'barracks'      => 4,
    'stable'        => 5,
    'workshop'      => 7,
    'marketplace'   => 4,
    'embassy'       => 3,
    'rally_point'   => 1,
    'hero_mansion'  => 4,
    'smithy'        => 2,
    'academy'       => 5,
    'residence'     => 4,
    'wall'          => 1,
];

// Population cost per resource field level (Travian: 1 per level)
$FIELD_POPULATION_PER_LEVEL = 1;

// ---- Movement time (seconds) for troops between villages ----
// Distance is Euclidean. Speed is the slowest unit's speed (in fields/hour).
// Returns seconds for one-way trip.
function movement_time_seconds($distance_fields, $slowest_unit_speed) {
    if ($slowest_unit_speed <= 0) return 3600;
    // speed is fields/hour, distance is fields → time in hours = distance / speed
    $hours = $distance_fields / $slowest_unit_speed;
    return (int)round($hours * 3600 / GAME_SERVER_SPEED);
}

// Distance between two coordinates (Euclidean).
function distance_between($x1, $y1, $x2, $y2) {
    return sqrt(pow($x2 - $x1, 2) + pow($y2 - $y1, 2));
}

// ---- Unit training base times (seconds at level 1 building) ----
$UNIT_TRAIN_TIME = [
    // Roman
    'legionnaire'         => 200,
    'praetorian'          => 220,
    'imperian'            => 240,
    'equites_legati'      => 320,
    'equites_imperatoris' => 440,
    'ram_roman'           => 1200,   // Workshop
    'catapult_roman'      => 1800,   // Workshop
    // Gaul
    'phalanx'             => 200,
    'swordsman'           => 220,
    'pathfinder'          => 280,
    'theutates_thunder'   => 360,
    'druidrider'          => 380,
    'ram_gaul'            => 1200,
    'trebuchet'           => 1800,
    // Teuton
    'clubswinger'         => 180,
    'spearman'            => 200,
    'axeman'              => 220,
    'scout'               => 220,
    'paladin'             => 380,
    'ram_teuton'          => 1200,
    'catapult_teuton'     => 1800,
    // Settlers / Colonists (trained at the Residence, shared across tribes)
    'colonist'            => 7200,   // 2 hours base — settlers are expensive and slow
];

$FIELD_BASE_TIME  = 60;     // 1 minute base
$BUILDING_BASE_TIME = [
    'main_building' => 600,
    'warehouse'     => 400,
    'granary'       => 400,
    'barracks'      => 1000,
    'stable'        => 1200,
    'workshop'      => 1500,
    'marketplace'   => 800,
    'embassy'       => 900,
    'rally_point'   => 300,
    'hero_mansion'  => 1800,
    'smithy'        => 1200,
    'academy'       => 2200,
    'residence'     => 2400,
    'wall'          => 700,
];

// ---- Tribe loot multipliers ----
// Each tribe raids differently (Travian official values):
//   - Teutons: best raiders (100%), Clubswinger is cheap & fast
//   - Romans:  average raiders (80%)
//   - Gauls:   moderate raiders (70%) but better defenders
// Applied to the max loot capacity of the attacking troops.
$TRIBE_LOOT_MULTIPLIER = [
    'teuton' => 1.00,   // 100% of carry capacity
    'roman'  => 0.80,   // 80% of carry capacity
    'gaul'   => 0.70,   // 70% of carry capacity
];

// ---- Troop carry capacity (resources per unit) ----
// How many resources a single unit can carry back from a raid.
$UNIT_CARRY_CAPACITY = [
    // Roman
    'legionnaire'         => 50,
    'praetorian'          => 20,
    'imperian'            => 50,
    'equites_legati'      => 0,    // scout — no loot
    'equites_imperatoris' => 100,
    'ram_roman'           => 0,    // siege — no loot
    'catapult_roman'      => 0,
    // Gaul
    'phalanx'             => 30,
    'swordsman'           => 45,
    'pathfinder'          => 0,
    'theutates_thunder'   => 75,
    'druidrider'          => 35,
    'ram_gaul'            => 0,
    'trebuchet'           => 0,
    // Teuton
    'clubswinger'         => 60,
    'spearman'            => 40,
    'axeman'              => 50,
    'scout'               => 0,
    'paladin'             => 110,
    'ram_teuton'          => 0,
    'catapult_teuton'     => 0,
    // Colonists carry nothing — they're for founding new villages
    'colonist'            => 0,
];

// ---- Marketplace: merchants per level + carry capacity per merchant ----
$MARKETPLACE_MERCHANTS_PER_LEVEL = 1;   // +1 merchant per level
$MARKETPLACE_MERCHANT_CAPACITY   = 500; // each merchant carries 500 resources

// Helper: how many merchants a village has based on marketplace level
function merchants_available($marketplace_level) {
    global $MARKETPLACE_MERCHANTS_PER_LEVEL;
    if ($marketplace_level < 1) return 0;
    return $marketplace_level * $MARKETPLACE_MERCHANTS_PER_LEVEL;
}

// Helper: how much can a given number of merchants carry
function merchant_total_capacity($merchant_count) {
    global $MARKETPLACE_MERCHANT_CAPACITY;
    return $merchant_count * $MARKETPLACE_MERCHANT_CAPACITY;
}

// ---- NPC Trading (resource redistribution for gold) ----
// The NPC merchant lets you REDISTRIBUTE your resources between wood/clay/iron/crop.
// Total amount stays the same, you just reallocate it.
// This costs gold — 1 gold coin per NPC trade (regardless of amount).
// Example: you have 5000 wood, 0 clay → NPC can convert it to 2500 wood, 2500 clay.
define('NPC_TRADE_GOLD_COST', 1);

// ---- Trade offers ----
// Players can create offers like "offering 1000 wood, want 800 clay".
// Other players can accept — they send the wanted resources, receive the offered ones.
$TRADE_OFFER_DURATION_HOURS = 48;   // offers auto-expire after 48h

// ---- Unit stats (per tribe) ----
$UNITS = [
    'roman' => [
        // Barracks (infantry)
        'legionnaire'        => ['name' => 'Legionnaire',        'attack' => 40, 'def_inf' => 35, 'def_cav' => 50, 'speed' => 6,  'cost' => ['wood'=>120,'clay'=>100,'iron'=>150,'crop'=>30]],
        'praetorian'         => ['name' => 'Praetorian',         'attack' => 30, 'def_inf' => 65, 'def_cav' => 35, 'speed' => 5,  'cost' => ['wood'=>100,'clay'=>130,'iron'=>160,'crop'=>70]],
        'imperian'           => ['name' => 'Imperian',           'attack' => 70, 'def_inf' => 40, 'def_cav' => 25, 'speed' => 7,  'cost' => ['wood'=>150,'clay'=>160,'iron'=>210,'crop'=>80]],
        // Stable (cavalry)
        'equites_legati'     => ['name' => 'Equites Legati',     'attack' => 0,  'def_inf' => 20, 'def_cav' => 10, 'speed' => 16, 'cost' => ['wood'=>140,'clay'=>160,'iron'=>20,'crop'=>40]],
        'equites_imperatoris'=> ['name' => 'Equites Imperatoris','attack' => 120,'def_inf' => 65, 'def_cav' => 50, 'speed' => 10, 'cost' => ['wood'=>550,'clay'=>440,'iron'=>320,'crop'=>100]],
        // Workshop (siege)
        'ram_roman'          => ['name' => 'Ram',                'attack' => 60, 'def_inf' => 30, 'def_cav' => 30, 'speed' => 4,  'cost' => ['wood'=>900,'clay'=>360,'iron'=>500,'crop'=>70]],
        'catapult_roman'     => ['name' => 'Fire Catapult',      'attack' => 75, 'def_inf' => 60, 'def_cav' => 60, 'speed' => 3,  'cost' => ['wood'=>950,'clay'=>1350,'iron'=>600,'crop'=>90]],
    ],
    'gaul' => [
        // Barracks
        'phalanx'            => ['name' => 'Phalanx',            'attack' => 15, 'def_inf' => 50, 'def_cav' => 60, 'speed' => 5,  'cost' => ['wood'=>100,'clay'=>130,'iron'=>55,'crop'=>30]],
        'swordsman'          => ['name' => 'Swordsman',          'attack' => 65, 'def_inf' => 35, 'def_cav' => 20, 'speed' => 6,  'cost' => ['wood'=>140,'clay'=>165,'iron'=>230,'crop'=>75]],
        // Stable
        'pathfinder'         => ['name' => 'Pathfinder',         'attack' => 0,  'def_inf' => 15, 'def_cav' => 25, 'speed' => 17, 'cost' => ['wood'=>110,'clay'=>120,'iron'=>30,'crop'=>45]],
        'theutates_thunder'  => ['name' => "Theutates Thunder",  'attack' => 90, 'def_inf' => 25, 'def_cav' => 40, 'speed' => 19, 'cost' => ['wood'=>350,'clay'=>450,'iron'=>230,'crop'=>60]],
        'druidrider'         => ['name' => 'Druidrider',         'attack' => 45, 'def_inf' => 50, 'def_cav' => 50, 'speed' => 16, 'cost' => ['wood'=>360,'clay'=>330,'iron'=>280,'crop'=>120]],
        // Workshop
        'ram_gaul'           => ['name' => 'Ram',                'attack' => 50, 'def_inf' => 30, 'def_cav' => 30, 'speed' => 4,  'cost' => ['wood'=>900,'clay'=>360,'iron'=>500,'crop'=>70]],
        'trebuchet'          => ['name' => 'Trebuchet',          'attack' => 70, 'def_inf' => 45, 'def_cav' => 45, 'speed' => 3,  'cost' => ['wood'=>950,'clay'=>1350,'iron'=>600,'crop'=>90]],
    ],
    'teuton' => [
        // Barracks
        'clubswinger'        => ['name' => 'Clubswinger',        'attack' => 40, 'def_inf' => 20, 'def_cav' => 5,  'speed' => 7,  'cost' => ['wood'=>95,'clay'=>75,'iron'=>40,'crop'=>40]],
        'spearman'           => ['name' => 'Spearman',           'attack' => 10, 'def_inf' => 35, 'def_cav' => 50, 'speed' => 7,  'cost' => ['wood'=>145,'clay'=>70,'iron'=>85,'crop'=>40]],
        'axeman'             => ['name' => 'Axeman',             'attack' => 60, 'def_inf' => 30, 'def_cav' => 30, 'speed' => 6,  'cost' => ['wood'=>130,'clay'=>120,'iron'=>170,'crop'=>70]],
        // Stable
        'scout'              => ['name' => 'Scout',              'attack' => 0,  'def_inf' => 10, 'def_cav' => 5,  'speed' => 9,  'cost' => ['wood'=>160,'clay'=>100,'iron'=>80,'crop'=>60]],
        'paladin'            => ['name' => 'Paladin',            'attack' => 55, 'def_inf' => 100,'def_cav' => 40, 'speed' => 10, 'cost' => ['wood'=>370,'clay'=>270,'iron'=>290,'crop'=>75]],
        // Workshop
        'ram_teuton'         => ['name' => 'Ram',                'attack' => 65, 'def_inf' => 30, 'def_cav' => 30, 'speed' => 4,  'cost' => ['wood'=>900,'clay'=>360,'iron'=>500,'crop'=>70]],
        'catapult_teuton'    => ['name' => 'Catapult',           'attack' => 80, 'def_inf' => 70, 'def_cav' => 70, 'speed' => 3,  'cost' => ['wood'=>950,'clay'=>1350,'iron'=>600,'crop'=>90]],
    ],
];

// Colonists (settlers) — shared across all tribes, trained at the Residence.
// Not in the per-tribe $UNITS array because they're identical for everyone.
$GLOBALS['COLONIST_UNIT'] = [
    'name'    => 'Colonist',
    'attack'  => 0,
    'def_inf' => 80,   // they can defend themselves while travelling
    'def_cav' => 80,
    'speed'   => 5,
    'cost'    => ['wood'=>3000,'clay'=>3000,'iron'=>3000,'crop'=>3000],
];

// ---- Building → unit type mapping ----
// Each military building trains a specific category of units.
// Used by building.php to show only that building's units, and by
// enqueue_training() to validate that the unit matches the building.
$GLOBALS['BUILDING_UNITS'] = [
    'barracks'  => [
        'roman'  => ['legionnaire', 'praetorian', 'imperian'],
        'gaul'   => ['phalanx', 'swordsman'],
        'teuton' => ['clubswinger', 'spearman', 'axeman'],
    ],
    'stable'    => [
        'roman'  => ['equites_legati', 'equites_imperatoris'],
        'gaul'   => ['pathfinder', 'theutates_thunder', 'druidrider'],
        'teuton' => ['scout', 'paladin'],
    ],
    'workshop'  => [
        'roman'  => ['ram_roman', 'catapult_roman'],
        'gaul'   => ['ram_gaul', 'trebuchet'],
        'teuton' => ['ram_teuton', 'catapult_teuton'],
    ],
    'residence' => [
        // Colonists are the same for all tribes
        'roman'  => ['colonist'],
        'gaul'   => ['colonist'],
        'teuton' => ['colonist'],
    ],
];

// Helper: get the list of unit_types trained at a given building for a tribe.
function units_for_building($building_type, $tribe) {
    $map = $GLOBALS['BUILDING_UNITS'][$building_type] ?? [];
    return $map[$tribe] ?? [];
}

// Helper: get the building that trains a given unit_type (false if none).
function building_for_unit($unit_type) {
    foreach ($GLOBALS['BUILDING_UNITS'] as $building => $tribes) {
        foreach ($tribes as $tribe => $units) {
            if (in_array($unit_type, $units, true)) return $building;
        }
    }
    return false;
}

// Helper: look up a unit's stats regardless of tribe.
// Returns null if not found.
function get_unit_stats($unit_type) {
    global $UNITS;
    if ($unit_type === 'colonist') return $GLOBALS['COLONIST_UNIT'];
    foreach ($UNITS as $tribe => $units) {
        if (isset($units[$unit_type])) return $units[$unit_type];
    }
    return null;
}

// Helper: list buildings that can be built
function available_buildings() {
    return [
        'main_building' => 'Main Building',
        'warehouse'     => 'Warehouse',
        'granary'       => 'Granary',
        'barracks'      => 'Barracks',
        'stable'        => 'Stable',
        'workshop'      => 'Workshop',
        'marketplace'   => 'Marketplace',
        'embassy'       => 'Embassy',
        'rally_point'   => 'Rally Point',
        'hero_mansion'  => 'Hero Mansion',
        'smithy'        => 'Smithy',
        'academy'       => 'Academy',
        'residence'     => 'Residence',
        'wall'          => 'City Wall',
    ];
}

// ============================================================
// ACADEMY — troop research
// ============================================================
// Each tribe's basic infantry (e.g. Legionnaire, Phalanx, Clubswinger)
// is available as soon as the Barracks is built. ALL other units must
// be RESEARCHED at the Academy before they can be trained.
//
// $UNIT_RESEARCH_REQUIRED lists, for every tribe, which unit_types
// require Academy research before they can be trained. Units that are
// NOT in this list are "free" (available once the Barracks/Stable is built).
//
// $UNIT_RESEARCH_CONFIG defines, for each unit_type that requires
// research:
//   - cost:   resources consumed by the research project
//   - time:   base research time (seconds) at Academy level 1
//   - academy_level: minimum Academy level needed to start this research
//   - requires:   optional list of OTHER unit_types that must be
//                 researched first (chain of prerequisites)
$UNIT_RESEARCH_REQUIRED = [
    'roman' => [
        // Legionnaire is the basic infantry — always available.
        'legionnaire'         => false,
        'praetorian'          => true,
        'imperian'            => true,
        'equites_legati'      => true,
        'equites_imperatoris' => true,
    ],
    'gaul' => [
        'phalanx'             => false,   // basic Gaul infantry
        'swordsman'           => true,
        'pathfinder'          => true,
        'theutates_thunder'   => true,
        'druidrider'          => true,
    ],
    'teuton' => [
        'clubswinger'         => false,   // basic Teuton infantry
        'spearman'            => true,
        'axeman'              => true,
        'scout'               => true,
        'paladin'             => true,
    ],
];

// Helper: does a given unit need Academy research for this tribe?
function unit_requires_research($tribe, $unit_type) {
    global $UNIT_RESEARCH_REQUIRED;
    return !empty($UNIT_RESEARCH_REQUIRED[$tribe][$unit_type]);
}

// Helper: is this unit_type known to this tribe at all?
function unit_belongs_to_tribe($tribe, $unit_type) {
    global $UNITS;
    return isset($UNITS[$tribe][$unit_type]);
}

// Research cost / time / academy level requirement per unit_type.
$UNIT_RESEARCH_CONFIG = [
    // ---- Roman ----
    'praetorian'          => ['cost' => ['wood'=>940,'clay'=>740,'iron'=>630,'crop'=>220], 'time' => 9600,  'academy_level' => 1, 'requires' => []],
    'imperian'            => ['cost' => ['wood'=>1280,'clay'=>1060,'iron'=>880,'crop'=>280], 'time' => 10800, 'academy_level' => 2, 'requires' => ['praetorian']],
    'equites_legati'      => ['cost' => ['wood'=>1440,'clay'=>1060,'iron'=>640,'crop'=>280], 'time' => 12000, 'academy_level' => 3, 'requires' => ['imperian']],
    'equites_imperatoris' => ['cost' => ['wood'=>2320,'clay'=>1180,'iron'=>1540,'crop'=>560], 'time' => 18000, 'academy_level' => 5, 'requires' => ['equites_legati']],
    // ---- Gaul ----
    'swordsman'           => ['cost' => ['wood'=>1000,'clay'=>740,'iron'=>880,'crop'=>320], 'time' => 9600,  'academy_level' => 1, 'requires' => []],
    'pathfinder'          => ['cost' => ['wood'=>1120,'clay'=>740,'iron'=>440,'crop'=>280], 'time' => 10800, 'academy_level' => 2, 'requires' => ['swordsman']],
    'theutates_thunder'   => ['cost' => ['wood'=>2320,'clay'=>1180,'iron'=>880,'crop'=>560], 'time' => 18000, 'academy_level' => 4, 'requires' => ['pathfinder']],
    'druidrider'          => ['cost' => ['wood'=>2560,'clay'=>1180,'iron'=>1440,'crop'=>560], 'time' => 19200, 'academy_level' => 5, 'requires' => ['theutates_thunder']],
    // ---- Teuton ----
    'spearman'            => ['cost' => ['wood'=>880,'clay'=>560,'iron'=>640,'crop'=>240], 'time' => 9600,  'academy_level' => 1, 'requires' => []],
    'axeman'              => ['cost' => ['wood'=>1120,'clay'=>940,'iron'=>880,'crop'=>280], 'time' => 10800, 'academy_level' => 2, 'requires' => ['spearman']],
    'scout'               => ['cost' => ['wood'=>1280,'clay'=>740,'iron'=>640,'crop'=>280], 'time' => 12000, 'academy_level' => 3, 'requires' => ['axeman']],
    'paladin'             => ['cost' => ['wood'=>2240,'clay'=>1180,'iron'=>1540,'crop'=>560], 'time' => 18000, 'academy_level' => 5, 'requires' => ['scout']],
];

// Helper: research time (seconds) for a unit at a given Academy level.
// Higher academy = faster research (-5% per level, max -50%).
function research_time_seconds($base_seconds, $academy_level = 1) {
    $factor = max(0.5, 1.0 - ($academy_level * 0.05));
    return (int)round($base_seconds * $factor / GAME_SERVER_SPEED);
}

// ---- Building prerequisites ----
// Each entry: 'building_type' => [required_building => min_level, ...]
// A building can only be constructed (or upgraded past a certain level)
// if all prerequisites are met.
//
// Reference: classic Travian requirements.
$BUILDING_PREREQUISITES = [
    'main_building' => [],                    // always available
    'warehouse'     => [],                    // always available
    'granary'       => [],                    // always available
    'rally_point'   => [],                    // always available
    'wall'          => ['main_building' => 1],

    'barracks'      => ['main_building' => 3],
    'stable'        => ['main_building' => 3, 'barracks' => 1],
    'workshop'      => ['main_building' => 3, 'barracks' => 5],
    'smithy'        => ['main_building' => 3, 'barracks' => 1],
    'marketplace'   => ['main_building' => 3, 'warehouse' => 1, 'granary' => 1],
    'embassy'       => ['main_building' => 3],
    'hero_mansion'  => ['main_building' => 3, 'rally_point' => 1],
    // The Academy is the centre of military research — it requires a
    // well-developed village: a strong main building, a working barracks,
    // and a smithy to forge the equipment that the scholars will study.
    'academy'       => ['main_building' => 5, 'barracks' => 3, 'smithy' => 1],
    // The Residence is where colonists (settlers) are trained to found
    // new villages. Only the capital can have a Residence.
    'residence'     => ['main_building' => 5, 'rally_point' => 1],
];

// ---- Unique buildings: can only have ONE per village ----
// If true, the building can only exist in a single slot per village.
$UNIQUE_BUILDINGS = [
    'main_building' => true,
    'warehouse'     => false,  // can have multiple
    'granary'       => false,  // can have multiple
    'barracks'      => true,
    'stable'        => true,
    'workshop'      => true,
    'marketplace'   => true,
    'embassy'       => true,
    'rally_point'   => true,
    'hero_mansion'  => true,
    'smithy'        => true,
    'academy'       => true,
    'residence'     => true,
    'wall'          => true,
];

// ---- Max levels per building ----
$BUILDING_MAX_LEVEL = [
    'main_building' => 20,
    'warehouse'     => 20,
    'granary'       => 20,
    'barracks'      => 20,
    'stable'        => 20,
    'workshop'      => 20,
    'marketplace'   => 20,
    'embassy'       => 20,
    'rally_point'   => 20,
    'hero_mansion'  => 20,
    'smithy'        => 20,
    'academy'       => 20,
    'residence'     => 20,
    'wall'          => 20,
];

// Check if prerequisites for a building are satisfied in a given village.
// Returns ['ok' => true] or ['ok' => false, 'error' => 'reason', 'missing' => [...]]
function check_building_prerequisites($building_type, $village_id) {
    global $BUILDING_PREREQUISITES;

    $reqs = $BUILDING_PREREQUISITES[$building_type] ?? [];
    if (empty($reqs)) return ['ok' => true];

    $buildings = db()->fetchAll(
        "SELECT building_type, MAX(level) AS level
         FROM buildings WHERE village_id = ?
         GROUP BY building_type",
        [$village_id]
    );
    $have = [];
    foreach ($buildings as $b) {
        $have[$b['building_type']] = (int)$b['level'];
    }

    $missing = [];
    foreach ($reqs as $req_building => $req_level) {
        $current = $have[$req_building] ?? 0;
        if ($current < $req_level) {
            $missing[] = ucfirst(str_replace('_',' ',$req_building)) . " Lv $req_level (you have Lv $current)";
        }
    }

    if (!empty($missing)) {
        return ['ok' => false, 'error' => 'Missing prerequisites: ' . implode('; ', $missing), 'missing' => $missing];
    }
    return ['ok' => true];
}

// Check if a building already exists in the village (for unique buildings).
// Returns true if the building_type already exists in any slot OTHER than $exclude_position.
function building_already_exists($building_type, $village_id, $exclude_position = -1) {
    global $UNIQUE_BUILDINGS;
    if (empty($UNIQUE_BUILDINGS[$building_type])) return false;  // not unique → can have multiple

    $existing = db()->fetch(
        "SELECT id FROM buildings WHERE village_id = ? AND building_type = ? AND position != ?",
        [$village_id, $building_type, $exclude_position]
    );
    return $existing ? true : false;
}
