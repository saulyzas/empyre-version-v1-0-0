<?php
/**
 * MYEMPIRE - Migration script.
 *
 * Run this once after updating from a previous version.
 * It adds new tables (training_queue, movements) without touching existing data.
 *
 * Usage:
 *   - Open http://localhost/myempire/migrate.php in your browser, OR
 *   - Run from CLI:  php migrate.php
 *
 * After successful migration, you can delete this file.
 */
require_once __DIR__ . '/app/lib/helpers.php';
init_session();

echo "<!DOCTYPE html><html><head><title>MYEMPIRE Migration</title>";
echo "<style>body{font-family:sans-serif;padding:40px;background:#f4ead5;color:#2a1f15;}";
echo ".ok{color:#4a7a3a;font-weight:bold;} .err{color:#8e2a26;font-weight:bold;}";
echo "pre{background:#2a1f15;color:#fdf6e3;padding:8px;border-radius:4px;}</style></head><body>";
echo "<h1>MYEMPIRE Migration</h1>";

$db = db();

// Detect driver
$driver = $db->pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
echo "<p>Database driver: <strong>$driver</strong></p>";

// List of new tables to add (idempotent — uses CREATE TABLE IF NOT EXISTS)
$migrations = [];

if ($driver === 'sqlite') {
    $migrations = [
        'training_queue' => "CREATE TABLE IF NOT EXISTS training_queue (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            village_id      INTEGER NOT NULL,
            unit_type       TEXT NOT NULL,
            count           INTEGER NOT NULL,
            finishes_at     TEXT NOT NULL,
            FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE
        )",
        'unit_research' => "CREATE TABLE IF NOT EXISTS unit_research (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            village_id      INTEGER NOT NULL,
            unit_type       TEXT NOT NULL,
            researched_at   TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE,
            UNIQUE(village_id, unit_type)
        )",
        'research_queue' => "CREATE TABLE IF NOT EXISTS research_queue (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            village_id      INTEGER NOT NULL,
            unit_type       TEXT NOT NULL,
            finishes_at     TEXT NOT NULL,
            FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE
        )",
        'movements' => "CREATE TABLE IF NOT EXISTS movements (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            from_village_id INTEGER NOT NULL,
            to_village_id   INTEGER NOT NULL,
            type            TEXT NOT NULL CHECK(type IN ('attack','reinforcement','return')),
            troops_json     TEXT NOT NULL DEFAULT '{}',
            loot_json       TEXT NOT NULL DEFAULT '{}',
            started_at      TEXT NOT NULL,
            arrives_at      TEXT NOT NULL,
            status          TEXT NOT NULL DEFAULT 'in_progress' CHECK(status IN ('in_progress','completed')),
            FOREIGN KEY(from_village_id) REFERENCES villages(id) ON DELETE CASCADE,
            FOREIGN KEY(to_village_id)   REFERENCES villages(id) ON DELETE CASCADE
        )",
        'resource_movements' => "CREATE TABLE IF NOT EXISTS resource_movements (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            from_village_id INTEGER NOT NULL,
            to_village_id   INTEGER NOT NULL,
            wood            INTEGER NOT NULL DEFAULT 0,
            clay            INTEGER NOT NULL DEFAULT 0,
            iron            INTEGER NOT NULL DEFAULT 0,
            crop            INTEGER NOT NULL DEFAULT 0,
            merchants_used  INTEGER NOT NULL DEFAULT 1,
            started_at      TEXT NOT NULL,
            arrives_at      TEXT NOT NULL,
            status          TEXT NOT NULL DEFAULT 'in_progress' CHECK(status IN ('in_progress','completed')),
            FOREIGN KEY(from_village_id) REFERENCES villages(id) ON DELETE CASCADE,
            FOREIGN KEY(to_village_id)   REFERENCES villages(id) ON DELETE CASCADE
        )",
        'trade_offers' => "CREATE TABLE IF NOT EXISTS trade_offers (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            player_id           INTEGER NOT NULL,
            village_id          INTEGER NOT NULL,
            offer_resource      TEXT NOT NULL CHECK(offer_resource IN ('wood','clay','iron','crop')),
            offer_amount        INTEGER NOT NULL,
            want_resource       TEXT NOT NULL CHECK(want_resource IN ('wood','clay','iron','crop')),
            want_amount         INTEGER NOT NULL,
            max_transport_hours INTEGER NOT NULL DEFAULT 24,
            created_at          TEXT NOT NULL DEFAULT (datetime('now')),
            expires_at          TEXT NOT NULL,
            status              TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','accepted','cancelled','expired')),
            FOREIGN KEY(player_id)  REFERENCES players(id)  ON DELETE CASCADE,
            FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE
        )",
    ];
} elseif ($driver === 'mysql') {
    $migrations = [
        'training_queue' => "CREATE TABLE IF NOT EXISTS `training_queue` (
            `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `village_id`      INT UNSIGNED NOT NULL,
            `unit_type`       VARCHAR(40) NOT NULL,
            `count`           INT NOT NULL,
            `finishes_at`     DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_tq_village` (`village_id`),
            CONSTRAINT `fk_tq_village` FOREIGN KEY (`village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'unit_research' => "CREATE TABLE IF NOT EXISTS `unit_research` (
            `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `village_id`      INT UNSIGNED NOT NULL,
            `unit_type`       VARCHAR(40) NOT NULL,
            `researched_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_ur_village_unit` (`village_id`, `unit_type`),
            KEY `idx_ur_village` (`village_id`),
            CONSTRAINT `fk_ur_village` FOREIGN KEY (`village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'research_queue' => "CREATE TABLE IF NOT EXISTS `research_queue` (
            `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `village_id`      INT UNSIGNED NOT NULL,
            `unit_type`       VARCHAR(40) NOT NULL,
            `finishes_at`     DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_rq_village` (`village_id`),
            KEY `idx_rq_finishes` (`finishes_at`),
            CONSTRAINT `fk_rq_village` FOREIGN KEY (`village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'movements' => "CREATE TABLE IF NOT EXISTS `movements` (
            `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `from_village_id` INT UNSIGNED NOT NULL,
            `to_village_id`   INT UNSIGNED NOT NULL,
            `type`            ENUM('attack','reinforcement','return') NOT NULL,
            `troops_json`     TEXT NOT NULL,
            `loot_json`       TEXT NOT NULL,
            `started_at`      DATETIME NOT NULL,
            `arrives_at`      DATETIME NOT NULL,
            `status`          ENUM('in_progress','completed') NOT NULL DEFAULT 'in_progress',
            PRIMARY KEY (`id`),
            KEY `idx_mov_from` (`from_village_id`),
            KEY `idx_mov_to` (`to_village_id`),
            CONSTRAINT `fk_mov_from` FOREIGN KEY (`from_village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_mov_to` FOREIGN KEY (`to_village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'resource_movements' => "CREATE TABLE IF NOT EXISTS `resource_movements` (
            `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `from_village_id` INT UNSIGNED NOT NULL,
            `to_village_id`   INT UNSIGNED NOT NULL,
            `wood`            INT NOT NULL DEFAULT 0,
            `clay`            INT NOT NULL DEFAULT 0,
            `iron`            INT NOT NULL DEFAULT 0,
            `crop`            INT NOT NULL DEFAULT 0,
            `merchants_used`  INT NOT NULL DEFAULT 1,
            `started_at`      DATETIME NOT NULL,
            `arrives_at`      DATETIME NOT NULL,
            `status`          ENUM('in_progress','completed') NOT NULL DEFAULT 'in_progress',
            PRIMARY KEY (`id`),
            KEY `idx_rm_from` (`from_village_id`),
            KEY `idx_rm_to` (`to_village_id`),
            CONSTRAINT `fk_rm_from` FOREIGN KEY (`from_village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_rm_to` FOREIGN KEY (`to_village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'trade_offers' => "CREATE TABLE IF NOT EXISTS `trade_offers` (
            `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `player_id`           INT UNSIGNED NOT NULL,
            `village_id`          INT UNSIGNED NOT NULL,
            `offer_resource`      ENUM('wood','clay','iron','crop') NOT NULL,
            `offer_amount`        INT NOT NULL,
            `want_resource`       ENUM('wood','clay','iron','crop') NOT NULL,
            `want_amount`         INT NOT NULL,
            `max_transport_hours` INT NOT NULL DEFAULT 24,
            `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `expires_at`          DATETIME NOT NULL,
            `status`              ENUM('active','accepted','cancelled','expired') NOT NULL DEFAULT 'active',
            PRIMARY KEY (`id`),
            KEY `idx_to_player` (`player_id`),
            KEY `idx_to_village` (`village_id`),
            KEY `idx_to_status` (`status`),
            CONSTRAINT `fk_to_player` FOREIGN KEY (`player_id`)
                REFERENCES `players` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_to_village` FOREIGN KEY (`village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
}

$ok_count = 0;
$err_count = 0;

foreach ($migrations as $name => $sql) {
    echo "<h3>Table: $name</h3>";
    try {
        $db->pdo()->exec($sql);
        echo "<p class='ok'>✓ Created (or already exists).</p>";
        $ok_count++;
    } catch (Throwable $e) {
        echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<pre>" . htmlspecialchars($sql) . "</pre>";
        $err_count++;
    }
}

// Also recalculate population for all existing villages
echo "<h3>Recalculate Population</h3>";
try {
    $villages = $db->fetchAll("SELECT id, player_id FROM villages");
    foreach ($villages as $v) {
        $pop = recalculate_population($v['id']);
        echo "<p class='ok'>✓ Village #{$v['id']}: population set to $pop</p>";
    }
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

// Fix missing village data (resources, resource_fields, buildings) for existing villages
echo "<h3>Fix Missing Village Data</h3>";
try {
    $villages = $db->fetchAll("SELECT id FROM villages");
    $fixed = 0;
    foreach ($villages as $v) {
        $vid = $v['id'];
        $has_res = $db->fetch("SELECT village_id FROM resources WHERE village_id = ?", [$vid]);
        $has_fields = (int)$db->fetchColumn("SELECT COUNT(*) FROM resource_fields WHERE village_id = ?", [$vid]);
        if (!$has_res || $has_fields === 0) {
            ensure_village_data($vid);
            $fixed++;
            echo "<p class='ok'>✓ Village #{$vid}: initialized missing data (resources: " . ($has_res ? 'yes' : 'no') . ", fields: {$has_fields})</p>";
        }
    }
    if ($fixed === 0) {
        echo "<p class='ok'>✓ All villages already have complete data.</p>";
    } else {
        echo "<p class='ok'>✓ Fixed {$fixed} village(es) with missing data.</p>";
    }
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

// Recalculate warehouse/granary capacity for all villages
echo "<h3>Recalculate Warehouse/Granary Capacity</h3>";
try {
    $villages = $db->fetchAll("SELECT id FROM villages");
    $recalc = 0;
    foreach ($villages as $v) {
        $caps = recalculate_capacity($v['id']);
        $recalc++;
        echo "<p class='ok'>✓ Village #{$v['id']}: wood_cap={$caps['wood_cap']} clay_cap={$caps['clay_cap']} iron_cap={$caps['iron_cap']} crop_cap={$caps['crop_cap']}</p>";
    }
    echo "<p class='ok'>✓ Recalculated capacity for {$recalc} village(s).</p>";
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

// Clean up invalid data in movements table
echo "<h3>Clean Invalid Movements Data</h3>";
try {
    // Delete movements with invalid type values
    $valid_types = ['attack', 'reinforcement', 'return'];
    $all_movements = $db->fetchAll("SELECT id, type, status FROM movements WHERE status = 'in_progress'");
    $cleaned = 0;
    foreach ($all_movements as $m) {
        if (!in_array($m['type'], $valid_types, true)) {
            $db->query("DELETE FROM movements WHERE id = ?", [$m['id']]);
            $cleaned++;
            echo "<p class='ok'>✓ Deleted movement #{$m['id']} with invalid type: " . htmlspecialchars($m['type']) . "</p>";
        }
        if (!in_array($m['status'], ['in_progress', 'completed'], true)) {
            $db->query("DELETE FROM movements WHERE id = ?", [$m['id']]);
            $cleaned++;
            echo "<p class='ok'>✓ Deleted movement #{$m['id']} with invalid status: " . htmlspecialchars($m['status']) . "</p>";
        }
    }
    // Also delete movements referencing non-existent villages
    $orphaned = $db->fetchAll(
        "SELECT m.id FROM movements m
         LEFT JOIN villages v1 ON m.from_village_id = v1.id
         LEFT JOIN villages v2 ON m.to_village_id = v2.id
         WHERE v1.id IS NULL OR v2.id IS NULL"
    );
    foreach ($orphaned as $o) {
        $db->query("DELETE FROM movements WHERE id = ?", [$o['id']]);
        $cleaned++;
        echo "<p class='ok'>✓ Deleted orphaned movement #{$o['id']} (references non-existent village)</p>";
    }
    if ($cleaned === 0) {
        echo "<p class='ok'>✓ No invalid movements found.</p>";
    } else {
        echo "<p class='ok'>✓ Cleaned {$cleaned} invalid movement(s).</p>";
    }
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

// Clean up invalid resource_movements
echo "<h3>Clean Invalid Resource Movements</h3>";
try {
    $orphaned_rm = $db->fetchAll(
        "SELECT rm.id FROM resource_movements rm
         LEFT JOIN villages v1 ON rm.from_village_id = v1.id
         LEFT JOIN villages v2 ON rm.to_village_id = v2.id
         WHERE v1.id IS NULL OR v2.id IS NULL"
    );
    $cleaned_rm = 0;
    foreach ($orphaned_rm as $o) {
        $db->query("DELETE FROM resource_movements WHERE id = ?", [$o['id']]);
        $cleaned_rm++;
    }
    if ($cleaned_rm === 0) {
        echo "<p class='ok'>✓ No invalid resource movements found.</p>";
    } else {
        echo "<p class='ok'>✓ Cleaned {$cleaned_rm} invalid resource movement(s).</p>";
    }
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

// Add last_activity column to players (for online/active stats)
echo "<h3>Add last_activity column to players</h3>";
try {
    $driver_check = $db->pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
    // Check whether the column already exists
    if ($driver_check === 'sqlite') {
        $cols = $db->fetchAll("PRAGMA table_info(players)");
    } else {
        $cols = $db->fetchAll("SHOW COLUMNS FROM `players`");
    }
    $has_last_activity = false;
    foreach ($cols as $c) {
        $field_name = $c['name'] ?? $c['Field'] ?? '';
        if (strtolower($field_name) === 'last_activity') {
            $has_last_activity = true;
            break;
        }
    }
    if (!$has_last_activity) {
        if ($driver_check === 'sqlite') {
            $db->pdo()->exec("ALTER TABLE players ADD COLUMN last_activity TEXT");
        } else {
            $db->pdo()->exec("ALTER TABLE `players` ADD COLUMN `last_activity` DATETIME NULL");
            // Add index for fast online-queries
            try {
                $db->pdo()->exec("ALTER TABLE `players` ADD INDEX `idx_players_last_activity` (`last_activity`)");
            } catch (Throwable $e2) { /* index might already exist */ }
        }
        echo "<p class='ok'>✓ Added last_activity column to players table.</p>";

        // Backfill last_activity = last_login (or created_at for never-logged-in players)
        $db->query("UPDATE players SET last_activity = COALESCE(last_login, created_at) WHERE last_activity IS NULL", []);
        echo "<p class='ok'>✓ Backfilled last_activity from last_login/created_at.</p>";
    } else {
        echo "<p class='ok'>✓ last_activity column already exists.</p>";
    }
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

// Add admin columns (is_admin, is_banned, banned_reason) to players
echo "<h3>Add admin/ban columns to players</h3>";
try {
    $driver_check = $db->pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver_check === 'sqlite') {
        $cols = $db->fetchAll("PRAGMA table_info(players)");
    } else {
        $cols = $db->fetchAll("SHOW COLUMNS FROM `players`");
    }
    $existing = [];
    foreach ($cols as $c) {
        $existing[strtolower($c['name'] ?? $c['Field'] ?? '')] = true;
    }

    $added = [];
    if (empty($existing['is_admin'])) {
        if ($driver_check === 'sqlite') {
            $db->pdo()->exec("ALTER TABLE players ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0");
        } else {
            $db->pdo()->exec("ALTER TABLE `players` ADD COLUMN `is_admin` TINYINT NOT NULL DEFAULT 0");
            try { $db->pdo()->exec("ALTER TABLE `players` ADD INDEX `idx_players_is_admin` (`is_admin`)"); } catch (Throwable $e2) {}
        }
        $added[] = 'is_admin';
    }
    if (empty($existing['is_banned'])) {
        if ($driver_check === 'sqlite') {
            $db->pdo()->exec("ALTER TABLE players ADD COLUMN is_banned INTEGER NOT NULL DEFAULT 0");
        } else {
            $db->pdo()->exec("ALTER TABLE `players` ADD COLUMN `is_banned` TINYINT NOT NULL DEFAULT 0");
            try { $db->pdo()->exec("ALTER TABLE `players` ADD INDEX `idx_players_is_banned` (`is_banned`)"); } catch (Throwable $e2) {}
        }
        $added[] = 'is_banned';
    }
    if (empty($existing['banned_reason'])) {
        if ($driver_check === 'sqlite') {
            $db->pdo()->exec("ALTER TABLE players ADD COLUMN banned_reason TEXT");
        } else {
            $db->pdo()->exec("ALTER TABLE `players` ADD COLUMN `banned_reason` VARCHAR(255) NULL");
        }
        $added[] = 'banned_reason';
    }

    if (!empty($added)) {
        echo "<p class='ok'>✓ Added columns: " . implode(', ', $added) . ".</p>";
    } else {
        echo "<p class='ok'>✓ All admin/ban columns already exist.</p>";
    }
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p class='ok'>$ok_count OK</p>";
if ($err_count > 0) echo "<p class='err'>$err_count errors</p>";

echo "<p style='margin-top:24px;'><a href='" . url('/') . "'>← Back to game</a></p>";
echo "<p style='font-size:12px;color:#5a4a30;margin-top:16px;'>You can now safely delete migrate.php.</p>";
echo "</body></html>";
