<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

// Find the building
$pos = (int)($_GET['id'] ?? -1);
$buildings = get_buildings($village['id']);
$buildings_by_pos = [];
foreach ($buildings as $b) $buildings_by_pos[$b['position']] = $b;

$building = $buildings_by_pos[$pos] ?? null;
if (!$building) {
    redirect('/village.php');
}

// Max level check (use per-building limit if defined)
global $BUILDING_MAX_LEVEL, $UNITS, $UNIT_RESEARCH_CONFIG, $UNIT_RESEARCH_REQUIRED;
$max_level = $BUILDING_MAX_LEVEL[$building['building_type']] ?? MAX_BUILDING_LEVEL;
$next_level = $building['level'] + 1;
$cost = calc_building_cost($building['building_type'], $next_level);
$time_sec = calc_building_time($building['building_type'], $next_level, $buildings_by_pos[0]['level'] ?? 1);
$can_afford = ($resources['wood'] >= $cost['wood'] && $resources['clay'] >= $cost['clay']
            && $resources['iron'] >= $cost['iron'] && $resources['crop'] >= $cost['crop']);
$is_max = $building['level'] >= $max_level;

// Prerequisites for upgrading (re-check)
$prereq = check_building_prerequisites($building['building_type'], $village['id']);
$prereq_ok = $prereq['ok'];

// ---- Handle POST actions ----
// Three kinds of POSTs come to this page:
//   1. Upgrade the building (default — no "action" field)
//   2. Research a unit at the Academy (action="research", unit_type=...)
//   3. Train troops in a military building (action="train", unit_type=..., count=...)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'upgrade';

    if ($action === 'research' && $building['building_type'] === 'academy') {
        // Research a new unit at the Academy
        $unit_type = $_POST['unit_type'] ?? '';
        $r = enqueue_research($village['id'], $unit_type);
        if (!$r['ok']) {
            $research_error = $r['error'];
        } else {
            // Reload to refresh the research queue display
            redirect('/building.php?id=' . $pos);
        }
    } elseif ($action === 'train') {
        // Train troops in a military building (barracks / stable / workshop / residence)
        $unit_type = $_POST['unit_type'] ?? '';
        $count     = (int)($_POST['count'] ?? 0);
        // Pass the building type so enqueue_training can verify the unit belongs here.
        $r = enqueue_training($village['id'], $unit_type, $count, (int)$building['level'], $building['building_type']);
        if (!$r['ok']) {
            $train_error = $r['error'];
        } else {
            // Reload to refresh the training queue display
            redirect('/building.php?id=' . $pos);
        }
    } elseif (!$is_max && $can_afford && $prereq_ok) {
        // Default: upgrade the building
        $result = enqueue_build($village['id'], 'building', $building['building_type'], $building['position'], $next_level, $cost, $time_sec);
        if ($result['ok']) {
            redirect('/village.php');
        } else {
            $error = $result['error'];
        }
    }
}
$error = $error ?? '';
$research_error = $research_error ?? '';
$train_error = $train_error ?? '';

$building_descriptions = [
    'main_building' => 'The heart of your village. Higher levels reduce build times for all other structures.',
    'warehouse'     => 'Stores wood, clay, and iron. Each level increases storage capacity by 800.',
    'granary'       => 'Stores crop. Each level increases crop storage capacity by 800.',
    'barracks'      => 'Train infantry units. Higher levels train troops faster.',
    'stable'        => 'Train cavalry units. Higher levels train mounts faster.',
    'workshop'      => 'Build siege engines — rams and catapults. Higher levels reduce production time.',
    'marketplace'   => 'Trade resources with other villages. Higher levels allow more merchants.',
    'embassy'       => 'Found or join alliances. Higher levels support larger alliances.',
    'rally_point'   => 'Send and receive troops. Rallies reinforcements here.',
    'hero_mansion'  => 'Recruit and manage your hero. Higher levels unlock more hero slots.',
    'smithy'        => 'Research unit upgrades. Higher levels unlock stronger troops.',
    'academy'       => 'Scholars study new troop types here. Each level lets you research stronger units and speeds up ongoing research.',
    'residence'     => 'Train colonists (settlers) here. Three colonists can found a new village. Higher levels speed up colonist training.',
    'wall'          => 'Defensive structure that boosts village defense significantly.',
];

// Buildings that train troops (each shows its own training panel below).
$TRAINING_BUILDINGS = ['barracks', 'stable', 'workshop', 'residence'];

$page_title = 'Building';
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:600px;margin:0 auto;">
    <div class="card-header">
        <?= e(ucfirst(str_replace('_', ' ', $building['building_type']))) ?> (Level <?= (int)$building['level'] ?>)
    </div>

    <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;">
        <img src="<?= img_url("buildings/{$building['building_type']}.png") ?>"
             alt="<?= e($building['building_type']) ?>" style="width:128px;height:128px;image-rendering:pixelated;border:3px solid var(--c-outline);border-radius:8px;">
        <div style="flex:1;">
            <h3 style="color:var(--c-wood-dk);margin-bottom:4px;">
                <?= e(ucfirst(str_replace('_', ' ', $building['building_type']))) ?>
            </h3>
            <p style="font-size:13px;color:var(--c-text-soft);">
                <?= e($building_descriptions[$building['building_type']] ?? 'A useful village structure.') ?>
            </p>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($is_max): ?>
    <div class="alert alert-info">This building has reached the maximum level (Lv <?= (int)$building['level'] ?>/<?= $max_level ?>).</div>
    <?php elseif (!$prereq_ok): ?>
    <div class="alert alert-error">Cannot upgrade: <?= e($prereq['error']) ?></div>
    <?php else: ?>
    <table class="data">
        <tr>
            <th>Current Level</th>
            <td><?= (int)$building['level'] ?> / <?= $max_level ?></td>
        </tr>
        <tr>
            <th>Upgrade to Level</th>
            <td><?= $next_level ?></td>
        </tr>
        <tr>
            <th>Cost</th>
            <td>
                <span class="res-icon res-wood"></span> <?= format_number($cost['wood']) ?> &nbsp;
                <span class="res-icon res-clay"></span> <?= format_number($cost['clay']) ?> &nbsp;
                <span class="res-icon res-iron"></span> <?= format_number($cost['iron']) ?> &nbsp;
                <span class="res-icon res-crop"></span> <?= format_number($cost['crop']) ?>
            </td>
        </tr>
        <tr>
            <th>Build Time</th>
            <td><?= e(format_seconds($time_sec)) ?></td>
        </tr>
        <tr>
            <th>You have</th>
            <td>
                <span class="res-icon res-wood"></span> <?= format_number($resources['wood']) ?> &nbsp;
                <span class="res-icon res-clay"></span> <?= format_number($resources['clay']) ?> &nbsp;
                <span class="res-icon res-iron"></span> <?= format_number($resources['iron']) ?> &nbsp;
                <span class="res-icon res-crop"></span> <?= format_number($resources['crop']) ?>
            </td>
        </tr>
    </table>

    <form method="POST" style="margin-top:16px;text-align:center;">
        <button type="submit" class="btn btn-gold btn-lg" <?= !$can_afford ? 'disabled' : '' ?>>
            <?= $can_afford ? "Upgrade to Level $next_level" : 'Not Enough Resources' ?>
        </button>
    </form>
    <?php endif; ?>

    <!-- Special building actions -->
    <?php
    // Military buildings (barracks, stable, workshop, residence) do NOT get
    // an external "action" link — training takes place INSIDE the building
    // page itself (see the training panel rendered below), per the spec
    // "all logic/action takes place in buildings".
    $building_actions = [
        'marketplace'  => ['url' => '/marketplace.php',  'label' => '🏪 Open Marketplace', 'desc' => 'Buy, sell, exchange, and send resources'],
        'hero_mansion' => ['url' => '/hero.php',          'label' => '🦸 Hero Mansion', 'desc' => 'Manage your hero'],
    ];
    ?>
    <?php if (isset($building_actions[$building['building_type']])):
        $action = $building_actions[$building['building_type']];
    ?>
    <div style="margin-top:24px;padding:16px;background:#fff8d6;border:2px solid var(--c-gold-dk);border-radius:8px;text-align:center;">
        <h3 style="color:var(--c-wood-dk);margin-bottom:8px;"><?= $action['label'] ?></h3>
        <p style="font-size:13px;color:var(--c-text-soft);margin-bottom:12px;"><?= $action['desc'] ?></p>
        <a href="<?= url($action['url']) ?>" class="btn btn-gold btn-lg"><?= $action['label'] ?></a>
    </div>
    <?php endif; ?>

    <p style="text-align:center;margin-top:16px;">
        <a href="<?= url('/village.php') ?>">← Back to Village</a>
    </p>
</div>

<?php if ($building['building_type'] === 'academy'):
    // ============================================================
    // ACADEMY RESEARCH PANEL
    // All research action takes place HERE, inside the Academy
    // building page. No separate research.php page exists.
    // Rendered OUTSIDE the 600px building card so the research
    // table has enough horizontal room to breathe.
    // ============================================================
    $player = current_player();
    $tribe  = $player['tribe'];
    $academy_level = (int)$building['level'];
    $researched = get_researched_units($village['id']);
    $rqueue     = get_research_queue($village['id']);
    $rqueue_set = [];
    foreach ($rqueue as $q) $rqueue_set[$q['unit_type']] = $q;
    $cavalry_keys = ['equites_legati','equites_imperatoris','pathfinder','theutates_thunder','druidrider','scout','paladin'];
?>
<div class="card" style="margin-top:16px;">
    <div class="card-header">🔬 Academy Research (Lv <?= $academy_level ?>)</div>

    <p style="font-size:12px;color:var(--c-text-soft);margin-bottom:12px;">
        Before advanced troops can be trained at the Barracks or Stable, they must be researched here.
        Each Academy level unlocks stronger units and accelerates ongoing research (−5% per level, up to −50%).
    </p>

    <?php if ($research_error): ?>
    <div class="alert alert-error" style="margin-bottom:12px;"><?= e($research_error) ?></div>
    <?php endif; ?>

    <!-- In-progress research queue -->
    <?php if (!empty($rqueue)): ?>
    <h4 style="font-size:12px;color:var(--c-wood-dk);margin-bottom:6px;">In Progress</h4>
    <table class="data" style="margin-bottom:12px;font-size:12px;">
        <thead>
            <tr><th>Unit</th><th>Finishes in</th></tr>
        </thead>
        <tbody>
        <?php foreach ($rqueue as $q): ?>
        <tr>
            <td style="display:flex;align-items:center;gap:6px;">
                <img src="<?= img_url("troops/{$tribe}_{$q['unit_type']}.png") ?>" width="20" height="20" alt="" style="image-rendering:pixelated;">
                <?= e(ucfirst(str_replace('_',' ',$q['unit_type']))) ?>
            </td>
            <td>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($q['finishes_at']) ?>">...</span>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <!-- Available research projects -->
    <h4 style="font-size:12px;color:var(--c-wood-dk);margin-bottom:6px;">Research Projects</h4>
    <table class="data" style="font-size:12px;">
        <thead>
            <tr>
                <th>Unit</th>
                <th>Requires</th>
                <th>Cost</th>
                <th>Time</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $shown_any_research = false;
        foreach ($UNITS[$tribe] as $unit_key => $u):
            // Only show units that require research
            if (!unit_requires_research($tribe, $unit_key)) continue;
            $shown_any_research = true;
            $cfg = $UNIT_RESEARCH_CONFIG[$unit_key];
            $is_done    = !empty($researched[$unit_key]);
            $is_queued  = isset($rqueue_set[$unit_key]);
            $is_cavalry = in_array($unit_key, $cavalry_keys, true);

            // Check prerequisites
            $check = check_unit_research_prerequisites($village['id'], $unit_key, $player);
            $check_ok = $check['ok'];

            // Affordability
            $rcost = $cfg['cost'];
            $can_afford_r = ($resources['wood'] >= $rcost['wood'] && $resources['clay'] >= $rcost['clay']
                          && $resources['iron'] >= $rcost['iron'] && $resources['crop'] >= $rcost['crop']);

            // Research time at current academy level
            $rtime = research_time_seconds($cfg['time'], $academy_level);

            // Prerequisite chain text
            $req_parts = [];
            $req_parts[] = "Academy Lv" . $cfg['academy_level'] . " <small>(have $academy_level)</small>";
            foreach ($cfg['requires'] as $req_unit) {
                $ok = !empty($researched[$req_unit]);
                $color = $ok ? '#4a7a3a' : '#8e2a26';
                $sym = $ok ? '✓' : '✗';
                $req_parts[] = "<span style='color:$color;'>$sym " . ucfirst(str_replace('_',' ',$req_unit)) . "</span>";
            }
            $req_text = implode('<br>', $req_parts);
        ?>
        <tr <?= $is_done ? 'style="opacity:0.5;"' : (!$check_ok ? 'style="opacity:0.7;"' : '') ?>>
            <td style="display:flex;align-items:center;gap:6px;">
                <img src="<?= img_url("troops/{$tribe}_{$unit_key}.png") ?>" width="28" height="28" alt="" style="image-rendering:pixelated;">
                <div>
                    <strong><?= e($u['name']) ?></strong><br>
                    <small>
                        <?= $is_cavalry ? '🐎 Cavalry' : '⚔️ Infantry' ?> ·
                        ATK <?= $u['attack'] ?>/DEF <?= $u['def_inf'] ?>/<?= $u['def_cav'] ?>/SPD <?= $u['speed'] ?>
                    </small>
                </div>
            </td>
            <td style="font-size:11px;"><?= $req_text ?></td>
            <td style="font-size:11px;">
                <span class="res-icon res-wood"></span><?= format_number($rcost['wood']) ?><br>
                <span class="res-icon res-clay"></span><?= format_number($rcost['clay']) ?><br>
                <span class="res-icon res-iron"></span><?= format_number($rcost['iron']) ?><br>
                <span class="res-icon res-crop"></span><?= format_number($rcost['crop']) ?>
            </td>
            <td style="font-size:11px;"><?= e(format_seconds($rtime)) ?></td>
            <td>
                <?php if ($is_done): ?>
                    <span style="font-size:11px;color:#4a7a3a;font-weight:bold;">✓ Researched</span>
                <?php elseif ($is_queued): ?>
                    <span style="font-size:11px;color:var(--c-gold-dk);font-weight:bold;">⏳ In Queue</span>
                <?php elseif (!$check_ok): ?>
                    <span style="font-size:11px;color:#8e2a26;" title="<?= e($check['error']) ?>">Locked</span>
                <?php else: ?>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="research">
                        <input type="hidden" name="unit_type" value="<?= e($unit_key) ?>">
                        <button type="submit" class="btn btn-green btn-sm" <?= !$can_afford_r ? 'disabled' : '' ?>>
                            <?= $can_afford_r ? 'Research' : 'Too Expensive' ?>
                        </button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$shown_any_research): ?>
        <tr>
            <td colspan="5" style="text-align:center;color:var(--c-text-soft);padding:16px;">
                All units of your tribe are either already researched or do not require research.
            </td>
        </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div style="margin-top:12px;padding:8px;background:#fff8d6;border-left:4px solid #f0c34b;font-size:11px;">
        <strong>ℹ️ How research works:</strong>
        <ul style="margin:4px 0 0 18px;">
            <li>Basic infantry (Legionnaire / Phalanx / Clubswinger) is always available once the Barracks is built.</li>
            <li>Advanced units must be researched here at the Academy before they can be trained.</li>
            <li>Some units require a previous unit to be researched first — build a research chain.</li>
            <li>Higher Academy level unlocks more units and speeds up research time.</li>
            <li>Each research project is per-village: a second village must re-research its own troops.</li>
        </ul>
    </div>
</div>
<?php endif; ?>

<?php
// ============================================================
// MILITARY BUILDING — TROOP TRAINING PANEL
// Shown for barracks, stable, workshop, residence.
// Each building shows ONLY the units it trains (per $BUILDING_UNITS map).
// ============================================================
if (in_array($building['building_type'], $TRAINING_BUILDINGS, true)):
    $player_obj = current_player();
    $tribe      = $player_obj['tribe'];
    $bld_level  = (int)$building['level'];
    $trainable  = units_for_building($building['building_type'], $tribe);
    $researched = get_researched_units($village['id']);
    $tqueue     = get_training_queue($village['id']);
    $village_troops = get_village_troops($village['id']);

    // Build a lookup of currently-owned counts for each trainable unit
    $owned_counts = [];
    foreach ($village_troops as $t) {
        $owned_counts[$t['unit_type']] = (int)$t['count'];
    }

    // Category label for the panel header
    $bld_labels = [
        'barracks'  => ['title' => '⚔️ Infantry Training',     'desc' => 'Foot soldiers — cheap, versatile, slow.'],
        'stable'    => ['title' => '🐎 Cavalry Training',       'desc' => 'Mounted units — fast, expensive, hard-hitting.'],
        'workshop'  => ['title' => ' bombardment Workshop',     'desc' => 'Siege engines — slow but devastating against walls.'],
        'residence' => ['title' => ' settlers Residence',       'desc' => 'Colonists found new villages. 3 colonists + an empty cell = new village.'],
    ];
    $bld_label = $bld_labels[$building['building_type']] ?? ['title' => 'Training', 'desc' => ''];
?>
<div class="card" style="margin-top:16px;">
    <div class="card-header"><?= $bld_label['title'] ?> (Lv <?= $bld_level ?>)</div>
    <p style="font-size:12px;color:var(--c-text-soft);margin-bottom:12px;">
        <?= e($bld_label['desc']) ?> Higher building levels train troops faster (−3% per level, max −30%).
    </p>

    <?php if ($train_error): ?>
    <div class="alert alert-error" style="margin-bottom:12px;"><?= e($train_error) ?></div>
    <?php endif; ?>

    <!-- Training queue -->
    <?php if (!empty($tqueue)): ?>
    <h4 style="font-size:12px;color:var(--c-wood-dk);margin-bottom:6px;">⏳ Training Queue</h4>
    <table class="data" style="margin-bottom:12px;font-size:12px;">
        <thead>
            <tr><th>Unit</th><th>Count</th><th>Finishes in</th></tr>
        </thead>
        <tbody>
        <?php foreach ($tqueue as $q):
            $stats = get_unit_stats($q['unit_type']);
            $uname = $stats ? $stats['name'] : ucfirst(str_replace('_',' ',$q['unit_type']));
        ?>
        <tr>
            <td><?= e($uname) ?></td>
            <td><?= (int)$q['count'] ?></td>
            <td>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($q['finishes_at']) ?>">...</span>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <?php if (empty($trainable)): ?>
    <p style="color:var(--c-text-soft);text-align:center;padding:16px;">
        No units are trainable at this building for your tribe.
    </p>
    <?php else: ?>
    <h4 style="font-size:12px;color:var(--c-wood-dk);margin-bottom:6px;">Train Units</h4>
    <table class="data" style="font-size:12px;">
        <thead>
            <tr>
                <th>Unit</th>
                <th>Stats</th>
                <th>Cost (each)</th>
                <th>Time (each)</th>
                <th>Have</th>
                <th>Train</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($trainable as $unit_key):
            $u = get_unit_stats($unit_key);
            if (!$u) continue;
            $cost = $u['cost'];
            $base_time = $UNIT_TRAIN_TIME[$unit_key] ?? 240;
            $time = training_time_seconds($base_time, $bld_level);
            $have_count = $owned_counts[$unit_key] ?? 0;
            $can_afford_one = ($resources['wood'] >= $cost['wood'] && $resources['clay'] >= $cost['clay']
                            && $resources['iron'] >= $cost['iron'] && $resources['crop'] >= $cost['crop']);

            // Research gate (colonists skip this — they don't need research)
            $needs_research = ($unit_key !== 'colonist') && unit_requires_research($tribe, $unit_key);
            $is_researched  = !$needs_research || !empty($researched[$unit_key]);
            $is_locked      = $needs_research && !$is_researched;
        ?>
        <tr <?= $is_locked ? 'style="opacity:0.55;"' : '' ?>>
            <td style="display:flex;align-items:center;gap:6px;">
                <img src="<?= img_url("troops/{$tribe}_{$unit_key}.png") ?>"
                     width="32" height="32" alt=""
                     style="image-rendering:pixelated;"
                     onerror="this.style.display='none';">
                <div>
                    <strong><?= e($u['name']) ?></strong>
                    <?php if ($is_locked): ?>
                        <br><small style="color:#8e2a26;font-weight:bold;">🔬 Research required at Academy</small>
                    <?php elseif ($needs_research): ?>
                        <br><small style="color:#4a7a3a;">✓ Researched</small>
                    <?php endif; ?>
                </div>
            </td>
            <td style="font-size:11px;">
                ATK <?= (int)$u['attack'] ?><br>
                DEF <?= (int)$u['def_inf'] ?>/<?= (int)$u['def_cav'] ?><br>
                SPD <?= (int)$u['speed'] ?>
            </td>
            <td style="font-size:11px;">
                <span class="res-icon res-wood"></span><?= format_number($cost['wood']) ?><br>
                <span class="res-icon res-clay"></span><?= format_number($cost['clay']) ?><br>
                <span class="res-icon res-iron"></span><?= format_number($cost['iron']) ?><br>
                <span class="res-icon res-crop"></span><?= format_number($cost['crop']) ?>
            </td>
            <td style="font-size:11px;"><?= e(format_seconds($time)) ?></td>
            <td><strong><?= $have_count ?></strong></td>
            <td>
                <?php if ($is_locked): ?>
                    <a href="<?= url('/village.php') ?>" class="btn btn-sm" style="background:#8e2a26;color:#fff;"
                       title="Build/visit an Academy to research this unit">🔬 Locked</a>
                <?php else: ?>
                    <form method="POST" style="display:flex;gap:4px;align-items:center;">
                        <input type="hidden" name="action" value="train">
                        <input type="hidden" name="unit_type" value="<?= e($unit_key) ?>">
                        <input type="number" name="count" value="1" min="1" max="100"
                               style="width:50px;padding:2px;" class="form-control">
                        <button type="submit" class="btn btn-green btn-sm"
                                <?= !$can_afford_one ? 'disabled' : '' ?>>
                            <?= $can_afford_one ? 'Train' : 'Too Expensive' ?>
                        </button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div style="margin-top:12px;padding:8px;background:#fff8d6;border-left:4px solid #f0c34b;font-size:11px;">
        <strong>ℹ️ Training here:</strong>
        <?php if ($building['building_type'] === 'barracks'): ?>
            Only infantry units are trained at the Barracks. Train cavalry at the Stable, siege at the Workshop, colonists at the Residence.
        <?php elseif ($building['building_type'] === 'stable'): ?>
            Only cavalry units are trained at the Stable. Train infantry at the Barracks.
        <?php elseif ($building['building_type'] === 'workshop'): ?>
            Only siege engines are built at the Workshop. They're slow but essential for breaking through City Walls.
        <?php elseif ($building['building_type'] === 'residence'): ?>
            Colonists are settlers who can found a new village. (Coming soon: send 3 colonists to an empty cell to found a new village.)
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/app/views/footer.php'; ?>
