<?php
/**
 * reports.php — Player reports inbox.
 *
 * Shows ONLY three categories of reports (per spec):
 *   1. ⚔️ Attack   — outgoing attacks you launched (attack sent, victory, raid failed)
 *   2. 🛡️ Defense  — incoming attacks on your villages (incoming attack, village attacked, village defended)
 *   3. 📦 Resources — resource shipments (sent, incoming, arrived)
 *
 * Other report types (research, NPC trade, trade offer accept/cancel,
 * reinforcement) are no longer created in the codebase, so they won't
 * appear here. Admin audit logs (category='admin') are excluded from this
 * view — admins can see them on the admin panel.
 */
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$player = current_player();

// ---- Actions: mark all read, delete ----
if (isset($_GET['mark_read'])) {
    db()->query("UPDATE reports SET is_read = 1 WHERE player_id = ?", [$player['id']]);
    redirect('/reports.php');
}
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    db()->query("DELETE FROM reports WHERE id = ? AND player_id = ?", [$del_id, $player['id']]);
    redirect('/reports.php' . (isset($_GET['tab']) ? '?tab=' . e($_GET['tab']) : ''));
}
if (isset($_GET['delete_all'])) {
    // Delete ALL read reports for this player (keeps unread ones)
    db()->query("DELETE FROM reports WHERE player_id = ? AND is_read = 1 AND category != 'admin'", [$player['id']]);
    redirect('/reports.php');
}

// ---- Fetch ALL reports for this player (excluding admin audit logs) ----
// We fetch all and then categorise in PHP because the attack/defense split
// requires inspecting the title/body — not just the category column.
$all_reports = db()->fetchAll(
    "SELECT * FROM reports
     WHERE player_id = ? AND category != 'admin'
     ORDER BY created_at DESC, id DESC
     LIMIT 300",
    [$player['id']]
);

// Categorise each report
$bucketed = ['attack' => [], 'defense' => [], 'resources' => [], 'other' => []];
foreach ($all_reports as $r) {
    $bucket = categorize_report($r);
    $bucketed[$bucket][] = $r;
}

// ---- Active tab ----
$tab = $_GET['tab'] ?? 'attack';
$valid_tabs = ['attack', 'defense', 'resources'];
if (!in_array($tab, $valid_tabs, true)) $tab = 'attack';

// Reports to show in the list
$reports = $bucketed[$tab];

// ---- Unread counts per tab ----
$unread = ['attack' => 0, 'defense' => 0, 'resources' => 0, 'total' => 0];
foreach ($bucketed as $bucket => $items) {
    if ($bucket === 'other') continue;
    foreach ($items as $r) {
        if (!$r['is_read']) {
            $unread[$bucket]++;
            $unread['total']++;
        }
    }
}

// ---- Selected report detail ----
$sel_id = (int)($_GET['id'] ?? 0);
$selected = null;
if ($sel_id) {
    $selected = db()->fetch("SELECT * FROM reports WHERE id = ? AND player_id = ?", [$sel_id, $player['id']]);
    if ($selected) {
        db()->query("UPDATE reports SET is_read = 1 WHERE id = ?", [$sel_id]);
        // Refresh unread counts after marking read
        $selected_cat = categorize_report($selected);
        if (isset($unread[$selected_cat]) && $unread[$selected_cat] > 0) {
            $unread[$selected_cat]--;
        }
        if ($unread['total'] > 0) $unread['total']--;
        // Mark as read in the list array too
        foreach ($reports as &$r) {
            if ($r['id'] == $sel_id) $r['is_read'] = 1;
        }
        unset($r);
    }
}

// Tab metadata (icons, colors, labels)
$tab_meta = [
    'attack'    => ['icon' => '⚔️', 'color' => '#8e2a26', 'label' => 'Attack',
                    'desc' => 'Battle results from your outgoing attacks — victories and defeats when your raids resolve.'],
    'defense'   => ['icon' => '🛡️', 'color' => '#4a6fa5', 'label' => 'Defense',
                    'desc' => 'Battle results when your village is attacked — defeats (loot stolen) and successful defenses.'],
    'resources' => ['icon' => '📦', 'color' => '#b88e28', 'label' => 'Resources',
                    'desc' => 'Resources that have arrived at your villages via the Marketplace.'],
];

$page_title = 'Reports' . ($unread['total'] > 0 ? " ({$unread['total']})" : '');
require __DIR__ . '/app/views/header.php';
?>

<style>
.report-tabs {
    display: flex;
    gap: 0;
    margin-bottom: 0;
    border-bottom: 3px solid var(--c-outline);
}
.report-tab {
    padding: 10px 18px;
    background: var(--c-panel, #f4ead5);
    border: 2px solid var(--c-outline);
    border-bottom: none;
    border-radius: 8px 8px 0 0;
    margin-right: 2px;
    text-decoration: none;
    color: var(--c-text-soft);
    font-weight: bold;
    font-size: 13px;
    position: relative;
    cursor: pointer;
}
.report-tab:hover {
    background: #fff8d6;
    color: var(--c-wood-dk);
    text-decoration: none;
}
.report-tab.active {
    background: #fff;
    color: var(--c-wood-dk);
    border-bottom: 2px solid #fff;
    margin-bottom: -3px;
    z-index: 2;
}
.report-tab .badge {
    display: inline-block;
    background: var(--c-red);
    color: #fff;
    font-size: 10px;
    padding: 1px 6px;
    border-radius: 10px;
    margin-left: 6px;
    min-width: 18px;
    text-align: center;
}
.report-tab .icon { font-size: 16px; margin-right: 4px; }

.report-list { list-style: none; padding: 0; margin: 0; }
.report-list li {
    border-bottom: 1px solid #e4d4a8;
    padding: 10px 12px;
    cursor: pointer;
    transition: background 0.15s;
    display: flex;
    align-items: flex-start;
    gap: 10px;
}
.report-list li:hover { background: #fff8d6; }
.report-list li.unread { background: #fffbe8; font-weight: bold; }
.report-list li.selected { background: #d6e5ff; }
.report-list li .dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--c-red);
    margin-top: 6px;
    flex-shrink: 0;
}
.report-list li.read .dot { background: transparent; border: 1px solid var(--c-outline); }
.report-list li .meta { flex: 1; min-width: 0; }
.report-list li .title {
    font-size: 13px;
    color: var(--c-wood-dk);
    margin-bottom: 2px;
    word-wrap: break-word;
}
.report-list li .time {
    font-size: 11px;
    color: var(--c-text-soft);
}
.report-list li .delete-btn {
    font-size: 14px;
    color: var(--c-red-dk);
    text-decoration: none;
    padding: 2px 6px;
    border-radius: 3px;
}
.report-list li .delete-btn:hover { background: #fce4e4; }

.report-body {
    background: #fff;
    border: 1px solid var(--c-outline);
    border-radius: 4px;
    padding: 14px;
    font-family: 'Courier New', 'Consolas', monospace;
    font-size: 12px;
    line-height: 1.55;
    white-space: pre-wrap;
    color: var(--c-text);
    overflow-x: auto;
}
.report-detail-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
    padding-bottom: 10px;
    border-bottom: 2px solid var(--c-outline);
}
.report-detail-header .big-icon {
    font-size: 32px;
    line-height: 1;
}
.report-detail-header h3 {
    margin: 0;
    color: var(--c-wood-dk);
    font-size: 16px;
}
.report-detail-header .meta-line {
    font-size: 11px;
    color: var(--c-text-soft);
    margin-top: 2px;
}
.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: var(--c-text-soft);
}
.empty-state .big { font-size: 48px; margin-bottom: 12px; opacity: 0.4; }
</style>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
        <span>📜 Reports</span>
        <span style="display:flex;gap:6px;">
            <?php if ($unread['total'] > 0): ?>
            <a href="<?= url('/reports.php?mark_read=1') ?>" class="btn btn-sm">✓ Mark all read</a>
            <?php endif; ?>
            <a href="<?= url('/reports.php?delete_all=1') ?>" class="btn btn-sm btn-red"
               onclick="return confirm('Delete ALL read reports? Unread reports will be kept.');">🗑 Clear read</a>
        </span>
    </div>

    <?php if ($unread['total'] > 0): ?>
    <div class="alert alert-info" style="margin-bottom:12px;padding:8px 12px;">
        <strong><?= $unread['total'] ?></strong> unread report(s):
        <?php foreach ($valid_tabs as $t): ?>
            <?php if ($unread[$t] > 0): ?>
            <span style="margin-left:8px;"><?= $tab_meta[$t]['icon'] ?> <?= $unread[$t] ?> <?= $tab_meta[$t]['label'] ?></span>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         Tabs
         ============================================================ -->
    <div class="report-tabs">
        <?php foreach ($valid_tabs as $t): ?>
        <a href="<?= url('/reports.php') ?>?tab=<?= $t ?>" class="report-tab <?= $tab === $t ? 'active' : '' ?>">
            <span class="icon"><?= $tab_meta[$t]['icon'] ?></span>
            <?= $tab_meta[$t]['label'] ?>
            <span class="badge" style="background:<?= $tab_meta[$t]['color'] ?>;">
                <?= count($bucketed[$t]) ?>
            </span>
            <?php if ($unread[$t] > 0): ?>
            <span class="badge"><?= $unread[$t] ?> new</span>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Tab description -->
    <p style="font-size:12px;color:var(--c-text-soft);margin:10px 0;padding:0 4px;">
        <?= e($tab_meta[$tab]['desc']) ?>
    </p>

    <div class="grid grid-2">
        <!-- ============================================================
             Reports list
             ============================================================ -->
        <div style="background:#fff;border:2px solid var(--c-outline);border-radius:6px;overflow:hidden;">
            <?php if (empty($reports)): ?>
            <div class="empty-state">
                <div class="big"><?= $tab_meta[$tab]['icon'] ?></div>
                <strong>No <?= strtolower($tab_meta[$tab]['label']) ?> reports.</strong><br><br>
                <?php if ($tab === 'attack'): ?>
                You'll get a battle report here when your raid<br>
                resolves. Send troops from the<br>
                <a href="<?= url('/troops.php') ?>">Troops</a> or <a href="<?= url('/map.php') ?>">Map</a> page.
                <?php elseif ($tab === 'defense'): ?>
                You haven't been attacked yet. Build a<br>
                <a href="<?= url('/village.php') ?>">City Wall</a> and train defenders to prepare.
                <?php else: ?>
                You'll get a report here when a shipment<br>
                arrives. Send resources from the<br>
                <a href="<?= url('/marketplace.php') ?>">Marketplace</a> page.
                <?php endif; ?>
            </div>
            <?php else: ?>
            <ul class="report-list">
                <?php foreach ($reports as $r):
                    $is_unread = !$r['is_read'];
                    $is_selected = ($sel_id == $r['id']);
                ?>
                <li class="<?= $is_unread ? 'unread' : 'read' ?> <?= $is_selected ? 'selected' : '' ?>"
                    onclick="window.location='<?= url('/reports.php') ?>?tab=<?= $tab ?>&id=<?= (int)$r['id'] ?>';">
                    <span class="dot"></span>
                    <div class="meta">
                        <div class="title"><?= e($r['title']) ?></div>
                        <div class="time"><?= e($r['created_at']) ?> · <?= time_ago($r['created_at']) ?></div>
                    </div>
                    <a href="<?= url('/reports.php') ?>?tab=<?= $tab ?>&delete=<?= (int)$r['id'] ?>"
                       class="delete-btn" onclick="event.stopPropagation(); return confirm('Delete this report?');">✕</a>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>

        <!-- ============================================================
             Report detail panel
             ============================================================ -->
        <div style="background:#fff;border:2px solid var(--c-outline);border-radius:6px;padding:16px;min-height:300px;">
            <?php if ($selected):
                $cat = categorize_report($selected);
                $meta = $tab_meta[$cat] ?? ['icon' => '📄', 'color' => '#888', 'label' => 'Report'];
            ?>
            <div class="report-detail-header">
                <span class="big-icon"><?= $meta['icon'] ?></span>
                <div style="flex:1;">
                    <h3><?= e($selected['title']) ?></h3>
                    <div class="meta-line">
                        <span style="background:<?= $meta['color'] ?>;color:#fff;padding:1px 6px;border-radius:3px;font-size:10px;text-transform:uppercase;letter-spacing:1px;">
                            <?= $meta['label'] ?>
                        </span>
                        &nbsp;|&nbsp; <?= e($selected['created_at']) ?> &nbsp;|&nbsp; <?= time_ago($selected['created_at']) ?>
                    </div>
                </div>
            </div>

            <div class="report-body"><?= e($selected['body']) ?></div>

            <div style="margin-top:12px;display:flex;gap:6px;flex-wrap:wrap;">
                <a href="<?= url('/reports.php') ?>?tab=<?= $tab ?>&delete=<?= (int)$selected['id'] ?>"
                   class="btn btn-red btn-sm"
                   onclick="return confirm('Delete this report?')">🗑 Delete</a>
                <a href="<?= url('/reports.php') ?>?tab=<?= $tab ?>" class="btn btn-sm">← Back to list</a>
                <?php if ($cat === 'attack' || $cat === 'defense'): ?>
                <a href="<?= url('/troops.php') ?>" class="btn btn-sm btn-blue">⚔️ Troops</a>
                <?php elseif ($cat === 'resources'): ?>
                <a href="<?= url('/marketplace.php') ?>" class="btn btn-sm btn-gold">📦 Marketplace</a>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="big">👈</div>
                <strong>Select a report from the list to view its content.</strong><br><br>
                Reports are generated only when an action resolves:
                <ul style="text-align:left;display:inline-block;font-size:12px;color:var(--c-text-soft);line-height:1.8;padding-left:20px;margin-top:8px;">
                    <li>⚔️ Your raid lands — victory or defeat report</li>
                    <li>🛡️ Your village is attacked — outcome report</li>
                    <li>📦 A resource shipment arrives at your village</li>
                </ul>
                <br><br>
                <em style="font-size:11px;color:var(--c-text-soft);">
                    Outgoing/incoming movements (in-progress attacks, reinforcements, shipments) are
                    shown on the <a href="<?= url('/troops.php') ?>">Troops</a> and
                    <a href="<?= url('/marketplace.php') ?>">Marketplace</a> pages — they don't generate reports
                    until they complete.
                </em>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ============================================================
         Legend / explanation
         ============================================================ -->
    <div style="margin-top:16px;padding:10px;background:#fff8d6;border-left:4px solid var(--c-gold-dk);border-radius:4px;font-size:11px;color:var(--c-text-soft);">
        <strong>ℹ️ About reports:</strong>
        Reports are generated <strong>only when an action resolves</strong> — battle outcomes (victory/defeat)
        and resource arrivals. Outgoing/incoming movements in progress (attacks on the way, reinforcements,
        shipments being delivered) are shown on the
        <a href="<?= url('/troops.php') ?>">Troops</a> and
        <a href="<?= url('/marketplace.php') ?>">Marketplace</a> pages — they don't create reports
        until they complete. This keeps the database lean.
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
