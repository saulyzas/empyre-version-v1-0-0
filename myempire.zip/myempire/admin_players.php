<?php
/**
 * admin_players.php — Player management.
 *
 * Actions:
 *   - Search / filter players (by username, by tribe, by admin/banned/active status)
 *   - Promote / demote admin
 *   - Ban / unban (with reason)
 *   - Award / deduct gold
 *   - Delete player (with confirmation)
 *   - View player detail (linked to player.php)
 */
require_once __DIR__ . '/app/lib/helpers.php';
require_once __DIR__ . '/app/lib/admin_helpers.php';
init_session();
require_admin();

// ---- Handle POST actions ----
$action_msg = '';
$action_err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $pid    = (int)($_POST['player_id'] ?? 0);

    switch ($action) {
        case 'promote':
            $r = admin_set_admin($pid, true);
            break;
        case 'demote':
            $r = admin_set_admin($pid, false);
            break;
        case 'ban':
            $reason = $_POST['reason'] ?? '';
            $r = admin_ban($pid, $reason);
            break;
        case 'unban':
            $r = admin_unban($pid);
            break;
        case 'award_gold':
            $amt = (int)($_POST['amount'] ?? 0);
            $r = admin_award_gold($pid, $amt);
            break;
        case 'delete':
            // Require explicit confirmation checkbox
            $confirm = $_POST['confirm'] ?? '';
            if ($confirm !== 'DELETE') {
                $r = ['ok' => false, 'error' => 'Type DELETE in the confirmation box to confirm.'];
            } else {
                $r = admin_delete_player($pid);
                if ($r['ok']) {
                    // Can't show detail anymore — go back to list
                    header('Location: ' . url('/admin_players.php?msg=deleted'));
                    exit;
                }
            }
            break;
        default:
            $r = ['ok' => false, 'error' => 'Unknown action.'];
    }

    if (!empty($r['ok'])) {
        $action_msg = ucfirst(str_replace('_', ' ', $action)) . ' succeeded.';
    } else {
        $action_err = $r['error'] ?? 'Action failed.';
    }
}

if (isset($_GET['msg']) && $_GET['msg'] === 'deleted') {
    $action_msg = 'Player deleted successfully.';
}

// ---- Filters ----
$search  = trim($_GET['search'] ?? '');
$tribe   = $_GET['tribe'] ?? '';
$status  = $_GET['status'] ?? '';   // all | admin | banned | online | inactive

// Build query
$sql = "SELECT p.*,
        (SELECT COUNT(*) FROM villages v WHERE v.player_id = p.id) AS village_count,
        (SELECT COALESCE(SUM(t.count), 0) FROM troops t
         JOIN villages v2 ON v2.id = t.village_id WHERE v2.player_id = p.id) AS troop_count
        FROM players p";
$where = [];
$params = [];
if ($search !== '') {
    $where[] = "(p.username LIKE ? OR p.email LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}
if (in_array($tribe, ['roman', 'gaul', 'teuton'], true)) {
    $where[] = "p.tribe = ?";
    $params[] = $tribe;
}
if ($status === 'admin') {
    $where[] = "p.is_admin = 1";
} elseif ($status === 'banned') {
    $where[] = "p.is_banned = 1";
} elseif ($status === 'online') {
    $cutoff = date('Y-m-d H:i:s', time() - ONLINE_THRESHOLD_SECONDS);
    $where[] = "p.last_activity >= ?";
    $params[] = $cutoff;
} elseif ($status === 'inactive') {
    $cutoff = date('Y-m-d H:i:s', time() - 7 * 86400);
    $where[] = "(p.last_activity IS NULL OR p.last_activity < ?)";
    $params[] = $cutoff;
}
if (!empty($where)) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY p.is_admin DESC, p.created_at DESC LIMIT 200";

$players = db()->fetchAll($sql, $params);

// If a specific player_id is in the URL (?id=N), show the detail panel for them
$detail_pid = (int)($_GET['id'] ?? 0);
$detail_player = null;
if ($detail_pid > 0) {
    $detail_player = db()->fetch(
        "SELECT p.*,
                (SELECT COUNT(*) FROM villages v WHERE v.player_id = p.id) AS village_count,
                (SELECT COALESCE(SUM(t.count), 0) FROM troops t
                 JOIN villages v2 ON v2.id = t.village_id WHERE v2.player_id = p.id) AS troop_count
         FROM players p WHERE p.id = ?",
        [$detail_pid]
    );
    if ($detail_player) {
        $detail_villages = db()->fetchAll(
            "SELECT * FROM villages WHERE player_id = ? ORDER BY is_capital DESC, id ASC",
            [$detail_pid]
        );
    }
}

$page_title = 'Admin — Players';
require __DIR__ . '/app/views/header.php';
?>

<div class="card">
    <div class="card-header" style="background:linear-gradient(135deg,#8e2a26,#5a1a18);color:#fff;">
        👥 Admin — Player Management
    </div>

    <p style="font-size:12px;">
        <a href="<?= url('/admin.php') ?>">← Back to Admin Panel</a>
    </p>

    <?php if ($action_msg): ?>
    <div class="alert alert-success"><?= e($action_msg) ?></div>
    <?php endif; ?>
    <?php if ($action_err): ?>
    <div class="alert alert-error"><?= e($action_err) ?></div>
    <?php endif; ?>

    <!-- ============================================================
         Filters
         ============================================================ -->
    <form method="GET" style="background:#fff;border:1px solid var(--c-outline);padding:10px;border-radius:6px;margin-bottom:16px;">
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end;">
            <div>
                <label style="font-size:11px;color:var(--c-text-soft);">Search</label><br>
                <input type="text" name="search" class="form-control" value="<?= e($search) ?>" placeholder="username or email" style="width:200px;">
            </div>
            <div>
                <label style="font-size:11px;color:var(--c-text-soft);">Tribe</label><br>
                <select name="tribe" class="form-control">
                    <option value="">All</option>
                    <option value="roman"  <?= $tribe === 'roman'  ? 'selected' : '' ?>>Roman</option>
                    <option value="gaul"   <?= $tribe === 'gaul'   ? 'selected' : '' ?>>Gaul</option>
                    <option value="teuton" <?= $tribe === 'teuton' ? 'selected' : '' ?>>Teuton</option>
                </select>
            </div>
            <div>
                <label style="font-size:11px;color:var(--c-text-soft);">Status</label><br>
                <select name="status" class="form-control">
                    <option value=""           <?= $status === ''           ? 'selected' : '' ?>>All</option>
                    <option value="admin"      <?= $status === 'admin'      ? 'selected' : '' ?>>Admins</option>
                    <option value="banned"     <?= $status === 'banned'     ? 'selected' : '' ?>>Banned</option>
                    <option value="online"     <?= $status === 'online'     ? 'selected' : '' ?>>Online now</option>
                    <option value="inactive"   <?= $status === 'inactive'   ? 'selected' : '' ?>>Inactive (7d+)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-blue btn-sm">🔍 Filter</button>
            <a href="<?= url('/admin_players.php') ?>" class="btn btn-sm">Clear</a>
        </div>
    </form>

    <!-- ============================================================
         Player detail panel (if ?id=N)
         ============================================================ -->
    <?php if ($detail_player): ?>
    <div style="background:#fff8d6;border:2px solid var(--c-gold-dk);border-radius:8px;padding:14px;margin-bottom:16px;">
        <h3 style="color:var(--c-wood-dk);margin-bottom:8px;">
            <img src="<?= img_url("tribes/{$detail_player['tribe']}.png") ?>" width="24" height="24" alt="" style="vertical-align:middle;image-rendering:pixelated;">
            <?= e($detail_player['username']) ?>
            <?php if ((int)$detail_player['is_admin'] === 1): ?>
                <span style="background:var(--c-gold-dk);color:#fff;padding:2px 6px;border-radius:3px;font-size:10px;">ADMIN</span>
            <?php endif; ?>
            <?php if ((int)$detail_player['is_banned'] === 1): ?>
                <span style="background:#8e2a26;color:#fff;padding:2px 6px;border-radius:3px;font-size:10px;">BANNED</span>
            <?php endif; ?>
            <span style="font-size:12px;color:var(--c-text-soft);">(ID <?= (int)$detail_player['id'] ?>)</span>
        </h3>

        <table class="data" style="font-size:12px;margin-bottom:12px;">
            <tr><th>Email</th><td><?= e($detail_player['email']) ?></td></tr>
            <tr><th>Tribe</th><td><?= ucfirst($detail_player['tribe']) ?></td></tr>
            <tr><th>Quadrant</th><td><?= e($detail_player['quadrant']) ?></td></tr>
            <tr><th>Population</th><td><?= (int)$detail_player['population'] ?></td></tr>
            <tr><th>Gold</th><td>₲ <?= (int)$detail_player['gold'] ?></td></tr>
            <tr><th>Villages</th><td><?= (int)$detail_player['village_count'] ?></td></tr>
            <tr><th>Total Troops</th><td><?= (int)$detail_player['troop_count'] ?></td></tr>
            <tr><th>Created</th><td><?= e($detail_player['created_at']) ?></td></tr>
            <tr><th>Last Login</th><td><?= e($detail_player['last_login'] ?? 'never') ?></td></tr>
            <tr><th>Last Activity</th><td><?= e($detail_player['last_activity'] ?? 'never') ?> (<?= time_ago($detail_player['last_activity']) ?>)</td></tr>
            <?php if ((int)$detail_player['is_banned'] === 1 && !empty($detail_player['banned_reason'])): ?>
            <tr><th>Ban Reason</th><td><?= e($detail_player['banned_reason']) ?></td></tr>
            <?php endif; ?>
        </table>

        <!-- Action forms -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">

            <!-- Promote / Demote -->
            <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:8px;border-radius:4px;">
                <input type="hidden" name="action" value="<?= (int)$detail_player['is_admin'] === 1 ? 'demote' : 'promote' ?>">
                <input type="hidden" name="player_id" value="<?= (int)$detail_player['id'] ?>">
                <div style="font-size:11px;color:var(--c-text-soft);margin-bottom:4px;">Admin Status</div>
                <button type="submit" class="btn btn-sm <?= (int)$detail_player['is_admin'] === 1 ? 'btn-red' : 'btn-gold' ?>" style="width:100%;">
                    <?= (int)$detail_player['is_admin'] === 1 ? '⬇️ Demote' : '⬆️ Promote to Admin' ?>
                </button>
            </form>

            <!-- Ban / Unban -->
            <?php if ((int)$detail_player['is_banned'] === 1): ?>
            <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:8px;border-radius:4px;">
                <input type="hidden" name="action" value="unban">
                <input type="hidden" name="player_id" value="<?= (int)$detail_player['id'] ?>">
                <div style="font-size:11px;color:var(--c-text-soft);margin-bottom:4px;">Ban Status</div>
                <button type="submit" class="btn btn-sm btn-green" style="width:100%;">✅ Unban</button>
            </form>
            <?php else: ?>
            <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:8px;border-radius:4px;">
                <input type="hidden" name="action" value="ban">
                <input type="hidden" name="player_id" value="<?= (int)$detail_player['id'] ?>">
                <div style="font-size:11px;color:var(--c-text-soft);margin-bottom:4px;">Ban (reason):</div>
                <input type="text" name="reason" class="form-control" placeholder="e.g. cheating" style="font-size:11px;margin-bottom:4px;" required>
                <button type="submit" class="btn btn-sm btn-red" style="width:100%;">🚫 Ban</button>
            </form>
            <?php endif; ?>

            <!-- Award gold -->
            <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:8px;border-radius:4px;">
                <input type="hidden" name="action" value="award_gold">
                <input type="hidden" name="player_id" value="<?= (int)$detail_player['id'] ?>">
                <div style="font-size:11px;color:var(--c-text-soft);margin-bottom:4px;">Gold (negative to take):</div>
                <input type="number" name="amount" class="form-control" value="100" style="font-size:11px;margin-bottom:4px;">
                <button type="submit" class="btn btn-sm btn-gold" style="width:100%;">₲ Award Gold</button>
            </form>

            <!-- Delete (with confirmation) -->
            <form method="POST" style="background:#fce4e4;border:1px solid #8e2a26;padding:8px;border-radius:4px;"
                  onsubmit="return confirm('⚠️ Delete this player permanently? This cannot be undone. All villages, troops, and data will be removed.');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="player_id" value="<?= (int)$detail_player['id'] ?>">
                <div style="font-size:11px;color:#8e2a26;margin-bottom:4px;">Type DELETE to confirm:</div>
                <input type="text" name="confirm" class="form-control" placeholder="DELETE" style="font-size:11px;margin-bottom:4px;" required>
                <button type="submit" class="btn btn-sm btn-red" style="width:100%;">🗑️ Delete Player</button>
            </form>
        </div>

        <!-- Player's villages -->
        <?php if (!empty($detail_villages)): ?>
        <h4 style="margin-top:14px;font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">Villages</h4>
        <table class="data" style="font-size:11px;">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Coords</th>
                    <th>Capital</th>
                    <th>Loyalty</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($detail_villages as $v): ?>
            <tr>
                <td><?= e($v['name']) ?></td>
                <td><?= (int)$v['x'] ?>|<?= (int)$v['y'] ?></td>
                <td><?= $v['is_capital'] ? '★' : '' ?></td>
                <td><?= (int)$v['loyalty'] ?>%</td>
                <td>
                    <a href="<?= url('/admin_villages.php?id=' . (int)$v['id']) ?>" class="btn btn-sm">Manage</a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

        <p style="margin-top:14px;">
            <a href="<?= url('/player.php?id=' . (int)$detail_player['id']) ?>" class="btn btn-sm btn-blue">👁 View Public Profile</a>
            <a href="<?= url('/admin_players.php') ?>" class="btn btn-sm">← Back to list</a>
        </p>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         Players list
         ============================================================ -->
    <h3 style="font-size:13px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">
        Players (<?= count($players) ?> shown)
    </h3>
    <table class="data" style="font-size:12px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>Player</th>
                <th>Tribe</th>
                <th>Pop</th>
                <th>Vil</th>
                <th>Troops</th>
                <th>Gold</th>
                <th>Status</th>
                <th>Last Seen</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($players as $p):
            $is_online = !empty($p['last_activity']) && $p['last_activity'] >= date('Y-m-d H:i:s', time() - ONLINE_THRESHOLD_SECONDS);
        ?>
        <tr style="<?= (int)$p['is_banned'] === 1 ? 'opacity:0.6;background:#fce4e4;' : '' ?><?= (int)$p['is_admin'] === 1 ? 'background:#fff8d6;' : '' ?>">
            <td><?= (int)$p['id'] ?></td>
            <td>
                <img src="<?= img_url("tribes/{$p['tribe']}.png") ?>" width="16" height="16" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                <strong><?= e($p['username']) ?></strong>
                <?php if ((int)$p['is_admin'] === 1): ?><span title="Admin" style="color:var(--c-gold-dk);">★</span><?php endif; ?>
            </td>
            <td><?= ucfirst($p['tribe']) ?></td>
            <td><?= (int)$p['population'] ?></td>
            <td><?= (int)$p['village_count'] ?></td>
            <td><?= (int)$p['troop_count'] ?></td>
            <td>₲ <?= (int)$p['gold'] ?></td>
            <td style="font-size:11px;">
                <?php if ((int)$p['is_banned'] === 1): ?>
                    <span style="color:#8e2a26;font-weight:bold;">BANNED</span>
                <?php elseif ($is_online): ?>
                    <span style="color:#4a7a3a;font-weight:bold;">● Online</span>
                <?php else: ?>
                    <span style="color:var(--c-text-soft);">○ <?= time_ago($p['last_activity']) ?></span>
                <?php endif; ?>
            </td>
            <td style="font-size:11px;color:var(--c-text-soft);"><?= time_ago($p['last_activity']) ?></td>
            <td>
                <a href="<?= url('/admin_players.php?id=' . (int)$p['id']) ?>" class="btn btn-sm btn-blue">Manage</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($players)): ?>
        <tr><td colspan="10" style="text-align:center;color:var(--c-text-soft);padding:16px;">No players match your filters.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
