<?php
/**
 * cell.php — Single-cell info page for the world map.
 *
 * Click any tile on map.php and you arrive here. The page shows:
 *   - Coordinates (X|Y) and terrain type with description (for empty cells)
 *   - For occupied cells: village name, owner info, hero, troops count
 *   - Distance from the player's own village + estimated travel time
 *   - Action buttons: Attack, Reinforce, Send Resources, View Profile, Center Map
 *
 * This replaces the old behavior where clicking an empty cell just
 * recentered the map, and clicking a village cell jumped directly to
 * player.php (losing all cell context).
 */
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);
$player   = current_player();

// Target cell coordinates
$tx = (int)($_GET['x'] ?? $village['x']);
$ty = (int)($_GET['y'] ?? $village['y']);

// Map view to return to (so "Back to Map" doesn't reset the view)
$from_x = (int)($_GET['from_x'] ?? $village['x']);
$from_y = (int)($_GET['from_y'] ?? $village['y']);

// ---- Terrain info ----
$terrain       = terrain_for_cell($tx, $ty);
$terrain_info  = terrain_description($tx, $ty);
$terrain_img   = "map/{$terrain}.png";

// ---- Is there a village at this cell? ----
$target_village = db()->fetch(
    "SELECT v.*, p.username, p.tribe AS player_tribe, p.population AS player_population,
            p.id AS player_id, p.created_at AS player_joined, p.last_login
     FROM villages v
     JOIN players p ON p.id = v.player_id
     WHERE v.x = ? AND v.y = ?",
    [$tx, $ty]
);

// ---- Distance + travel time from player's own village ----
$dist = distance_between($village['x'], $village['y'], $tx, $ty);
// Merchants travel at 12 fields/hour. Troops travel at slowest unit speed.
// We'll show a few common speeds as a guide.
$merchant_speed = 12;
$merchant_travel_sec = movement_time_seconds($dist, $merchant_speed);
// For troop travel, show the slowest typical infantry (6 fields/hour) as a rough guide
$legionnaire_speed = 6;
$infantry_travel_sec = movement_time_seconds($dist, $legionnaire_speed);
$cavalry_speed = 16;
$cavalry_travel_sec = movement_time_seconds($dist, $cavalry_speed);

// ---- Player's own troops (for attack/reinforce availability) ----
$my_troops = get_village_troops($village['id']);
$has_troops = !empty($my_troops);

// ---- Player's own buildings (for marketplace availability) ----
$my_buildings = get_buildings($village['id']);
$my_marketplace_level = 0;
$my_rally_point_level = 0;
foreach ($my_buildings as $b) {
    if ($b['building_type'] === 'marketplace') $my_marketplace_level = max($my_marketplace_level, (int)$b['level']);
    if ($b['building_type'] === 'rally_point') $my_rally_point_level = max($my_rally_point_level, (int)$b['level']);
}

// ---- If target village exists: gather extended info ----
if ($target_village) {
    $target_player_id = (int)$target_village['player_id'];

    // Target player's village count + total troops count (visible — Travian typically shows it via stats)
    $target_village_count = (int)db()->fetchColumn(
        "SELECT COUNT(*) FROM villages WHERE player_id = ?",
        [$target_player_id]
    );

    $target_total_troops = (int)db()->fetchColumn(
        "SELECT COALESCE(SUM(t.count), 0) FROM troops t
         JOIN villages v ON v.id = t.village_id
         WHERE v.player_id = ?",
        [$target_player_id]
    );

    // Target's hero (if any)
    $target_hero = db()->fetch("SELECT * FROM heroes WHERE player_id = ?", [$target_player_id]);

    // Target's tribe loot multiplier
    $target_loot_mult = $GLOBALS['TRIBE_LOOT_MULTIPLIER'][$target_village['player_tribe']] ?? 0.7;

    // Is this the player's own village?
    $is_own = ($target_player_id === (int)$player['id']);

    // Are we currently attacking this village?
    $incoming_attacks_count = (int)db()->fetchColumn(
        "SELECT COUNT(*) FROM movements
         WHERE to_village_id = ? AND type = 'attack' AND status = 'in_progress'",
        [$target_village['id']]
    );

    // Are there incoming reinforcements to this village?
    $incoming_reinforcements_count = (int)db()->fetchColumn(
        "SELECT COUNT(*) FROM movements
         WHERE to_village_id = ? AND type = 'reinforcement' AND status = 'in_progress'",
        [$target_village['id']]
    );
}

// ---- Active incoming attacks on the cell (for warning display) ----
$incoming_attacks_here = 0;
if (!empty($target_village)) {
    $incoming_attacks_here = (int)db()->fetchColumn(
        "SELECT COUNT(*) FROM movements
         WHERE to_village_id = ? AND type = 'attack' AND status = 'in_progress'",
        [$target_village['id']]
    );
}

// ---- "Back to Map" link preserves the previous view ----
$back_to_map_url = url('/map.php') . '?x=' . $from_x . '&y=' . $from_y;
$center_map_url  = url('/map.php') . '?x=' . $tx . '&y=' . $ty;

$page_title = "Cell $tx|$ty";
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:760px;margin:0 auto;">
    <div class="card-header">
        📍 Cell (<?= $tx ?>|<?= $ty ?>)
    </div>

    <!-- ============== Cell identity panel ============== -->
    <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;flex-wrap:wrap;">
        <img src="<?= img_url($terrain_img) ?>"
             alt="<?= e($terrain_info['name']) ?>"
             width="96" height="96"
             style="image-rendering:pixelated;border:3px solid var(--c-outline);border-radius:8px;background:var(--c-panel);">
        <div style="flex:1;min-width:200px;">
            <h3 style="color:var(--c-wood-dk);margin-bottom:4px;">
                <?= e($terrain_info['name']) ?>
                <?php if (!empty($target_village) && !empty($is_own)): ?>
                    <span style="font-size:13px;color:var(--c-text-soft);">(your village)</span>
                <?php elseif (!empty($target_village)): ?>
                    <span style="font-size:13px;color:var(--c-red-dk);">(occupied)</span>
                <?php else: ?>
                    <span style="font-size:13px;color:var(--c-text-soft);">(abandoned)</span>
                <?php endif; ?>
            </h3>
            <p style="font-size:13px;color:var(--c-text-soft);">
                <?= e($terrain_info['short']) ?>
            </p>
            <p style="font-size:11px;color:var(--c-text-soft);margin-top:4px;">
                <strong>Bonus:</strong> <?= e($terrain_info['production_bonus']) ?>
            </p>
        </div>
    </div>

    <!-- ============== Quick nav actions ============== -->
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px;">
        <a href="<?= $back_to_map_url ?>" class="btn btn-sm">← Back to Map</a>
        <a href="<?= $center_map_url ?>" class="btn btn-sm btn-gold">🎯 Center Map Here</a>
        <?php if (!empty($target_village) && empty($is_own)): ?>
        <a href="<?= url('/player.php') . '?id=' . (int)$target_village['player_id'] ?>" class="btn btn-sm btn-blue">👁 View Player Profile</a>
        <?php endif; ?>
    </div>

    <!-- ============== If there's a village here ============== -->
    <?php if (!empty($target_village)): ?>

        <?php if ($incoming_attacks_here > 0 && empty($is_own)): ?>
        <div class="alert alert-error" style="margin-bottom:12px;">
            ⚠️ <strong><?= $incoming_attacks_here ?></strong> incoming attack(s) detected on this village!
        </div>
        <?php endif; ?>

        <table class="data" style="margin-bottom:16px;">
            <tr>
                <th style="width:30%;">Village Name</th>
                <td>
                    <img src="<?= img_url('map/village.png') ?>" width="20" height="20" alt="" style="vertical-align:middle;">
                    <strong><?= e($target_village['name']) ?></strong>
                    <?php if ($target_village['is_capital']): ?>
                        <span style="background:var(--c-gold-dk);color:#fff;padding:1px 6px;border-radius:4px;font-size:10px;margin-left:6px;">CAPITAL</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Coordinates</th>
                <td><?= (int)$target_village['x'] ?> | <?= (int)$target_village['y'] ?></td>
            </tr>
            <tr>
                <th>Owner</th>
                <td>
                    <img src="<?= img_url("tribes/{$target_village['player_tribe']}.png") ?>" width="18" height="18" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e($target_village['username']) ?>
                    <span style="color:var(--c-text-soft);font-size:11px;">(<?= e(ucfirst($target_village['player_tribe'])) ?> tribe)</span>
                    <?php if (empty($is_own)): ?>
                        — <a href="<?= url('/player.php') . '?id=' . (int)$target_village['player_id'] ?>" style="font-size:11px;">view profile</a>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Loyalty</th>
                <td>
                    <div style="display:flex;align-items:center;gap:6px;">
                        <div style="flex:1;max-width:160px;height:10px;background:#4a3a20;border:1px solid var(--c-outline);border-radius:3px;overflow:hidden;">
                            <div style="width:<?= max(0, min(100, (int)$target_village['loyalty'])) ?>%;height:100%;background:linear-gradient(90deg,#4a7a3a,#7ab84a);"></div>
                        </div>
                        <span><?= (int)$target_village['loyalty'] ?>%</span>
                    </div>
                </td>
            </tr>
            <tr>
                <th>Player Population</th>
                <td><?= (int)$target_village['player_population'] ?></td>
            </tr>
            <tr>
                <th>Villages Owned</th>
                <td><?= $target_village_count ?></td>
            </tr>
            <tr>
                <th>Total Troops</th>
                <td>
                    <?= $target_total_troops ?> unit(s)
                    <?php if (!empty($is_own)): ?>
                        <span style="color:var(--c-text-soft);font-size:11px;">(across all your villages)</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php if (!empty($target_hero)): ?>
            <tr>
                <th>Hero</th>
                <td>
                    <img src="<?= img_url("misc/hero_icon.png") ?>" width="18" height="18" alt="" style="vertical-align:middle;">
                    <?= e($target_hero['name']) ?> — Level <?= (int)$target_hero['level'] ?>
                    (ATK <?= (int)$target_hero['attack'] ?> / DEF <?= (int)$target_hero['defense'] ?> / HP <?= (int)$target_hero['health'] ?>)
                </td>
            </tr>
            <?php endif; ?>
            <tr>
                <th>Player Joined</th>
                <td><?= e($target_village['player_joined']) ?></td>
            </tr>
            <?php if (!empty($target_village['last_login'])): ?>
            <tr>
                <th>Last Login</th>
                <td><?= e($target_village['last_login']) ?></td>
            </tr>
            <?php endif; ?>
        </table>

        <?php if (!empty($is_own)): ?>
            <!-- ============== Own village actions ============== -->
            <div style="padding:12px;background:#fff8d6;border:2px solid var(--c-gold-dk);border-radius:8px;text-align:center;margin-bottom:12px;">
                <h3 style="color:var(--c-wood-dk);margin-bottom:8px;">🏘️ Your Village</h3>
                <p style="font-size:13px;color:var(--c-text-soft);margin-bottom:12px;">
                    This is your own village. Manage buildings, train troops, and gather resources here.
                </p>
                <a href="<?= url('/village.php') ?>" class="btn btn-gold btn-lg">Manage Village</a>
            </div>
        <?php else: ?>
            <!-- ============== Other player's village — action panel ============== -->
            <div style="padding:12px;background:#f4ead5;border:2px solid var(--c-outline);border-radius:8px;">
                <h3 style="color:var(--c-wood-dk);margin-bottom:8px;">⚔️ Diplomatic & Military Actions</h3>

                <!-- Attack -->
                <div style="margin-bottom:10px;padding:8px;background:#fff;border-left:4px solid var(--c-red-dk);border-radius:4px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                        <div>
                            <strong style="color:var(--c-red-dk);">⚔ Attack / Raid</strong><br>
                            <small style="color:var(--c-text-soft);">
                                Send troops to raid this village and steal resources.
                                <?php if (!$has_troops): ?>
                                    <br><span style="color:#8e2a26;">You have no troops — train some at the Barracks first.</span>
                                <?php endif; ?>
                            </small>
                        </div>
                        <?php if ($has_troops): ?>
                        <a href="<?= url('/attack.php') . '?x=' . $tx . '&y=' . $ty ?>" class="btn btn-red btn-sm">⚔ Attack</a>
                        <?php else: ?>
                        <a href="<?= url('/troops.php') ?>" class="btn btn-sm" style="background:#888;">Train Troops First</a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Reinforce -->
                <div style="margin-bottom:10px;padding:8px;background:#fff;border-left:4px solid #4a7a3a;border-radius:4px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                        <div>
                            <strong style="color:#4a7a3a;">🛡 Reinforce</strong><br>
                            <small style="color:var(--c-text-soft);">
                                Send troops to defend this village. They will fight on the defender's side.
                                <?php if (!$has_troops): ?>
                                    <br><span style="color:#8e2a26;">You have no troops to send.</span>
                                <?php endif; ?>
                            </small>
                        </div>
                        <?php if ($has_troops): ?>
                        <form method="POST" action="<?= url('/send_troops.php') ?>" style="display:inline;">
                            <input type="hidden" name="to_x" value="<?= $tx ?>">
                            <input type="hidden" name="to_y" value="<?= $ty ?>">
                            <input type="hidden" name="mission" value="reinforcement">
                            <button type="submit" class="btn btn-green btn-sm">🛡 Reinforce</button>
                        </form>
                        <?php else: ?>
                        <button class="btn btn-sm" style="background:#888;" disabled>No Troops</button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Send Resources -->
                <div style="padding:8px;background:#fff;border-left:4px solid #4a6fa5;border-radius:4px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                        <div>
                            <strong style="color:#4a6fa5;">📦 Send Resources</strong><br>
                            <small style="color:var(--c-text-soft);">
                                Send wood/clay/iron/crop to this village via merchants.
                                <?php if ($my_marketplace_level < 1): ?>
                                    <br><span style="color:#8e2a26;">Requires a Marketplace (you don't have one).</span>
                                <?php endif; ?>
                            </small>
                        </div>
                        <?php if ($my_marketplace_level >= 1): ?>
                        <a href="<?= url('/send_resources.php') . '?to_village=' . (int)$target_village['id'] ?>" class="btn btn-blue btn-sm">📦 Send</a>
                        <?php else: ?>
                        <button class="btn btn-sm" style="background:#888;" disabled>No Marketplace</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <!-- ============== Empty cell — abandoned valley ============== -->
        <div style="padding:14px;background:#f4ead5;border:2px dashed var(--c-outline);border-radius:8px;margin-bottom:16px;">
            <h3 style="color:var(--c-wood-dk);margin-bottom:6px;">🍂 Abandoned <?= e($terrain_info['name']) ?></h3>
            <p style="font-size:13px;color:var(--c-text);line-height:1.5;margin-bottom:8px;">
                <?= e($terrain_info['long']) ?>
            </p>
            <p style="font-size:11px;color:var(--c-text-soft);">
                <strong>Terrain bonus:</strong> <?= e($terrain_info['production_bonus']) ?>
            </p>
        </div>

        <table class="data" style="margin-bottom:16px;">
            <tr>
                <th style="width:30%;">Status</th>
                <td>
                    <span style="color:#8e2a26;font-weight:bold;">🗺️ Unoccupied</span>
                    — no village has been founded here.
                </td>
            </tr>
            <tr>
                <th>Terrain</th>
                <td>
                    <img src="<?= img_url($terrain_img) ?>" width="20" height="20" alt="" style="vertical-align:middle;">
                    <?= e($terrain_info['name']) ?>
                </td>
            </tr>
            <tr>
                <th>Coordinates</th>
                <td><?= $tx ?> | <?= $ty ?></td>
            </tr>
        </table>

        <div style="padding:10px;background:#fff8d6;border-left:4px solid #f0c34b;font-size:12px;margin-bottom:12px;">
            <strong>ℹ️ Note:</strong> Founding a new village on an abandoned cell is not yet implemented.
            For now, abandoned cells are mainly useful as a tactical reference — knowing the terrain
            helps you plan attacks, reinforcements, and merchant routes that pass through them.
        </div>
    <?php endif; ?>

    <!-- ============== Distance + travel time ============== -->
    <div class="card" style="margin-top:8px;">
        <div class="card-header">📍 Distance from <?= e($village['name']) ?></div>
        <table class="data">
            <tr>
                <th style="width:30%;">Your Village</th>
                <td>
                    <?= e($village['name']) ?>
                    <span style="color:var(--c-text-soft);font-size:11px;">(<?= (int)$village['x'] ?>|<?= (int)$village['y'] ?>)</span>
                </td>
            </tr>
            <tr>
                <th>Distance</th>
                <td>
                    <strong><?= number_format($dist, 2) ?></strong> fields
                    <?php if ($dist == 0): ?>
                        <span style="color:var(--c-gold-dk);font-size:11px;">(same cell)</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Merchant Travel</th>
                <td>
                    <?= e(format_seconds($merchant_travel_sec)) ?>
                    <span style="color:var(--c-text-soft);font-size:11px;">(12 fields/hour)</span>
                </td>
            </tr>
            <tr>
                <th>Infantry Travel</th>
                <td>
                    <?= e(format_seconds($infantry_travel_sec)) ?>
                    <span style="color:var(--c-text-soft);font-size:11px;">(6 fields/hour, e.g. Legionnaire)</span>
                </td>
            </tr>
            <tr>
                <th>Cavalry Travel</th>
                <td>
                    <?= e(format_seconds($cavalry_travel_sec)) ?>
                    <span style="color:var(--c-text-soft);font-size:11px;">(16 fields/hour, e.g. Equites Legati)</span>
                </td>
            </tr>
        </table>
    </div>

    <!-- ============== Nearby villages (within 5 fields) ============== -->
    <?php
    $nearby_radius = 5;
    $nearby_villages = db()->fetchAll(
        "SELECT v.id, v.name, v.x, v.y, v.is_capital, p.username, p.tribe
         FROM villages v
         JOIN players p ON p.id = v.player_id
         WHERE v.x BETWEEN ? AND ?
           AND v.y BETWEEN ? AND ?
           AND NOT (v.x = ? AND v.y = ?)
         ORDER BY ((v.x - ?) * (v.x - ?) + (v.y - ?) * (v.y - ?)) ASC
         LIMIT 8",
        [$tx - $nearby_radius, $tx + $nearby_radius,
         $ty - $nearby_radius, $ty + $nearby_radius,
         $tx, $ty,
         $tx, $tx, $ty, $ty]
    );
    ?>
    <?php if (!empty($nearby_villages)): ?>
    <div class="card" style="margin-top:16px;">
        <div class="card-header">🏘️ Nearby Villages (within <?= $nearby_radius ?> fields)</div>
        <table class="data" style="font-size:12px;">
            <thead>
                <tr>
                    <th>Village</th>
                    <th>Owner</th>
                    <th>Coordinates</th>
                    <th>Distance</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($nearby_villages as $nv):
                $nd = distance_between($tx, $ty, $nv['x'], $nv['y']);
            ?>
            <tr>
                <td>
                    <?= e($nv['name']) ?>
                    <?php if ($nv['is_capital']): ?>
                    <span style="background:var(--c-gold-dk);color:#fff;padding:0 4px;border-radius:3px;font-size:9px;">★</span>
                    <?php endif; ?>
                </td>
                <td>
                    <img src="<?= img_url("tribes/{$nv['tribe']}.png") ?>" width="16" height="16" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e($nv['username']) ?>
                </td>
                <td>
                    <a href="<?= url('/cell.php') . '?x=' . (int)$nv['x'] . '&y=' . (int)$nv['y'] . '&from_x=' . $from_x . '&from_y=' . $from_y ?>">
                        <?= (int)$nv['x'] ?>|<?= (int)$nv['y'] ?>
                    </a>
                </td>
                <td><?= number_format($nd, 1) ?> fields</td>
                <td>
                    <a href="<?= url('/cell.php') . '?x=' . (int)$nv['x'] . '&y=' . (int)$nv['y'] . '&from_x=' . $from_x . '&from_y=' . $from_y ?>" class="btn btn-sm">Inspect</a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <p style="text-align:center;margin-top:16px;">
        <a href="<?= $back_to_map_url ?>">← Back to Map</a>
        | <a href="<?= $center_map_url ?>">🎯 Center Map Here</a>
    </p>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
