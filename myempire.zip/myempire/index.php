<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();

// If already logged in, redirect to village
if (current_player_id()) {
    redirect('/village.php');
}

// Fetch server-wide statistics for the landing page panel
$stats = get_server_stats();

global $TRIBES;
$page_title = 'Home';
require __DIR__ . '/app/views/header.php';
?>
<style>
.landing-hero {
    background: linear-gradient(135deg, #8e5eaf 0%, #4a6da8 50%, #2d3e5e 100%);
    color: #fff;
    padding: 60px 20px;
    text-align: center;
    border-bottom: 4px solid #231612;
    margin: -16px -16px 24px;
}
.landing-hero h1 {
    font-family: Georgia, serif;
    font-size: 56px;
    letter-spacing: 6px;
    text-shadow: 3px 3px 0 #231612;
    margin-bottom: 12px;
}
.landing-hero p { font-size: 18px; opacity: 0.95; margin-bottom: 24px; }
.landing-cta {
    display: inline-block;
    padding: 12px 32px;
    background: #f0c34b;
    color: #231612;
    border: 3px solid #231612;
    border-radius: 6px;
    font-size: 18px;
    font-weight: bold;
    box-shadow: 0 4px 0 #231612;
    text-decoration: none;
    margin: 0 8px;
}
.landing-cta:hover { transform: translateY(-2px); text-decoration: none; }
.landing-cta:active { transform: translateY(2px); box-shadow: none; }
.landing-cta.alt { background: #6aa555; color: #fff; }

/* === Server statistics panel === */
.stats-panel {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 12px;
    margin-top: 12px;
}
.stat-box {
    background: linear-gradient(180deg, #fff8d6 0%, #f4ead5 100%);
    border: 2px solid var(--c-outline);
    border-radius: 8px;
    padding: 14px 10px;
    text-align: center;
    box-shadow: 0 2px 0 var(--c-outline);
    transition: transform 0.15s ease;
}
.stat-box:hover { transform: translateY(-2px); }
.stat-box .stat-num {
    font-family: Georgia, serif;
    font-size: 28px;
    font-weight: bold;
    color: var(--c-wood-dk);
    line-height: 1;
    text-shadow: 1px 1px 0 #fff;
}
.stat-box .stat-label {
    font-size: 11px;
    color: var(--c-text-soft);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-top: 4px;
}
.stat-box.online .stat-num { color: #4a7a3a; }
.stat-box.online::before {
    content: '';
    display: inline-block;
    width: 8px;
    height: 8px;
    background: #4a7a3a;
    border-radius: 50%;
    margin-right: 4px;
    box-shadow: 0 0 6px #4a7a3a;
    animation: pulse 1.6s infinite;
}
@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
}

.online-list {
    list-style: none;
    padding: 0;
    margin: 8px 0 0;
}
.online-list li {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 6px;
    border-bottom: 1px dashed var(--c-outline-soft, #d4c4a0);
    font-size: 12px;
}
.online-list li:last-child { border-bottom: none; }
.online-list .dot {
    width: 8px; height: 8px;
    background: #4a7a3a;
    border-radius: 50%;
    box-shadow: 0 0 4px #4a7a3a;
    flex-shrink: 0;
}

.tribe-bar {
    display: flex;
    height: 18px;
    border: 2px solid var(--c-outline);
    border-radius: 4px;
    overflow: hidden;
    margin-top: 6px;
    background: #ddd;
}
.tribe-bar > div {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    color: #fff;
    font-weight: bold;
    text-shadow: 1px 1px 0 rgba(0,0,0,0.4);
}
.tribe-bar .roman-seg  { background: #b8403a; }
.tribe-bar .gaul-seg   { background: #4a8a4a; }
.tribe-bar .teuton-seg { background: #6a6a8a; }
</style>

<div class="landing-hero">
    <h1><?= e(GAME_NAME) ?></h1>
    <p><?= e(GAME_TAGLINE) ?>. Forge alliances, build mighty armies, and conquer the ancient world.</p>
    <a href="<?= url('/register.php') ?>" class="landing-cta">PLAY FOR FREE</a>
    <a href="<?= url('/login.php') ?>" class="landing-cta alt">LOGIN</a>
    <a href="<?= url('/faq.php') ?>" class="landing-cta" style="background:#6aa555;color:#fff;">❓ FAQ</a>
</div>

<!-- ============================================================
     Server Statistics Panel
     ============================================================ -->
<div class="card">
    <div class="card-header">📊 Server Statistics</div>

    <!-- Main stat boxes -->
    <div class="stats-panel">
        <div class="stat-box">
            <div class="stat-num"><?= number_format($stats['total_players']) ?></div>
            <div class="stat-label">Registered</div>
        </div>
        <div class="stat-box online">
            <div class="stat-num"><?= number_format($stats['online_now']) ?></div>
            <div class="stat-label">Online Now</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= number_format($stats['active_today']) ?></div>
            <div class="stat-label">Active Today</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= number_format($stats['active_this_week']) ?></div>
            <div class="stat-label">Active This Week</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= number_format($stats['total_villages']) ?></div>
            <div class="stat-label">Villages</div>
        </div>
        <div class="stat-box">
            <div class="stat-num"><?= number_format($stats['total_troops']) ?></div>
            <div class="stat-label">Troops Raised</div>
        </div>
    </div>

    <!-- Tribe distribution bar + breakdown -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-top:18px;align-items:start;">
        <div>
            <h4 style="margin:0 0 4px;font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">Tribe Distribution</h4>
            <?php
            $total_for_bar = max(1, $stats['total_players']);
            $roman_pct  = round(100 * $stats['tribe_counts']['roman']  / $total_for_bar);
            $gaul_pct   = round(100 * $stats['tribe_counts']['gaul']   / $total_for_bar);
            $teuton_pct = max(0, 100 - $roman_pct - $gaul_pct);
            ?>
            <div class="tribe-bar">
                <?php if ($stats['tribe_counts']['roman'] > 0): ?>
                <div class="roman-seg" style="width:<?= $roman_pct ?>%;" title="Romans: <?= $stats['tribe_counts']['roman'] ?>"><?= $stats['tribe_counts']['roman'] ?></div>
                <?php endif; ?>
                <?php if ($stats['tribe_counts']['gaul'] > 0): ?>
                <div class="gaul-seg" style="width:<?= $gaul_pct ?>%;" title="Gauls: <?= $stats['tribe_counts']['gaul'] ?>"><?= $stats['tribe_counts']['gaul'] ?></div>
                <?php endif; ?>
                <?php if ($stats['tribe_counts']['teuton'] > 0): ?>
                <div class="teuton-seg" style="width:<?= $teuton_pct ?>%;" title="Teutons: <?= $stats['tribe_counts']['teuton'] ?>"><?= $stats['tribe_counts']['teuton'] ?></div>
                <?php endif; ?>
                <?php if ($stats['total_players'] === 0): ?>
                <div style="background:#ddd;width:100%;"></div>
                <?php endif; ?>
            </div>
            <div style="display:flex;gap:14px;font-size:11px;margin-top:6px;flex-wrap:wrap;">
                <span><img src="<?= img_url('tribes/roman.png') ?>" width="14" height="14" alt="" style="vertical-align:middle;"> Romans: <?= $stats['tribe_counts']['roman'] ?></span>
                <span><img src="<?= img_url('tribes/gaul.png') ?>" width="14" height="14" alt="" style="vertical-align:middle;"> Gauls: <?= $stats['tribe_counts']['gaul'] ?></span>
                <span><img src="<?= img_url('tribes/teuton.png') ?>" width="14" height="14" alt="" style="vertical-align:middle;"> Teutons: <?= $stats['tribe_counts']['teuton'] ?></span>
            </div>
        </div>

        <div>
            <h4 style="margin:0 0 4px;font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">Top Player</h4>
            <?php if (!empty($stats['top_player'])): ?>
            <div style="display:flex;align-items:center;gap:8px;padding:6px;background:#fff;border:1px solid var(--c-outline);border-radius:4px;">
                <img src="<?= img_url("tribes/{$stats['top_player']['tribe']}.png") ?>" width="28" height="28" alt="" style="image-rendering:pixelated;">
                <div>
                    <div style="font-weight:bold;color:var(--c-wood-dk);"><?= e($stats['top_player']['username']) ?></div>
                    <div style="font-size:11px;color:var(--c-text-soft);">Population <?= (int)$stats['top_player']['population'] ?> · <?= ucfirst($stats['top_player']['tribe']) ?></div>
                </div>
            </div>
            <?php else: ?>
            <div style="font-size:12px;color:var(--c-text-soft);padding:6px;">No players yet — be the first!</div>
            <?php endif; ?>

            <h4 style="margin:12px 0 4px;font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">Newest Player</h4>
            <?php if (!empty($stats['newest_player'])): ?>
            <div style="display:flex;align-items:center;gap:8px;padding:6px;background:#fff;border:1px solid var(--c-outline);border-radius:4px;">
                <img src="<?= img_url("tribes/{$stats['newest_player']['tribe']}.png") ?>" width="28" height="28" alt="" style="image-rendering:pixelated;">
                <div>
                    <div style="font-weight:bold;color:var(--c-wood-dk);"><?= e($stats['newest_player']['username']) ?></div>
                    <div style="font-size:11px;color:var(--c-text-soft);">Joined <?= time_ago($stats['newest_player']['created_at']) ?></div>
                </div>
            </div>
            <?php else: ?>
            <div style="font-size:12px;color:var(--c-text-soft);padding:6px;">No players yet.</div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Online players list -->
    <?php if (!empty($stats['online_players_list'])): ?>
    <div style="margin-top:18px;">
        <h4 style="margin:0 0 4px;font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">
            🟢 Players Online Now (<?= count($stats['online_players_list']) ?><?= $stats['online_now'] > 8 ? '+' : '' ?>)
        </h4>
        <ul class="online-list">
            <?php foreach ($stats['online_players_list'] as $op): ?>
            <li>
                <span class="dot"></span>
                <img src="<?= img_url("tribes/{$op['tribe']}.png") ?>" width="16" height="16" alt="" style="image-rendering:pixelated;">
                <strong><?= e($op['username']) ?></strong>
                <span style="color:var(--c-text-soft);font-size:11px;">— <?= e(ucfirst($op['tribe'])) ?> tribe, active <?= time_ago($op['last_activity']) ?></span>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php if ($stats['online_now'] > 8): ?>
        <p style="font-size:11px;color:var(--c-text-soft);margin-top:6px;">
            …and <?= $stats['online_now'] - 8 ?> more player(s) online.
        </p>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <p style="margin-top:18px;font-size:12px;color:var(--c-text-soft);font-style:italic;">
        No players online right now. Be the first to log in!
    </p>
    <?php endif; ?>
</div>

<div class="grid grid-3">
    <?php foreach ($TRIBES as $key => $tribe): ?>
    <div class="card" style="text-align:center;">
        <img src="<?= img_url("tribes/{$key}_crest.png") ?>" alt="<?= e($tribe['name']) ?>" style="width:120px;height:120px;image-rendering:pixelated;">
        <h3 style="color: var(--c-wood-dk); margin: 8px 0; font-family: Georgia, serif;">The <?= e($tribe['name']) ?></h3>
        <p style="font-size: 13px; color: var(--c-text-soft);"><?= e($tribe['desc']) ?></p>
    </div>
    <?php endforeach; ?>
</div>

<div class="card">
    <div class="card-header">Build Your Empire</div>
    <p>Start with a single village in the wilderness. Develop 18 resource fields (woodcutter, clay pit, iron mine, cropland) to fuel your growth. Construct barracks, stables, smithies, and marketplaces. Train armies unique to your tribe and march them across a vast world map of player villages and uncharted terrain.</p>
    <p style="margin-top:8px;">Resources accumulate in real time. Build queues let you stack upgrades while you sleep. Hero units gain experience. Forge alliances via embassies. The strategic depth of classic browser strategy—now in your own PHP-powered package.</p>
</div>

<div class="card">
    <div class="card-header">Strategic Infrastructure</div>
    <div class="grid grid-3" style="margin-top: 8px;">
        <div style="text-align:center;">
            <img src="<?= img_url('buildings/warehouse.png') ?>" alt="Warehouse" style="width:80px;height:80px;image-rendering:pixelated;">
            <div style="font-weight:bold;margin-top:4px;">Warehouse</div>
            <div style="font-size:11px;color:var(--c-text-soft);">Store wood, clay, iron</div>
        </div>
        <div style="text-align:center;">
            <img src="<?= img_url('buildings/barracks.png') ?>" alt="Barracks" style="width:80px;height:80px;image-rendering:pixelated;">
            <div style="font-weight:bold;margin-top:4px;">Barracks</div>
            <div style="font-size:11px;color:var(--c-text-soft);">Train infantry units</div>
        </div>
        <div style="text-align:center;">
            <img src="<?= img_url('buildings/hero_mansion.png') ?>" alt="Hero Mansion" style="width:80px;height:80px;image-rendering:pixelated;">
            <div style="font-weight:bold;margin-top:4px;">Hero Mansion</div>
            <div style="font-size:11px;color:var(--c-text-soft);">Recruit & level up heroes</div>
        </div>
    </div>
</div>

<div class="card" style="text-align:center;">
    <div class="card-header">Ready to make history?</div>
    <p style="margin: 12px 0;">Claim your quadrant, raise your banner, and write your name into the chronicles of <?= e(GAME_NAME) ?>.</p>
    <a href="<?= url('/register.php') ?>" class="btn btn-green btn-lg">Start Now</a>
    <a href="<?= url('/faq.php') ?>" class="btn btn-blue btn-lg">📖 Read the FAQ</a>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
