<?php
/**
 * troops.php — Troops overview (read-only).
 *
 * IMPORTANT: Troop TRAINING no longer happens on this page. Per spec, all
 * training takes place INSIDE the appropriate building:
 *   - Barracks  → infantry
 *   - Stable    → cavalry
 *   - Workshop  → siege engines (ram, catapult/trebuchet)
 *   - Residence → colonists (settlers)
 *
 * This page is now an OVERVIEW that shows:
 *   - The player's current troops (across all categories)
 *   - The training queue (units being trained right now)
 *   - Active troop movements (outgoing attacks, reinforcements, returns)
 *   - A "Send Troops" form (still useful for attacks/reinforcements)
 *   - Quick links to each military building (where training actually happens)
 */
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

$player = current_player();
$tribe = $player['tribe'];

// Find building levels (for the quick-links panel)
$buildings = get_buildings($village['id']);
$barracks_level  = 0;
$stable_level    = 0;
$workshop_level  = 0;
$residence_level = 0;
$buildings_by_pos = [];
foreach ($buildings as $b) {
    $buildings_by_pos[$b['position']] = $b;
    if ($b['building_type'] === 'barracks')  $barracks_level  = max($barracks_level,  (int)$b['level']);
    if ($b['building_type'] === 'stable')    $stable_level    = max($stable_level,    (int)$b['level']);
    if ($b['building_type'] === 'workshop')  $workshop_level  = max($workshop_level,  (int)$b['level']);
    if ($b['building_type'] === 'residence') $residence_level = max($residence_level, (int)$b['level']);
}

// Categorise units by their training building (using the new map)
$infantry_keys  = array_merge(
    units_for_building('barracks', $tribe)
);
$cavalry_keys   = units_for_building('stable', $tribe);
$siege_keys     = units_for_building('workshop', $tribe);
$colonist_keys  = units_for_building('residence', $tribe);

// Existing troops + queues
$troops         = get_village_troops($village['id']);
$training_queue = get_training_queue($village['id']);

$page_title = 'Troops';
require __DIR__ . '/app/views/header.php';
?>

<div class="grid grid-2">
    <div>
        <!-- ============================================================
             Troops overview by category
             ============================================================ -->
        <div class="card">
            <div class="card-header">⚔️ Your Troops</div>

            <?php if (empty($troops)): ?>
            <p style="color:var(--c-text-soft);text-align:center;padding:24px;">
                You have no troops yet. Train them at the
                <a href="<?= url('/village.php') ?>">Barracks</a>,
                <a href="<?= url('/village.php') ?>">Stable</a>,
                <a href="<?= url('/village.php') ?>">Workshop</a>, or
                <a href="<?= url('/village.php') ?>">Residence</a>.
            </p>
            <?php else: ?>

            <?php
            // Helper to render a category block
            function render_troop_category($title, $icon, $units_in_cat, $troops, $tribe) {
                if (empty($units_in_cat)) return;
                $has_any = false;
                foreach ($units_in_cat as $k) {
                    foreach ($troops as $t) {
                        if ($t['unit_type'] === $k && $t['count'] > 0) { $has_any = true; break 2; }
                    }
                }
                echo '<h4 style="font-size:12px;color:var(--c-wood-dk);margin:10px 0 4px;">' . $icon . ' ' . e($title) . '</h4>';
                if (!$has_any) {
                    echo '<p style="font-size:11px;color:var(--c-text-soft);padding:4px 0 8px;">None stationed here.</p>';
                    return;
                }
                echo '<table class="data" style="font-size:12px;margin-bottom:8px;">';
                echo '<thead><tr><th>Unit</th><th>Have</th></tr></thead><tbody>';
                foreach ($units_in_cat as $k) {
                    foreach ($troops as $t) {
                        if ($t['unit_type'] === $k && $t['count'] > 0) {
                            $stats = get_unit_stats($k);
                            $name  = $stats ? $stats['name'] : ucfirst(str_replace('_',' ',$k));
                            echo '<tr>';
                            echo '<td style="display:flex;align-items:center;gap:6px;">';
                            echo '<img src="' . img_url("troops/{$tribe}_{$k}.png") . '" width="24" height="24" alt="" style="image-rendering:pixelated;" onerror="this.style.display=\'none\';">';
                            echo '<div><strong>' . e($name) . '</strong><br>';
                            echo '<small>ATK ' . (int)$stats['attack'] . ' / DEF ' . (int)$stats['def_inf'] . '/' . (int)$stats['def_cav'] . ' / SPD ' . (int)$stats['speed'] . '</small>';
                            echo '</div></td>';
                            echo '<td><strong>' . (int)$t['count'] . '</strong></td>';
                            echo '</tr>';
                        }
                    }
                }
                echo '</tbody></table>';
            }

            render_troop_category('Infantry (Barracks)',     '⚔️', $infantry_keys, $troops, $tribe);
            render_troop_category('Cavalry (Stable)',        '🐎', $cavalry_keys,  $troops, $tribe);
            render_troop_category('Siege (Workshop)',        ' bombardment', $siege_keys,     $troops, $tribe);
            render_troop_category('Colonists (Residence)',   ' settlers',    $colonist_keys,  $troops, $tribe);
            ?>
            <?php endif; ?>
        </div>

        <!-- ============================================================
             Training queue
             ============================================================ -->
        <div class="card">
            <div class="card-header">⏳ Training Queue</div>
            <?php if (empty($training_queue)): ?>
            <p style="color:var(--c-text-soft);">No troops in training.</p>
            <?php else: ?>
            <?php foreach ($training_queue as $item):
                $stats = get_unit_stats($item['unit_type']);
                $uname = $stats ? $stats['name'] : ucfirst(str_replace('_',' ',$item['unit_type']));
            ?>
            <div class="queue-item">
                <img src="<?= img_url("troops/{$tribe}_{$item['unit_type']}.png") ?>"
                     width="24" height="24" alt=""
                     onerror="this.style.display='none';">
                <span class="queue-name">
                    <?= e($uname) ?> x<?= (int)$item['count'] ?>
                </span>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($item['finishes_at']) ?>">...</span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- ============================================================
             Send Troops form
             ============================================================ -->
        <div class="card">
            <div class="card-header">📤 Send Troops</div>
            <?php if (empty($troops)): ?>
            <p style="color:var(--c-text-soft);">You have no troops to send. Train some first.</p>
            <?php else: ?>
            <form method="POST" action="<?= url('/send_troops.php') ?>">
                <div class="form-group">
                    <label>Target Coordinates (X|Y)</label>
                    <div style="display:flex;gap:4px;">
                        <input type="number" name="to_x" class="form-control" placeholder="X" required style="flex:1;">
                        <input type="number" name="to_y" class="form-control" placeholder="Y" required style="flex:1;">
                    </div>
                </div>
                <div class="form-group">
                    <label>Mission</label>
                    <select name="mission" class="form-control">
                        <option value="attack">Attack (raid)</option>
                        <option value="reinforcement">Reinforcement</option>
                    </select>
                </div>
                <table class="data" style="font-size:12px;">
                    <thead>
                        <tr><th>Unit</th><th>Have</th><th>Send</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($troops as $t):
                        $u = get_unit_stats($t['unit_type']);
                        if (!$u) continue;
                    ?>
                    <tr>
                        <td>
                            <img src="<?= img_url("troops/{$tribe}_{$t['unit_type']}.png") ?>"
                                 width="20" height="20" alt=""
                                 style="vertical-align:middle;image-rendering:pixelated;"
                                 onerror="this.style.display='none';">
                            <?= e($u['name']) ?>
                        </td>
                        <td><?= (int)$t['count'] ?></td>
                        <td>
                            <input type="number" name="troops[<?= e($t['unit_type']) ?>]"
                                   min="0" max="<?= (int)$t['count'] ?>" value="0"
                                   style="width:60px;padding:2px;" class="form-control">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-red" style="margin-top:8px;">Send Troops</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <!-- ============================================================
             Military buildings — quick links (where training happens)
             ============================================================ -->
        <div class="panel">
            <div class="panel-title">🏋️ Train Troops (in buildings)</div>
            <p style="font-size:11px;color:var(--c-text-soft);margin-bottom:8px;">
                Troops are trained inside their respective buildings. Click a building below to open its training panel.
            </p>

            <?php
            // Find the position of each military building for the link
            $bld_positions = [];
            foreach ($buildings as $b) {
                if (in_array($b['building_type'], ['barracks','stable','workshop','residence'], true)) {
                    $bld_positions[$b['building_type']] = (int)$b['position'];
                }
            }
            ?>

            <?php if ($barracks_level > 0 && isset($bld_positions['barracks'])): ?>
            <a href="<?= url('/building.php?id=' . $bld_positions['barracks']) ?>"
               class="btn btn-green btn-sm" style="display:block;margin-bottom:4px;text-align:left;">
                ⚔️ Barracks (Lv <?= $barracks_level ?>) → Train Infantry
            </a>
            <?php else: ?>
            <span class="btn btn-sm" style="display:block;margin-bottom:4px;background:#888;color:#fff;cursor:not-allowed;text-align:left;">
                ⚔️ Barracks — not built (build via Village page)
            </span>
            <?php endif; ?>

            <?php if ($stable_level > 0 && isset($bld_positions['stable'])): ?>
            <a href="<?= url('/building.php?id=' . $bld_positions['stable']) ?>"
               class="btn btn-green btn-sm" style="display:block;margin-bottom:4px;text-align:left;">
                🐎 Stable (Lv <?= $stable_level ?>) → Train Cavalry
            </a>
            <?php else: ?>
            <span class="btn btn-sm" style="display:block;margin-bottom:4px;background:#888;color:#fff;cursor:not-allowed;text-align:left;">
                🐎 Stable — not built
            </span>
            <?php endif; ?>

            <?php if ($workshop_level > 0 && isset($bld_positions['workshop'])): ?>
            <a href="<?= url('/building.php?id=' . $bld_positions['workshop']) ?>"
               class="btn btn-green btn-sm" style="display:block;margin-bottom:4px;text-align:left;">
                 Workshop (Lv <?= $workshop_level ?>) → Build Siege
            </a>
            <?php else: ?>
            <span class="btn btn-sm" style="display:block;margin-bottom:4px;background:#888;color:#fff;cursor:not-allowed;text-align:left;">
                 Workshop — not built
            </span>
            <?php endif; ?>

            <?php if ($residence_level > 0 && isset($bld_positions['residence'])): ?>
            <a href="<?= url('/building.php?id=' . $bld_positions['residence']) ?>"
               class="btn btn-green btn-sm" style="display:block;margin-bottom:4px;text-align:left;">
                 Residence (Lv <?= $residence_level ?>) → Train Colonists
            </a>
            <?php else: ?>
            <span class="btn btn-sm" style="display:block;margin-bottom:4px;background:#888;color:#fff;cursor:not-allowed;text-align:left;">
                 Residence — not built
            </span>
            <?php endif; ?>
        </div>

        <!-- ============================================================
             Active movements
             ============================================================ -->
        <div class="panel">
            <div class="panel-title">Active Movements</div>
            <?php
            $movs = get_movements($village['id']);
            if (empty($movs['outgoing']) && empty($movs['incoming'])):
            ?>
            <p style="font-size:11px;color:var(--c-text-soft);">No active troop movements.</p>
            <?php else: ?>
            <?php if (!empty($movs['outgoing'])): ?>
            <h4 style="font-size:11px;color:var(--c-wood-dk);margin-top:8px;">OUTGOING</h4>
            <?php foreach ($movs['outgoing'] as $m):
                $type_label = ucfirst($m['type']);
                if ($m['type'] === 'return')         $type_label = '↩ Returning';
                elseif ($m['type'] === 'attack')     $type_label = '⚔ Attack';
                elseif ($m['type'] === 'reinforcement') $type_label = '🛡 Reinforce';
            ?>
            <div class="queue-item">
                <span class="queue-name">
                    <?= $type_label ?> → <?= e($m['target_name']) ?> (<?= e($m['target_player']) ?>)
                </span>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($m['arrives_at']) ?>">...</span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php if (!empty($movs['incoming'])): ?>
            <h4 style="font-size:11px;color:var(--c-red-dk);margin-top:8px;">INCOMING</h4>
            <?php foreach ($movs['incoming'] as $m):
                $type_label = ucfirst($m['type']);
                if ($m['type'] === 'attack')          $type_label = '⚠️ Attack from';
                elseif ($m['type'] === 'reinforcement') $type_label = '🛡 Reinforcement from';
                elseif ($m['type'] === 'return')      $type_label = '↩ Returning from';
            ?>
            <div class="queue-item">
                <span class="queue-name">
                    <?= $type_label ?> <?= e($m['source_name']) ?> (<?= e($m['source_player']) ?>)
                </span>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($m['arrives_at']) ?>">...</span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="panel">
            <div class="panel-title">Tips</div>
            <ul style="font-size:11px;padding-left:14px;">
                <li>Train infantry at the <strong>Barracks</strong>.</li>
                <li>Train cavalry at the <strong>Stable</strong>.</li>
                <li>Build siege engines at the <strong>Workshop</strong>.</li>
                <li>Train colonists at the <strong>Residence</strong> (3 needed to found a new village).</li>
                <li>Higher building levels = faster training.</li>
                <li>Build an <strong>Academy</strong> to research advanced units before training them.</li>
                <li>Server speed (<?= GAME_SERVER_SPEED ?>x) applies to training time.</li>
            </ul>
        </div>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
