<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();

if (current_player_id()) {
    redirect('/village.php');
}

global $TRIBES, $QUADRANTS;

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $tribe    = $_POST['tribe'] ?? 'roman';
    $quadrant = $_POST['quadrant'] ?? 'NorthEast';

    // Validation
    if (strlen($username) < 3 || strlen($username) > 20) {
        $error = 'Username must be 3-20 characters long.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif (!isset($TRIBES[$tribe])) {
        $error = 'Invalid tribe selected.';
    } elseif (!isset($QUADRANTS[$quadrant])) {
        $error = 'Invalid quadrant selected.';
    } else {
        // Check if username/email is taken
        $exists = db()->fetch("SELECT id FROM players WHERE username = ? OR email = ?", [$username, $email]);
        if ($exists) {
            $error = 'Username or email already taken.';
        } else {
            // Pick a random coordinate in the chosen quadrant
            [$dx, $dy] = $QUADRANTS[$quadrant];
            $x = $dx * random_int(10, 90);
            $y = $dy * random_int(10, 90);

            // Create player
            $player_id = db()->insert('players', [
                'username' => $username,
                'email'    => $email,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'tribe'    => $tribe,
                'quadrant' => $quadrant,
            ]);

            // Create village
            $village_id = db()->insert('villages', [
                'player_id'  => $player_id,
                'name'       => $username . "'s Village",
                'x'          => $x,
                'y'          => $y,
                'is_capital' => 1,
            ]);

            // Explicitly initialize village data via PHP (primary path).
            // This ensures resources, resource_fields, and main_building exist
            // even if the SQL trigger trg_init_village is missing or broken.
            ensure_village_data($village_id);

            // Create hero
            db()->insert('heroes', [
                'player_id'  => $player_id,
                'village_id' => $village_id,
                'name'       => $username,
            ]);

            // Welcome report
            db()->insert('reports', [
                'player_id' => $player_id,
                'title'     => 'Welcome to ' . GAME_NAME . '!',
                'body'      => "Welcome, $username! Your village has been founded at coordinates $x|$y in the $quadrant quadrant.\n\nStart by upgrading your resource fields (Fields tab) to gather more wood, clay, iron, and crop. Then build a Warehouse and Granary to increase storage, and a Barracks to train your first soldiers.",
                'category'  => 'general',
            ]);

            // Auto-login
            $_SESSION['player_id'] = $player_id;
            redirect('/village.php');
        }
    }
}

$page_title = 'Register';
require __DIR__ . '/app/views/header.php';
?>
<div class="auth-form card">
    <h1>Register</h1>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required minlength="3" maxlength="20"
                   value="<?= e($_POST['username'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required
                   value="<?= e($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required minlength="6">
        </div>

        <div class="form-group">
            <label>Choose Your Tribe</label>
            <input type="hidden" name="tribe" id="tribe-input" value="roman">
            <div class="tribes-showcase" style="grid-template-columns: repeat(3, 1fr);">
                <?php foreach ($TRIBES as $key => $tribe): ?>
                <div class="tribe-card <?= ($_POST['tribe'] ?? 'roman') === $key ? 'selected' : '' ?>" data-tribe="<?= e($key) ?>">
                    <img src="<?= img_url("tribes/{$key}.png") ?>" alt="<?= e($tribe['name']) ?>">
                    <h4><?= e($tribe['name']) ?></h4>
                    <p><?= e($tribe['desc']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="form-group">
            <label>Starting Quadrant</label>
            <select name="quadrant" class="form-control">
                <?php foreach (array_keys($QUADRANTS) as $q): ?>
                <option value="<?= e($q) ?>" <?= ($_POST['quadrant'] ?? '') === $q ? 'selected' : '' ?>><?= e($q) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-green btn-lg" style="width: 100%;">Create Account</button>
    </form>

    <p style="text-align:center; margin-top:12px;">
        Already have an account? <a href="<?= url('/login.php') ?>">Login</a>
    </p>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
