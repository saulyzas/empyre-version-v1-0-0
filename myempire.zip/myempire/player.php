<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

// Get target player
$target_id = (int)($_GET['id'] ?? 0);
$target = db()->fetch(
    "SELECT p.*, COUNT(v.id) AS village_count
     FROM players p
     LEFT JOIN villages v ON v.player_id = p.id
     WHERE p.id = ?
     GROUP BY p.id",
    [$target_id]
);

if (!$target) {
    redirect('/stats.php');
}

// Get target villages
$target_villages = db()->fetchAll(
    "SELECT * FROM villages WHERE player_id = ? ORDER BY is_capital DESC, id ASC",
    [$target_id]
);

// Get target's tribe info
$tribe_name = ucfirst($target['tribe']);
$loot_mult = $GLOBALS['TRIBE_LOOT_MULTIPLIER'][$target['tribe']] ?? 0.7;
$loot_pct = round($loot_mult * 100);

// Get target's hero
$target_hero = db()->fetch("SELECT * FROM heroes WHERE player_id = ?", [$target_id]);

// Get target's total troops (across all villages)
$target_troops_count = (int)db()->fetchColumn(
    "SELECT COALESCE(SUM(count), 0) FROM troops t
     JOIN villages v ON v.id = t.village_id
     WHERE v.player_id = ?",
    [$target_id]
);

// Get my villages (for sending resources)
$my_villages = db()->fetchAll(
    "SELECT * FROM villages WHERE player_id = ? ORDER BY is_capital DESC, id ASC",
    [current_player_id()]
);

// Check what buildings I have (for permissions)
$my_buildings = get_buildings($village['id']);
$my_marketplace_level = 0;
$my_barracks_level = 0;
$my_stable_level = 0;
$my_rally_point_level = 0;
foreach ($my_buildings as $b) {
    if ($b['building_type'] === 'marketplace') $my_marketplace_level = max($my_marketplace_level, (int)$b['level']);
    if ($b['building_type'] === 'barracks')    $my_barracks_level    = max($my_barracks_level, (int)$b['level']);
    if ($b['building_type'] === 'stable')      $my_stable_level      = max($my_stable_level, (int)$b['level']);
    if ($b['building_type'] === 'rally_point') $my_rally_point_level = max($my_rally_point_level, (int)$b['level']);
}

$merchants_have = merchants_available($my_marketplace_level);
$merchants_in_use = (int)db()->fetchColumn(
    "SELECT COALESCE(SUM(merchants_used), 0) FROM resource_movements
     WHERE from_village_id = ? AND status = 'in_progress'",
    [$village['id']]
);
$merchants_free = $merchants_have - $merchants_in_use;
$merchant_capacity = merchant_total_capacity($merchants_free);

// Handle resource send
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'send_resources') {
        $to_vid = (int)($_POST['to_village_id'] ?? 0);
        $wood = (int)($_POST['wood'] ?? 0);
        $clay = (int)($_POST['clay'] ?? 0);
        $iron = (int)($_POST['iron'] ?? 0);
        $crop = (int)($_POST['crop'] ?? 0);

        // Verify target village belongs to target player
        $to_vil = db()->fetch("SELECT * FROM villages WHERE id = ? AND player_id = ?", [$to_vid, $target_id]);
        if (!$to_vil) {
            $error = 'Target village not found.';
        } else {
            $result = send_resources($village['id'], $to_vid, $wood, $clay, $iron, $crop);
            if ($result['ok']) {
                $success = "Resources sent! Merchants will arrive at " . $result['arrives_at'];
                redirect('/player.php?id=' . $target_id . '&sent=1');
            } else {
                $error = $result['error'];
            }
        }
    }
}

if (isset($_GET['sent'])) $success = 'Resources sent successfully!';

$page_title = 'Player: ' . $target['username'];
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:760px;margin:0 auto;">
    <div class="card-header">
        <img src="<?= img_url("tribes/{$target['tribe']}.png") ?>" alt="" width="32" height="32" style="vertical-align:middle;image-rendering:pixelated;">
        <?= e($target['username']) ?> — <?= e($tribe_name) ?>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success"><?= e($success) ?></div>
    <?php endif; ?>

    <table class="data">
        <tr>
            <th>Player</th>
            <td><?= e($target['username']) ?></td>
        </tr>
        <tr>
            <th>Tribe</th>
            <td>
                <img src="<?= img_url("tribes/{$target['tribe']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                <?= e($tribe_name) ?>
            </td>
        </tr>
        <tr>
            <th>Population</th>
            <td><?= (int)$target['population'] ?></td>
        </tr>
        <tr>
            <th>Villages</th>
            <td><?= (int)$target['village_count'] ?></td>
        </tr>
        <tr>
            <th>Total Troops</th>
            <td><?= $target_troops_count ?></td>
        </tr>
        <tr>
            <th>Loot Bonus</th>
            <td><?= $loot_pct ?>% of carry capacity</td>
        </tr>
        <tr>
            <th>Hero</th>
            <td>
                <?php if ($target_hero): ?>
                    <?= e($target_hero['name']) ?> (Lv <?= (int)$target_hero['level'] ?>)
                <?php else: ?>
                    <em>No hero</em>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th>Joined</th>
            <td><?= e($target['created_at']) ?></td>
        </tr>
        <?php if ($target['last_login']): ?>
        <tr>
            <th>Last login</th>
            <td><?= e($target['last_login']) ?></td>
        </tr>
        <?php endif; ?>
    </table>
</div>

<!-- Target villages list -->
<div class="card" style="max-width:760px;margin:16px auto;">
    <div class="card-header">Villages</div>
    <table class="data">
        <thead>
            <tr>
                <th>Name</th>
                <th>Coordinates</th>
                <th>Population</th>
                <th>Capital</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($target_villages as $tv): ?>
        <tr>
            <td><?= e($tv['name']) ?></td>
            <td><a href="<?= url('/map.php') . '?x=' . (int)$tv['x'] . '&y=' . (int)$tv['y'] ?>"><?= (int)$tv['x'] ?>|<?= (int)$tv['y'] ?></a></td>
            <td><?= (int)$target['population'] ?></td>
            <td><?= $tv['is_capital'] ? '★' : '' ?></td>
            <td>
                <a href="<?= url('/attack.php') . '?x=' . (int)$tv['x'] . '&y=' . (int)$tv['y'] ?>" class="btn btn-red btn-sm">⚔ Attack</a>
                <a href="<?= url('/send_resources.php') . '?to_village=' . (int)$tv['id'] ?>" class="btn btn-blue btn-sm">📦 Send</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Quick attack form -->
<div class="card" style="max-width:760px;margin:16px auto;">
    <div class="card-header">⚔️ Attack <?= e($target['username']) ?></div>
    <?php if (empty(get_village_troops($village['id']))): ?>
    <p style="color:var(--c-text-soft);text-align:center;padding:12px;">
        You have no troops to attack with. Train some at the <a href="<?= url('/troops.php') ?>">Troops</a> page first.
    </p>
    <?php else: ?>
    <form method="POST" action="<?= url('/send_troops.php') ?>">
        <input type="hidden" name="mission" value="attack">
        <p>Select target village and troops to send:</p>
        <div class="form-group">
            <label>Target Village</label>
            <select name="to_x" id="attack_target_x" class="form-control" onchange="document.getElementById('attack_target_y').value = this.options[this.selectedIndex].dataset.y;">
                <?php foreach ($target_villages as $tv): ?>
                <option value="<?= (int)$tv['x'] ?>" data-y="<?= (int)$tv['y'] ?>"><?= e($tv['name']) ?> (<?= (int)$tv['x'] ?>|<?= (int)$tv['y'] ?>)</option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="to_y" id="attack_target_y" value="<?= (int)$target_villages[0]['y'] ?>">
        </div>
        <table class="data" style="font-size:12px;">
            <thead>
                <tr><th>Unit</th><th>Have</th><th>Send</th></tr>
            </thead>
            <tbody>
            <?php
            $my_player = current_player();
            $my_tribe = $my_player['tribe'];
            $my_troops = get_village_troops($village['id']);
            $my_units = $GLOBALS['UNITS'][$my_tribe] ?? [];
            foreach ($my_troops as $t):
                $u = $my_units[$t['unit_type']] ?? null;
                if (!$u) continue;
            ?>
            <tr>
                <td>
                    <img src="<?= img_url("troops/{$my_tribe}_{$t['unit_type']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e($u['name']) ?>
                </td>
                <td><?= (int)$t['count'] ?></td>
                <td>
                    <input type="number" name="troops[<?= e($t['unit_type']) ?>]" min="0" max="<?= (int)$t['count'] ?>" value="0" style="width:60px;padding:2px;" class="form-control">
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-red" style="margin-top:8px;">⚔ Send Attack</button>
    </form>
    <?php endif; ?>
</div>

<!-- Send resources form -->
<div class="card" style="max-width:760px;margin:16px auto;">
    <div class="card-header">📦 Send Resources to <?= e($target['username']) ?></div>
    <?php if ($my_marketplace_level < 1): ?>
    <div class="alert alert-info">
        You need a <strong>Marketplace</strong> to send resources to other players.
        Build one in your village first.
    </div>
    <?php else: ?>
    <p style="font-size:12px;color:var(--c-text-soft);">
        Marketplace Lv <?= $my_marketplace_level ?> |
        Merchants: <?= $merchants_free ?>/<?= $merchants_have ?> free |
        Capacity: <?= $merchant_capacity ?> resources
    </p>
    <form method="POST">
        <input type="hidden" name="action" value="send_resources">
        <div class="form-group">
            <label>Target Village</label>
            <select name="to_village_id" class="form-control">
                <?php foreach ($target_villages as $tv): ?>
                <option value="<?= (int)$tv['id'] ?>"><?= e($tv['name']) ?> (<?= (int)$tv['x'] ?>|<?= (int)$tv['y'] ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <table class="data" style="font-size:12px;">
            <thead>
                <tr><th>Resource</th><th>You have</th><th>Send</th></tr>
            </thead>
            <tbody>
            <tr>
                <td><span class="res-icon res-wood"></span> Wood</td>
                <td><?= format_number($resources['wood']) ?></td>
                <td><input type="number" name="wood" min="0" max="<?= (int)$resources['wood'] ?>" value="0" style="width:80px;padding:2px;" class="form-control"></td>
            </tr>
            <tr>
                <td><span class="res-icon res-clay"></span> Clay</td>
                <td><?= format_number($resources['clay']) ?></td>
                <td><input type="number" name="clay" min="0" max="<?= (int)$resources['clay'] ?>" value="0" style="width:80px;padding:2px;" class="form-control"></td>
            </tr>
            <tr>
                <td><span class="res-icon res-iron"></span> Iron</td>
                <td><?= format_number($resources['iron']) ?></td>
                <td><input type="number" name="iron" min="0" max="<?= (int)$resources['iron'] ?>" value="0" style="width:80px;padding:2px;" class="form-control"></td>
            </tr>
            <tr>
                <td><span class="res-icon res-crop"></span> Crop</td>
                <td><?= format_number($resources['crop']) ?></td>
                <td><input type="number" name="crop" min="0" max="<?= (int)$resources['crop'] ?>" value="0" style="width:80px;padding:2px;" class="form-control"></td>
            </tr>
            </tbody>
        </table>
        <button type="submit" class="btn btn-blue" style="margin-top:8px;">📦 Send Resources</button>
    </form>
    <?php endif; ?>
</div>

<p style="text-align:center;margin:16px 0;">
    <a href="<?= url('/stats.php') ?>">← Back to Ranks</a>
</p>

<?php require __DIR__ . '/app/views/footer.php'; ?>
