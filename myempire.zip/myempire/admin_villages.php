<?php
/**
 * admin_villages.php — Village management.
 *
 * Actions:
 *   - Search / filter villages (by name, by owner, by coords)
 *   - Rename village
 *   - Set loyalty (0-100)
 *   - Award resources (wood/clay/iron/crop)
 *   - Delete village (only if owner has more than 1)
 *   - View village detail (buildings, troops, resources)
 */
require_once __DIR__ . '/app/lib/helpers.php';
require_once __DIR__ . '/app/lib/admin_helpers.php';
init_session();
require_admin();

// ---- Handle POST actions ----
$action_msg = '';
$action_err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action     = $_POST['action'] ?? '';
    $village_id = (int)($_POST['village_id'] ?? 0);

    switch ($action) {
        case 'rename':
            $new_name = $_POST['new_name'] ?? '';
            $r = admin_rename_village($village_id, $new_name);
            break;
        case 'set_loyalty':
            $loyalty = (float)($_POST['loyalty'] ?? 100);
            $r = admin_set_loyalty($village_id, $loyalty);
            break;
        case 'award_resources':
            $wood = (int)($_POST['wood'] ?? 0);
            $clay = (int)($_POST['clay'] ?? 0);
            $iron = (int)($_POST['iron'] ?? 0);
            $crop = (int)($_POST['crop'] ?? 0);
            $r = admin_award_resources($village_id, $wood, $clay, $iron, $crop);
            break;
        case 'delete':
            $confirm = $_POST['confirm'] ?? '';
            if ($confirm !== 'DELETE') {
                $r = ['ok' => false, 'error' => 'Type DELETE in the confirmation box.'];
            } else {
                $r = admin_delete_village($village_id);
                if ($r['ok']) {
                    header('Location: ' . url('/admin_villages.php?msg=deleted'));
                    exit;
                }
            }
            break;
        default:
            $r = ['ok' => false, 'error' => 'Unknown action.'];
    }

    if (!empty($r['ok'])) {
        $action_msg = ucfirst(str_replace('_', ' ', $action)) . ' succeeded.';
    } else {
        $action_err = $r['error'] ?? 'Action failed.';
    }
}

if (isset($_GET['msg']) && $_GET['msg'] === 'deleted') {
    $action_msg = 'Village deleted successfully.';
}

// ---- Filters ----
$search = trim($_GET['search'] ?? '');

$sql = "SELECT v.*, p.username, p.tribe, p.id AS player_id,
        (SELECT COUNT(*) FROM buildings b WHERE b.village_id = v.id) AS building_count,
        (SELECT COALESCE(SUM(count), 0) FROM troops t WHERE t.village_id = v.id) AS troop_count
        FROM villages v
        JOIN players p ON p.id = v.player_id";
$where = [];
$params = [];
if ($search !== '') {
    $where[] = "(v.name LIKE ? OR p.username LIKE ? OR CAST(v.x AS TEXT) LIKE ? OR CAST(v.y AS TEXT) LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}
if (!empty($where)) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY v.is_capital DESC, v.created_at DESC LIMIT 200";

$villages = db()->fetchAll($sql, $params);

// If ?id=N is set, show detail panel for that village
$detail_vid = (int)($_GET['id'] ?? 0);
$detail_village = null;
if ($detail_vid > 0) {
    $detail_village = db()->fetch(
        "SELECT v.*, p.username, p.tribe, p.id AS player_id
         FROM villages v
         JOIN players p ON p.id = v.player_id
         WHERE v.id = ?",
        [$detail_vid]
    );
    if ($detail_village) {
        // Refresh resources for accuracy
        $detail_resources = update_resources($detail_vid);
        $detail_buildings = get_buildings($detail_vid);
        $detail_troops    = get_village_troops($detail_vid);
        $detail_fields    = get_resource_fields($detail_vid);
        $detail_queue     = get_build_queue($detail_vid);
        $detail_training  = get_training_queue($detail_vid);
        $detail_research  = get_research_queue($detail_vid);
        $detail_researched= get_researched_units($detail_vid);

        $village_count_for_owner = (int)db()->fetchColumn(
            "SELECT COUNT(*) FROM villages WHERE player_id = ?",
            [$detail_village['player_id']]
        );
    }
}

$page_title = 'Admin — Villages';
require __DIR__ . '/app/views/header.php';
?>

<div class="card">
    <div class="card-header" style="background:linear-gradient(135deg,#8e2a26,#5a1a18);color:#fff;">
        🏘️ Admin — Village Management
    </div>

    <p style="font-size:12px;">
        <a href="<?= url('/admin.php') ?>">← Back to Admin Panel</a>
    </p>

    <?php if ($action_msg): ?>
    <div class="alert alert-success"><?= e($action_msg) ?></div>
    <?php endif; ?>
    <?php if ($action_err): ?>
    <div class="alert alert-error"><?= e($action_err) ?></div>
    <?php endif; ?>

    <!-- ============================================================
         Village detail panel
         ============================================================ -->
    <?php if ($detail_village): ?>
    <div style="background:#fff8d6;border:2px solid var(--c-gold-dk);border-radius:8px;padding:14px;margin-bottom:16px;">
        <h3 style="color:var(--c-wood-dk);margin-bottom:8px;">
            🏘️ <?= e($detail_village['name']) ?>
            <?php if ($detail_village['is_capital']): ?>
                <span style="background:var(--c-gold-dk);color:#fff;padding:2px 6px;border-radius:3px;font-size:10px;">CAPITAL</span>
            <?php endif; ?>
            <span style="font-size:12px;color:var(--c-text-soft);">(ID <?= (int)$detail_village['id'] ?>)</span>
        </h3>

        <table class="data" style="font-size:12px;margin-bottom:12px;">
            <tr><th>Owner</th><td>
                <img src="<?= img_url("tribes/{$detail_village['tribe']}.png") ?>" width="16" height="16" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                <a href="<?= url('/admin_players.php?id=' . (int)$detail_village['player_id']) ?>"><?= e($detail_village['username']) ?></a>
            </td></tr>
            <tr><th>Coordinates</th><td><?= (int)$detail_village['x'] ?> | <?= (int)$detail_village['y'] ?></td></tr>
            <tr><th>Loyalty</th><td><?= (int)$detail_village['loyalty'] ?>%</td></tr>
            <tr><th>Created</th><td><?= e($detail_village['created_at']) ?></td></tr>
            <tr>
                <th>Resources</th>
                <td>
                    <span class="res-icon res-wood"></span><?= (int)$detail_resources['wood'] ?>/<?= (int)$detail_resources['wood_cap'] ?>
                    &nbsp;<span class="res-icon res-clay"></span><?= (int)$detail_resources['clay'] ?>/<?= (int)$detail_resources['clay_cap'] ?>
                    &nbsp;<span class="res-icon res-iron"></span><?= (int)$detail_resources['iron'] ?>/<?= (int)$detail_resources['iron_cap'] ?>
                    &nbsp;<span class="res-icon res-crop"></span><?= (int)$detail_resources['crop'] ?>/<?= (int)$detail_resources['crop_cap'] ?>
                </td>
            </tr>
            <tr><th>Buildings</th><td><?= count($detail_buildings) ?></td></tr>
            <tr><th>Troops stationed</th><td><?= array_sum(array_column($detail_troops, 'count')) ?></td></tr>
            <tr><th>Resource fields</th><td><?= count($detail_fields) ?></td></tr>
            <tr><th>Build queue</th><td><?= count($detail_queue) ?></td></tr>
            <tr><th>Training queue</th><td><?= count($detail_training) ?></td></tr>
            <tr><th>Research queue</th><td><?= count($detail_research) ?></td></tr>
            <tr><th>Researched units</th><td><?= count($detail_researched) ?></td></tr>
        </table>

        <!-- Action forms -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;">

            <!-- Rename -->
            <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:8px;border-radius:4px;">
                <input type="hidden" name="action" value="rename">
                <input type="hidden" name="village_id" value="<?= (int)$detail_village['id'] ?>">
                <div style="font-size:11px;color:var(--c-text-soft);margin-bottom:4px;">Rename village:</div>
                <input type="text" name="new_name" class="form-control" value="<?= e($detail_village['name']) ?>" maxlength="60" style="font-size:11px;margin-bottom:4px;" required>
                <button type="submit" class="btn btn-sm btn-blue" style="width:100%;">✏️ Rename</button>
            </form>

            <!-- Set loyalty -->
            <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:8px;border-radius:4px;">
                <input type="hidden" name="action" value="set_loyalty">
                <input type="hidden" name="village_id" value="<?= (int)$detail_village['id'] ?>">
                <div style="font-size:11px;color:var(--c-text-soft);margin-bottom:4px;">Loyalty (0-100):</div>
                <input type="number" name="loyalty" class="form-control" value="<?= (int)$detail_village['loyalty'] ?>" min="0" max="100" step="1" style="font-size:11px;margin-bottom:4px;" required>
                <button type="submit" class="btn btn-sm btn-gold" style="width:100%;">⚖️ Set Loyalty</button>
            </form>

            <!-- Award resources -->
            <form method="POST" style="background:#fff;border:1px solid var(--c-outline);padding:8px;border-radius:4px;">
                <input type="hidden" name="action" value="award_resources">
                <input type="hidden" name="village_id" value="<?= (int)$detail_village['id'] ?>">
                <div style="font-size:11px;color:var(--c-text-soft);margin-bottom:4px;">Award resources (negatives deduct):</div>
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:4px;font-size:10px;">
                    <input type="number" name="wood" class="form-control" placeholder="Wood" value="0" style="font-size:10px;padding:2px;">
                    <input type="number" name="clay" class="form-control" placeholder="Clay" value="0" style="font-size:10px;padding:2px;">
                    <input type="number" name="iron" class="form-control" placeholder="Iron" value="0" style="font-size:10px;padding:2px;">
                    <input type="number" name="crop" class="form-control" placeholder="Crop" value="0" style="font-size:10px;padding:2px;">
                </div>
                <button type="submit" class="btn btn-sm btn-green" style="width:100%;margin-top:4px;">📦 Award Resources</button>
            </form>

            <!-- Delete (with confirmation) -->
            <?php if ($village_count_for_owner > 1): ?>
            <form method="POST" style="background:#fce4e4;border:1px solid #8e2a26;padding:8px;border-radius:4px;"
                  onsubmit="return confirm('⚠️ Delete this village? The player will lose it permanently.');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="village_id" value="<?= (int)$detail_village['id'] ?>">
                <div style="font-size:11px;color:#8e2a26;margin-bottom:4px;">Type DELETE to confirm:</div>
                <input type="text" name="confirm" class="form-control" placeholder="DELETE" style="font-size:11px;margin-bottom:4px;" required>
                <button type="submit" class="btn btn-sm btn-red" style="width:100%;">🗑️ Delete Village</button>
            </form>
            <?php else: ?>
            <div style="background:#fce4e4;border:1px solid #8e2a26;padding:8px;border-radius:4px;font-size:11px;color:#8e2a26;">
                ⚠️ Cannot delete this village — it is the owner's only village. Delete the player instead.
            </div>
            <?php endif; ?>
        </div>

        <!-- Buildings list -->
        <?php if (!empty($detail_buildings)): ?>
        <h4 style="margin-top:14px;font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">Buildings</h4>
        <table class="data" style="font-size:11px;">
            <thead><tr><th>Position</th><th>Type</th><th>Level</th></tr></thead>
            <tbody>
            <?php foreach ($detail_buildings as $b): ?>
            <tr>
                <td><?= (int)$b['position'] ?></td>
                <td><?= ucfirst(str_replace('_', ' ', $b['building_type'])) ?></td>
                <td><?= (int)$b['level'] ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

        <!-- Troops list -->
        <?php if (!empty($detail_troops)): ?>
        <h4 style="margin-top:14px;font-size:12px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">Troops</h4>
        <table class="data" style="font-size:11px;">
            <thead><tr><th>Unit type</th><th>Count</th></tr></thead>
            <tbody>
            <?php foreach ($detail_troops as $t): ?>
            <tr>
                <td><?= ucfirst(str_replace('_', ' ', $t['unit_type'])) ?></td>
                <td><?= (int)$t['count'] ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

        <p style="margin-top:14px;">
            <a href="<?= url('/cell.php?x=' . (int)$detail_village['x'] . '&y=' . (int)$detail_village['y']) ?>" class="btn btn-sm btn-blue">📍 View on Map</a>
            <a href="<?= url('/admin_villages.php') ?>" class="btn btn-sm">← Back to list</a>
        </p>
    </div>
    <?php endif; ?>

    <!-- ============================================================
         Search + list
         ============================================================ -->
    <form method="GET" style="background:#fff;border:1px solid var(--c-outline);padding:10px;border-radius:6px;margin-bottom:16px;">
        <div style="display:flex;gap:8px;align-items:end;flex-wrap:wrap;">
            <div>
                <label style="font-size:11px;color:var(--c-text-soft);">Search</label><br>
                <input type="text" name="search" class="form-control" value="<?= e($search) ?>" placeholder="name, owner, or coords" style="width:240px;">
            </div>
            <button type="submit" class="btn btn-blue btn-sm">🔍 Filter</button>
            <a href="<?= url('/admin_villages.php') ?>" class="btn btn-sm">Clear</a>
        </div>
    </form>

    <h3 style="font-size:13px;color:var(--c-wood-dk);text-transform:uppercase;letter-spacing:1px;">
        Villages (<?= count($villages) ?> shown)
    </h3>
    <table class="data" style="font-size:12px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>Village</th>
                <th>Owner</th>
                <th>Coords</th>
                <th>Loyalty</th>
                <th>Buildings</th>
                <th>Troops</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($villages as $v): ?>
        <tr style="<?= $v['is_capital'] ? 'background:#fff8d6;' : '' ?>">
            <td><?= (int)$v['id'] ?></td>
            <td>
                <?= e($v['name']) ?>
                <?php if ($v['is_capital']): ?><span title="Capital">★</span><?php endif; ?>
            </td>
            <td>
                <img src="<?= img_url("tribes/{$v['tribe']}.png") ?>" width="14" height="14" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                <a href="<?= url('/admin_players.php?id=' . (int)$v['player_id']) ?>"><?= e($v['username']) ?></a>
            </td>
            <td><a href="<?= url('/cell.php?x=' . (int)$v['x'] . '&y=' . (int)$v['y']) ?>"><?= (int)$v['x'] ?>|<?= (int)$v['y'] ?></a></td>
            <td><?= (int)$v['loyalty'] ?>%</td>
            <td><?= (int)$v['building_count'] ?></td>
            <td><?= (int)$v['troop_count'] ?></td>
            <td>
                <a href="<?= url('/admin_villages.php?id=' . (int)$v['id']) ?>" class="btn btn-sm btn-blue">Manage</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($villages)): ?>
        <tr><td colspan="8" style="text-align:center;color:var(--c-text-soft);padding:16px;">No villages match your filters.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
