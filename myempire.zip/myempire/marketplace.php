<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);
$player = current_player();

// Check if player has a Marketplace
$buildings = get_buildings($village['id']);
$market_level = 0;
foreach ($buildings as $b) {
    if ($b['building_type'] === 'marketplace') $market_level = max($market_level, (int)$b['level']);
}

// Handle actions
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $market_level >= 1) {
    $action = $_POST['action'] ?? '';

    if ($action === 'send') {
        // Send resources to another player (uses merchants, no gold cost)
        $to_village_id = (int)($_POST['to_village_id'] ?? 0);
        $wood = (int)($_POST['wood'] ?? 0);
        $clay = (int)($_POST['clay'] ?? 0);
        $iron = (int)($_POST['iron'] ?? 0);
        $crop = (int)($_POST['crop'] ?? 0);

        $to_vil = db()->fetch("SELECT * FROM villages WHERE id = ?", [$to_village_id]);
        if (!$to_vil) {
            $error = 'Target village not found.';
        } else {
            $result = send_resources($village['id'], $to_village_id, $wood, $clay, $iron, $crop);
            if ($result['ok']) {
                $success = "📦 Resources sent to " . e($to_vil['name']) . "! Merchants will arrive at " . $result['arrives_at'];
            } else {
                $error = $result['error'];
            }
        }
    } elseif ($action === 'npc_redistribute') {
        // NPC Trade: redistribute resources for 1 gold
        $new_amounts = [
            'wood' => (int)($_POST['new_wood'] ?? 0),
            'clay' => (int)($_POST['new_clay'] ?? 0),
            'iron' => (int)($_POST['new_iron'] ?? 0),
            'crop' => (int)($_POST['new_crop'] ?? 0),
        ];
        $result = npc_redistribute_resources($village['id'], $new_amounts);
        if ($result['ok']) {
            $success = "🔄 Resources redistributed! Cost: {$result['gold_spent']} gold.";
        } else {
            $error = $result['error'];
        }
    } elseif ($action === 'create_offer') {
        // Create a trade offer
        $offer_resource = $_POST['offer_resource'] ?? '';
        $offer_amount = (int)($_POST['offer_amount'] ?? 0);
        $want_resource = $_POST['want_resource'] ?? '';
        $want_amount = (int)($_POST['want_amount'] ?? 0);
        $max_transport = (int)($_POST['max_transport_hours'] ?? 24);

        $result = create_trade_offer($village['id'], $offer_resource, $offer_amount, $want_resource, $want_amount, $max_transport);
        if ($result['ok']) {
            $success = "📋 Trade offer created! Offering $offer_amount $offer_resource for $want_amount $want_resource.";
        } else {
            $error = $result['error'];
        }
    } elseif ($action === 'accept_offer') {
        // Accept a trade offer
        $offer_id = (int)($_POST['offer_id'] ?? 0);
        $result = accept_trade_offer($offer_id, $village['id']);
        if ($result['ok']) {
            $success = "✅ Trade accepted! Resources will arrive at " . $result['arrives_at'];
        } else {
            $error = $result['error'];
        }
    } elseif ($action === 'cancel_offer') {
        $offer_id = (int)($_POST['offer_id'] ?? 0);
        $result = cancel_trade_offer($offer_id, $player['id']);
        if ($result['ok']) {
            $success = "❌ Trade offer cancelled. Resources returned to your warehouse.";
        } else {
            $error = $result['error'];
        }
    }
}

// Refresh player data after action
$player = current_player();
$resources = update_resources($village['id']);

// Tab
$tab = $_GET['tab'] ?? 'send';
$valid_tabs = ['send','npc','offers','create'];
if (!in_array($tab, $valid_tabs)) $tab = 'send';

// Get merchant info for "send" tab
$merchants_have = merchants_available($market_level);
$merchants_in_use = (int)db()->fetchColumn(
    "SELECT COALESCE(SUM(merchants_used), 0) FROM resource_movements
     WHERE from_village_id = ? AND status = 'in_progress'",
    [$village['id']]
);
$merchants_free = $merchants_have - $merchants_in_use;
$merchant_capacity = merchant_total_capacity($merchants_free);

// Get all villages for sending (excluding own current village)
$other_villages = db()->fetchAll(
    "SELECT v.id, v.name, v.x, v.y, p.username, p.tribe
     FROM villages v JOIN players p ON p.id = v.player_id
     WHERE v.id != ?
     ORDER BY p.username, v.name
     LIMIT 200",
    [$village['id']]
);

// Get trade offers (for Offers tab)
$active_offers = get_active_trade_offers($player['id']);
$my_offers = get_my_trade_offers($player['id']);

$page_title = 'Marketplace';
require __DIR__ . '/app/views/header.php';
?>

<style>
.tab-bar { display:flex; gap:4px; margin-bottom:16px; flex-wrap:wrap; }
.tab-bar a { padding:8px 16px; background:var(--c-stone); border:2px solid var(--c-stone-dk); border-radius:6px; text-decoration:none; color:var(--c-text); font-weight:bold; font-size:13px; }
.tab-bar a.active { background:var(--c-gold); color:var(--c-text); border-color:var(--c-outline); }
.tab-bar a:hover { text-decoration:none; transform:translateY(-1px); }

.gold-display { display:flex; align-items:center; gap:8px; background:linear-gradient(135deg,#f0c34b,#b88e28); color:#2a1f15; padding:8px 16px; border-radius:8px; border:2px solid var(--c-outline); font-weight:bold; box-shadow:0 2px 0 var(--c-outline); }
.gold-coin { display:inline-block; width:24px; height:24px; background:radial-gradient(circle,#f0c34b 30%,#b88e28 70%); border-radius:50%; border:2px solid #8c6f1a; position:relative; }
.gold-coin::after { content:'₲'; position:absolute; inset:0; display:flex; align-items:center; justify-content:center; font-weight:bold; color:#5a4410; font-size:14px; }

.trade-card { background:var(--c-white); border:2px solid var(--c-stone-dk); border-radius:8px; padding:16px; margin-bottom:12px; }
.trade-card h3 { color:var(--c-wood-dk); margin-bottom:8px; }
.npc-grid { display:grid; grid-template-columns:120px 1fr 1fr 1fr; gap:8px; padding:8px 0; border-bottom:1px solid var(--c-stone); align-items:center; }
.npc-grid.header { font-weight:bold; background:var(--c-stone); padding:8px; border-radius:4px 4px 0 0; border-bottom:2px solid var(--c-stone-dk); }
.npc-grid.diff-neg { color:#8e2a26; }
.npc-grid.diff-pos { color:#4a7a3a; }

.offer-card { background:var(--c-paper); border:2px solid var(--c-stone-dk); border-radius:6px; padding:12px; margin-bottom:8px; display:flex; gap:12px; align-items:center; }
.offer-arrow { font-size:24px; color:var(--c-wood-dk); }
</style>

<div class="card">
    <div class="card-header">
        🏪 Marketplace (Level <?= $market_level ?>)
        <div style="float:right;display:flex;align-items:center;gap:8px;">
            <div class="gold-display">
                <span class="gold-coin"></span>
                <span><?= (int)$player['gold'] ?> gold</span>
            </div>
        </div>
    </div>

    <?php if ($market_level < 1): ?>
    <div class="alert alert-info">
        You need to build a <strong>Marketplace</strong> before you can trade.
        Visit your <a href="<?= url('/village.php') ?>">village</a> and build one in an empty slot.
    </div>
    <?php else: ?>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success"><?= e($success) ?></div>
    <?php endif; ?>

    <!-- Tab bar -->
    <div class="tab-bar">
        <a href="<?= url('/marketplace.php') ?>?tab=send" class="<?= $tab === 'send' ? 'active' : '' ?>">📦 Send Resources</a>
        <a href="<?= url('/marketplace.php') ?>?tab=npc" class="<?= $tab === 'npc' ? 'active' : '' ?>">🔄 NPC Trade (Gold)</a>
        <a href="<?= url('/marketplace.php') ?>?tab=offers" class="<?= $tab === 'offers' ? 'active' : '' ?>">📋 Offers (<?= count($active_offers) ?>)</a>
        <a href="<?= url('/marketplace.php') ?>?tab=create" class="<?= $tab === 'create' ? 'active' : '' ?>">➕ Create Offer</a>
    </div>

    <?php if ($tab === 'send'): ?>
    <!-- SEND: Send resources to another player -->
    <div style="font-size:11px;color:var(--c-text-soft);padding:8px;background:#e0e5ff;border-left:4px solid #324d80;margin-bottom:12px;">
        📦 <strong>Player-to-Player:</strong> Send resources to other players using your merchants. Travel time depends on distance.
    </div>

    <div class="trade-card">
        <h3>📦 Send Resources</h3>
        <p style="font-size:12px;color:var(--c-text-soft);margin-bottom:12px;">
            Merchants: <strong><?= $merchants_free ?>/<?= $merchants_have ?></strong> free |
            Capacity: <strong><?= format_number($merchant_capacity) ?></strong> resources per trip |
            Travel speed: 12 fields/hour
        </p>

        <?php if (empty($other_villages)): ?>
        <div class="alert alert-info">No other villages available to send resources to.</div>
        <?php else: ?>
        <form method="POST">
            <input type="hidden" name="action" value="send">
            <div class="form-group">
                <label>Target Village</label>
                <select name="to_village_id" class="form-control">
                    <?php foreach ($other_villages as $v): ?>
                    <option value="<?= (int)$v['id'] ?>"><?= e($v['name']) ?> (<?= (int)$v['x'] ?>|<?= (int)$v['y'] ?>) — <?= e($v['username']) ?> (<?= ucfirst($v['tribe']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <table class="data" style="font-size:12px;">
                <thead>
                    <tr><th>Resource</th><th>You have</th><th>Send</th></tr>
                </thead>
                <tbody>
                <?php foreach (['wood','clay','iron','crop'] as $res): ?>
                <tr>
                    <td><span class="res-icon res-<?= $res ?>"></span> <?= ucfirst($res) ?></td>
                    <td><?= format_number($resources[$res]) ?></td>
                    <td><input type="number" name="<?= $res ?>" min="0" max="<?= (int)$resources[$res] ?>" value="0" style="width:90px;padding:4px;" class="form-control"></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <button type="submit" class="btn btn-blue" style="margin-top:12px;">📦 Send Resources</button>
        </form>
        <?php endif; ?>
    </div>

    <?php elseif ($tab === 'npc'): ?>
    <!-- NPC TRADE: Redistribute resources for gold -->
    <div style="font-size:11px;color:var(--c-text-soft);padding:8px;background:#fff8d6;border-left:4px solid #f0c34b;margin-bottom:12px;">
        🔄 <strong>NPC Merchant:</strong> Redistribute your warehouse resources any way you like. Cost: <strong><?= NPC_TRADE_GOLD_COST ?> gold</strong> per trade. Total stays the same.
    </div>

    <div class="trade-card">
        <h3>🔄 NPC Trade — Redistribute Resources</h3>
        <p style="font-size:12px;color:var(--c-text-soft);margin-bottom:12px;">
            With the NPC merchant you can distribute the resources in your warehouse as you desire.
            The first row shows the current stock. In the second row you can choose another distribution.
            The third row shows the difference between the old and new stock.
        </p>

        <?php
        $current_total = (int)($resources['wood'] + $resources['clay'] + $resources['iron'] + $resources['crop']);
        ?>
        <div class="npc-grid header">
            <div>Resource</div>
            <div>Current Stock</div>
            <div>New Distribution</div>
            <div>Difference</div>
        </div>

        <form method="POST" id="npc_form">
            <input type="hidden" name="action" value="npc_redistribute">

            <?php foreach (['wood','clay','iron','crop'] as $res): ?>
            <div class="npc-grid">
                <div><span class="res-icon res-<?= $res ?>"></span> <strong><?= ucfirst($res) ?></strong></div>
                <div id="cur_<?= $res ?>"><?= format_number($resources[$res]) ?></div>
                <div>
                    <input type="number" name="new_<?= $res ?>" id="new_<?= $res ?>" value="<?= (int)$resources[$res] ?>" min="0" max="<?= (int)$resources[$res . '_cap'] ?>" style="width:120px;padding:4px;" class="form-control" oninput="updateNpcDiff()">
                </div>
                <div id="diff_<?= $res ?>" style="font-weight:bold;">0</div>
            </div>
            <?php endforeach; ?>

            <div class="npc-grid" style="border-bottom:none;font-weight:bold;background:var(--c-paper);">
                <div>Sum</div>
                <div id="cur_sum"><?= format_number($current_total) ?></div>
                <div id="new_sum"><?= format_number($current_total) ?></div>
                <div id="diff_sum">0</div>
            </div>

            <div style="margin-top:12px;padding:12px;background:#fff8d6;border-left:4px solid #f0c34b;font-size:12px;">
                💰 Cost: <strong><?= NPC_TRADE_GOLD_COST ?> gold</strong> (you have <?= (int)$player['gold'] ?>)
            </div>

            <button type="submit" class="btn btn-gold btn-lg" style="margin-top:12px;width:100%;" id="npc_submit">
                🔄 Redistribute for <?= NPC_TRADE_GOLD_COST ?> gold
            </button>
        </form>
    </div>

    <script>
    const initialAmounts = {
        wood: <?= (int)$resources['wood'] ?>,
        clay: <?= (int)$resources['clay'] ?>,
        iron: <?= (int)$resources['iron'] ?>,
        crop: <?= (int)$resources['crop'] ?>,
    };

    function updateNpcDiff() {
        let newSum = 0;
        ['wood','clay','iron','crop'].forEach(r => {
            const cur = initialAmounts[r];
            let newVal = parseInt(document.getElementById('new_' + r).value) || 0;
            const diff = newVal - cur;
            const diffEl = document.getElementById('diff_' + r);
            diffEl.textContent = diff > 0 ? '+' + diff : diff;
            diffEl.style.color = diff > 0 ? '#4a7a3a' : (diff < 0 ? '#8e2a26' : '#5a4a30');
            newSum += newVal;
        });
        document.getElementById('new_sum').textContent = newSum.toLocaleString('en-US');
        const curSum = Object.values(initialAmounts).reduce((a,b) => a+b, 0);
        const totalDiff = newSum - curSum;
        const diffSumEl = document.getElementById('diff_sum');
        diffSumEl.textContent = totalDiff > 0 ? '+' + totalDiff : totalDiff;
        diffSumEl.style.color = totalDiff !== 0 ? '#8e2a26' : '#4a7a3a';

        // Disable submit if totals don't match
        const submitBtn = document.getElementById('npc_submit');
        submitBtn.disabled = (totalDiff !== 0);
        if (totalDiff !== 0) {
            submitBtn.textContent = '⚠️ Totals must match (diff: ' + totalDiff + ')';
        } else {
            submitBtn.textContent = '🔄 Redistribute for <?= NPC_TRADE_GOLD_COST ?> gold';
        }
    }
    updateNpcDiff();
    </script>

    <?php elseif ($tab === 'offers'): ?>
    <!-- OFFERS: Browse and accept other players' offers + view own -->
    <div style="font-size:11px;color:var(--c-text-soft);padding:8px;background:#e0ffe0;border-left:4px solid #4a7a3a;margin-bottom:12px;">
        📋 <strong>Trade Offers:</strong> Browse offers from other players. If no offers exist, no trades can be made. Create your own offer to attract traders.
    </div>

    <!-- Other players' offers -->
    <div class="trade-card">
        <h3>📋 Offers at the Marketplace</h3>
        <?php if (empty($active_offers)): ?>
        <div style="text-align:center;padding:24px;color:var(--c-text-soft);">
            <em>No offers at the marketplace.</em><br><br>
            <a href="<?= url('/marketplace.php') ?>?tab=create" class="btn btn-green btn-sm">➕ Create the first offer</a>
        </div>
        <?php else: ?>
        <table class="data">
            <thead>
                <tr>
                    <th>Offered</th>
                    <th></th>
                    <th>Wanted</th>
                    <th>Rate</th>
                    <th>Player</th>
                    <th>Expires</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($active_offers as $o): 
                $rate = $o['offer_amount'] > 0 ? round($o['want_amount'] / $o['offer_amount'], 2) : 0;
                $expires_in = strtotime($o['expires_at']) - time();
                $expires_text = $expires_in > 3600 ? round($expires_in/3600) . 'h' : round($expires_in/60) . 'm';
            ?>
            <tr>
                <td>
                    <span class="res-icon res-<?= $o['offer_resource'] ?>"></span>
                    <strong><?= format_number($o['offer_amount']) ?></strong> <?= ucfirst($o['offer_resource']) ?>
                </td>
                <td style="font-size:18px;color:var(--c-wood-dk);">→</td>
                <td>
                    <span class="res-icon res-<?= $o['want_resource'] ?>"></span>
                    <strong><?= format_number($o['want_amount']) ?></strong> <?= ucfirst($o['want_resource']) ?>
                </td>
                <td style="font-size:11px;">1 <?= $o['offer_resource'] ?> = <?= $rate ?> <?= $o['want_resource'] ?></td>
                <td>
                    <img src="<?= img_url("tribes/{$o['tribe']}.png") ?>" width="16" height="16" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e($o['username']) ?>
                </td>
                <td style="font-size:11px;"><?= $expires_text ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="accept_offer">
                        <input type="hidden" name="offer_id" value="<?= (int)$o['id'] ?>">
                        <button type="submit" class="btn btn-green btn-sm">✅ Accept</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <!-- My offers -->
    <div class="trade-card">
        <h3>📝 My Offers</h3>
        <?php if (empty($my_offers)): ?>
        <p style="color:var(--c-text-soft);text-align:center;padding:12px;">You haven't created any offers yet.</p>
        <?php else: ?>
        <table class="data">
            <thead>
                <tr>
                    <th>Offering</th>
                    <th></th>
                    <th>Want</th>
                    <th>Status</th>
                    <th>Village</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($my_offers as $o): ?>
            <tr>
                <td>
                    <span class="res-icon res-<?= $o['offer_resource'] ?>"></span>
                    <strong><?= format_number($o['offer_amount']) ?></strong> <?= ucfirst($o['offer_resource']) ?>
                </td>
                <td style="font-size:18px;">→</td>
                <td>
                    <span class="res-icon res-<?= $o['want_resource'] ?>"></span>
                    <strong><?= format_number($o['want_amount']) ?></strong> <?= ucfirst($o['want_resource']) ?>
                </td>
                <td>
                    <?php
                    $status_colors = ['active' => '#4a7a3a', 'accepted' => '#324d80', 'cancelled' => '#8e2a26', 'expired' => '#8e2a26'];
                    $color = $status_colors[$o['status']] ?? '#5a4a30';
                    ?>
                    <span style="color:<?= $color ?>;font-weight:bold;text-transform:uppercase;font-size:11px;"><?= $o['status'] ?></span>
                </td>
                <td style="font-size:11px;"><?= e($o['village_name']) ?></td>
                <td style="font-size:11px;"><?= substr($o['created_at'], 0, 16) ?></td>
                <td>
                    <?php if ($o['status'] === 'active'): ?>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="cancel_offer">
                        <input type="hidden" name="offer_id" value="<?= (int)$o['id'] ?>">
                        <button type="submit" class="btn btn-red btn-sm" onclick="return confirm('Cancel this offer? Resources will be returned.')">❌ Cancel</button>
                    </form>
                    <?php else: ?>
                    <em style="color:var(--c-text-soft);font-size:11px;">—</em>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
        <p style="margin-top:12px;text-align:center;">
            <a href="<?= url('/marketplace.php') ?>?tab=create" class="btn btn-green btn-sm">➕ Create New Offer</a>
        </p>
    </div>

    <?php elseif ($tab === 'create'): ?>
    <!-- CREATE OFFER -->
    <div style="font-size:11px;color:var(--c-text-soft);padding:8px;background:#e0ffe0;border-left:4px solid #4a7a3a;margin-bottom:12px;">
        ➕ <strong>Create Trade Offer:</strong> Offer resources you have for resources you want. Other players can accept your offer via the Offers tab.
    </div>

    <div class="trade-card">
        <h3>➕ Create New Trade Offer</h3>
        <form method="POST">
            <input type="hidden" name="action" value="create_offer">

            <table class="data" style="margin-bottom:12px;">
                <thead>
                    <tr>
                        <th></th>
                        <th>Amount</th>
                        <th>Resource</th>
                    </tr>
                </thead>
                <tbody>
                <tr>
                    <td><strong style="color:var(--c-wood-dk);">Offering:</strong></td>
                    <td><input type="number" name="offer_amount" min="1" value="1000" style="width:120px;padding:4px;" class="form-control" required></td>
                    <td>
                        <select name="offer_resource" class="form-control">
                            <?php foreach (['wood','clay','iron','crop'] as $r): ?>
                            <option value="<?= $r ?>"><?= ucfirst($r) ?> (have: <?= format_number($resources[$r]) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><strong style="color:var(--c-wood-dk);">Searching:</strong></td>
                    <td><input type="number" name="want_amount" min="1" value="1000" style="width:120px;padding:4px;" class="form-control" required></td>
                    <td>
                        <select name="want_resource" class="form-control">
                            <?php foreach (['wood','clay','iron','crop'] as $r): ?>
                            <option value="<?= $r ?>"><?= ucfirst($r) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                </tbody>
            </table>

            <div class="form-group">
                <label>Max transport time (hours):</label>
                <input type="number" name="max_transport_hours" min="1" max="48" value="24" style="width:80px;padding:4px;" class="form-control">
                <small style="color:var(--c-text-soft);">Players further away than this won't be able to accept your offer.</small>
            </div>

            <div style="margin-top:12px;padding:8px;background:#fff8d6;border-left:4px solid #f0c34b;font-size:12px;">
                ⚠️ <strong>Note:</strong> Offered resources are held in escrow until someone accepts your offer or you cancel it (resources returned).
            </div>

            <button type="submit" class="btn btn-green btn-lg" style="margin-top:12px;width:100%;">➕ Create Offer</button>
        </form>
    </div>

    <?php endif; ?>

    <?php endif; ?>
</div>

<p style="text-align:center;margin:16px 0;">
    <a href="<?= url('/village.php') ?>">← Back to Village</a>
</p>

<?php require __DIR__ . '/app/views/footer.php'; ?>
