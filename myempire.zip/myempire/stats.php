<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

// Fetch server-wide stats for the summary panel at the top
$server_stats = get_server_stats();

// Players ranking (by population) — also include last_activity for the online badge
$players = db()->fetchAll(
    "SELECT p.id, p.username, p.tribe, p.population, p.created_at, p.last_activity,
            COUNT(v.id) AS village_count
     FROM players p
     LEFT JOIN villages v ON v.player_id = p.id
     GROUP BY p.id
     ORDER BY p.population DESC, p.created_at ASC
     LIMIT 100"
);

// Online cutoff (matches the threshold in get_server_stats)
$online_cutoff = date('Y-m-d H:i:s', time() - ONLINE_THRESHOLD_SECONDS);
$today_cutoff  = date('Y-m-d H:i:s', time() - ACTIVE_TODAY_THRESHOLD_HOURS * 3600);

// Get loot multiplier per tribe for display
$loot_pct = [
    'teuton' => 100,
    'roman'  => 80,
    'gaul'   => 70,
];

$page_title = 'Ranks';
require __DIR__ . '/app/views/header.php';
?>

<!-- ============================================================
     Server Statistics Summary Panel
     ============================================================ -->
<div class="card" style="margin-bottom:16px;">
    <div class="card-header">📊 Server Statistics</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;">
        <div style="background:#fff8d6;border:2px solid var(--c-outline);border-radius:6px;padding:10px;text-align:center;">
            <div style="font-family:Georgia,serif;font-size:24px;font-weight:bold;color:var(--c-wood-dk);"><?= number_format($server_stats['total_players']) ?></div>
            <div style="font-size:10px;color:var(--c-text-soft);text-transform:uppercase;letter-spacing:1px;">Registered</div>
        </div>
        <div style="background:#e6f4e0;border:2px solid #4a7a3a;border-radius:6px;padding:10px;text-align:center;">
            <div style="font-family:Georgia,serif;font-size:24px;font-weight:bold;color:#2a5a2a;">
                <span style="display:inline-block;width:8px;height:8px;background:#4a7a3a;border-radius:50%;box-shadow:0 0 6px #4a7a3a;animation:blink 1.6s infinite;margin-right:4px;"></span>
                <?= number_format($server_stats['online_now']) ?>
            </div>
            <div style="font-size:10px;color:#2a5a2a;text-transform:uppercase;letter-spacing:1px;">Online Now</div>
        </div>
        <div style="background:#fff8d6;border:2px solid var(--c-outline);border-radius:6px;padding:10px;text-align:center;">
            <div style="font-family:Georgia,serif;font-size:24px;font-weight:bold;color:var(--c-wood-dk);"><?= number_format($server_stats['active_today']) ?></div>
            <div style="font-size:10px;color:var(--c-text-soft);text-transform:uppercase;letter-spacing:1px;">Active Today</div>
        </div>
        <div style="background:#fff8d6;border:2px solid var(--c-outline);border-radius:6px;padding:10px;text-align:center;">
            <div style="font-family:Georgia,serif;font-size:24px;font-weight:bold;color:var(--c-wood-dk);"><?= number_format($server_stats['total_villages']) ?></div>
            <div style="font-size:10px;color:var(--c-text-soft);text-transform:uppercase;letter-spacing:1px;">Villages</div>
        </div>
        <div style="background:#fff8d6;border:2px solid var(--c-outline);border-radius:6px;padding:10px;text-align:center;">
            <div style="font-family:Georgia,serif;font-size:24px;font-weight:bold;color:var(--c-wood-dk);"><?= number_format($server_stats['total_troops']) ?></div>
            <div style="font-size:10px;color:var(--c-text-soft);text-transform:uppercase;letter-spacing:1px;">Troops Raised</div>
        </div>
    </div>

    <!-- Tribe breakdown mini-bar -->
    <div style="margin-top:12px;display:flex;gap:14px;font-size:11px;align-items:center;flex-wrap:wrap;">
        <span style="color:var(--c-text-soft);text-transform:uppercase;letter-spacing:1px;font-size:10px;">Tribes:</span>
        <span><img src="<?= img_url('tribes/roman.png') ?>" width="14" height="14" alt="" style="vertical-align:middle;"> Romans: <?= $server_stats['tribe_counts']['roman'] ?></span>
        <span><img src="<?= img_url('tribes/gaul.png') ?>" width="14" height="14" alt="" style="vertical-align:middle;"> Gauls: <?= $server_stats['tribe_counts']['gaul'] ?></span>
        <span><img src="<?= img_url('tribes/teuton.png') ?>" width="14" height="14" alt="" style="vertical-align:middle;"> Teutons: <?= $server_stats['tribe_counts']['teuton'] ?></span>
    </div>
</div>

<style>
@keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
}
.online-badge {
    display: inline-block;
    width: 8px;
    height: 8px;
    background: #4a7a3a;
    border-radius: 50%;
    box-shadow: 0 0 4px #4a7a3a;
    animation: blink 1.6s infinite;
    margin-right: 4px;
    vertical-align: middle;
}
.today-badge {
    display: inline-block;
    width: 8px;
    height: 8px;
    background: #f0c34b;
    border-radius: 50%;
    margin-right: 4px;
    vertical-align: middle;
}
</style>

<div class="card">
    <div class="card-header">Player Rankings</div>
    <p style="font-size:12px;color:var(--c-text-soft);margin-bottom:12px;">
        <span class="online-badge"></span> = online now (active within 5 min) ·
        <span class="today-badge"></span> = active today ·
        Click a player name to view their profile — attack them or send resources.
    </p>
    <table class="data">
        <thead>
            <tr>
                <th>Rank</th>
                <th>Status</th>
                <th>Player</th>
                <th>Tribe</th>
                <th>Loot</th>
                <th>Population</th>
                <th>Villages</th>
                <th>Last Seen</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($players as $i => $p):
            $is_online = !empty($p['last_activity']) && $p['last_activity'] >= $online_cutoff;
            $is_today  = !empty($p['last_activity']) && $p['last_activity'] >= $today_cutoff;
        ?>
        <tr <?= $is_online ? 'style="background:rgba(74,122,58,0.08);"' : '' ?>>
            <td><?= $i + 1 ?></td>
            <td style="text-align:center;">
                <?php if ($is_online): ?>
                    <span class="online-badge" title="Online now"></span>
                <?php elseif ($is_today): ?>
                    <span class="today-badge" title="Active today"></span>
                <?php else: ?>
                    <span style="display:inline-block;width:8px;height:8px;background:#888;border-radius:50%;margin-right:4px;vertical-align:middle;" title="Inactive"></span>
                <?php endif; ?>
            </td>
            <td>
                <a href="<?= url('/player.php') . '?id=' . (int)$p['id'] ?>" style="font-weight:bold;">
                    <img src="<?= img_url("tribes/{$p['tribe']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e($p['username']) ?>
                </a>
            </td>
            <td><?= e(ucfirst($p['tribe'])) ?></td>
            <td><?= $loot_pct[$p['tribe']] ?? 70 ?>%</td>
            <td><?= (int)$p['population'] ?></td>
            <td><?= (int)$p['village_count'] ?></td>
            <td style="font-size:11px;color:var(--c-text-soft);">
                <?= $p['last_activity'] ? e(time_ago($p['last_activity'])) : '<em>never</em>' ?>
            </td>
            <td>
                <a href="<?= url('/player.php') . '?id=' . (int)$p['id'] ?>" class="btn btn-sm btn-blue">View</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($players)): ?>
        <tr><td colspan="9" style="text-align:center;color:var(--c-text-soft);">No players yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
