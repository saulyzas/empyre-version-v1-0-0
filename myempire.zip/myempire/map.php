<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
$cx = (int)($_GET['x'] ?? $village['x']);
$cy = (int)($_GET['y'] ?? $village['y']);

// 7x7 grid around the center (with axis labels = 15x15 visual area but we use 13+2 for labels)
// Use a 13x13 visible area centered on (cx, cy)
$half = 6;
$x_min = $cx - $half;
$x_max = $cx + $half;
$y_min = $cy - $half;
$y_max = $cy + $half;

// Fetch villages in range from DB
$villages_in_range = db()->fetchAll(
    "SELECT v.id, v.name, v.x, v.y, v.player_id, p.username, p.tribe
     FROM villages v JOIN players p ON p.id = v.player_id
     WHERE v.x BETWEEN ? AND ? AND v.y BETWEEN ? AND ?",
    [$x_min, $x_max, $y_min, $y_max]
);
$vil_lookup = [];
foreach ($villages_in_range as $v) {
    $vil_lookup[$v['x'] . ',' . $v['y']] = $v;
}

$page_title = 'World Map';
require __DIR__ . '/app/views/header.php';
?>

<div class="card">
    <div class="card-header">
        Map <span style="color:var(--c-text-soft);">(<?= $cx ?>|<?= $cy ?>)</span>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <div style="display:flex;gap:4px;">
            <a href="<?= url('/map.php') . '?x=' . $cx . '&y=' . ($cy + 7) ?>" class="btn btn-sm">↑ N</a>
            <a href="<?= url('/map.php') . '?x=' . ($cx - 7) . '&y=' . $cy ?>" class="btn btn-sm">← W</a>
            <a href="<?= url('/map.php') . '?x=' . $cx . '&y=' . ($cy - 7) ?>" class="btn btn-sm">↓ S</a>
            <a href="<?= url('/map.php') . '?x=' . ($cx + 7) . '&y=' . $cy ?>" class="btn btn-sm">→ E</a>
            <a href="<?= url('/map.php') . '?x=' . $village['x'] . '&y=' . $village['y'] ?>" class="btn btn-sm btn-gold">⌂ Center</a>
        </div>
    </div>

    <div class="map-container">
        <div class="map-grid">
            <!-- Top-left corner -->
            <div class="map-cell map-axis-corner"></div>
            <!-- X axis labels -->
            <?php for ($x = $x_min; $x <= $x_max; $x++): ?>
            <div class="map-label"><?= $x ?></div>
            <?php endfor; ?>

            <?php for ($y = $y_max; $y >= $y_min; $y--): ?>
            <!-- Y axis label -->
            <div class="map-label"><?= $y ?></div>
            <?php for ($x = $x_min; $x <= $x_max; $x++):
                $terrain = terrain_for_cell($x, $y);
                $v = $vil_lookup[$x . ',' . $y] ?? null;
                $is_current = ($x == $village['x'] && $y == $village['y']);
                if ($v) {
                    $img = 'map/village.png';
                    $title = $v['name'] . ' (' . $v['username'] . ') — click for details';
                } else {
                    $img = "map/{$terrain}.png";
                    $title = "$x|$y (" . ucfirst($terrain) . ") — click to inspect";
                }
                // ALL cells link to cell.php with from_x/from_y preserving the current view
                $cell_url = url('/cell.php') . '?x=' . $x . '&y=' . $y . '&from_x=' . $cx . '&from_y=' . $cy;
            ?>
            <a href="<?= $cell_url ?>" class="map-cell <?= $is_current ? 'current' : '' ?>" title="<?= e($title) ?>">
                <img src="<?= img_url($img) ?>" alt="<?= e($terrain) ?>">
                <?php if ($is_current): ?>
                <span style="position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(240,195,75,0.4);pointer-events:none;"></span>
                <?php elseif ($v && $v['player_id'] != $village['player_id']): ?>
                <span style="position:absolute;top:1px;right:1px;width:6px;height:6px;background:var(--c-red);border-radius:50%;border:1px solid var(--c-outline);pointer-events:none;" title="Enemy village"></span>
                <?php elseif ($v && $v['player_id'] == $village['player_id']): ?>
                <span style="position:absolute;top:1px;right:1px;width:6px;height:6px;background:#4a7a3a;border-radius:50%;border:1px solid var(--c-outline);pointer-events:none;" title="Your village"></span>
                <?php endif; ?>
            </a>
            <?php endfor; ?>
            <?php endfor; ?>
        </div>
    </div>

    <!-- Village list in view -->
    <?php if (!empty($villages_in_range)): ?>
    <div class="card" style="margin-top:16px;">
        <div class="card-header">Villages in this area</div>
        <table class="data">
            <thead>
                <tr><th>Coordinates</th><th>Village</th><th>Player</th><th>Tribe</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php foreach ($villages_in_range as $v): ?>
            <tr>
                <td><a href="<?= url('/cell.php') . '?x=' . (int)$v['x'] . '&y=' . (int)$v['y'] . '&from_x=' . $cx . '&from_y=' . $cy ?>"><?= (int)$v['x'] ?>|<?= (int)$v['y'] ?></a></td>
                <td>
                    <a href="<?= url('/cell.php') . '?x=' . (int)$v['x'] . '&y=' . (int)$v['y'] . '&from_x=' . $cx . '&from_y=' . $cy ?>"><?= e($v['name']) ?></a>
                </td>
                <td><a href="<?= url('/player.php') . '?id=' . (int)$v['player_id'] ?>"><?= e($v['username']) ?></a></td>
                <td>
                    <img src="<?= img_url("tribes/{$v['tribe']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e(ucfirst($v['tribe'])) ?>
                </td>
                <td>
                    <a href="<?= url('/cell.php') . '?x=' . (int)$v['x'] . '&y=' . (int)$v['y'] . '&from_x=' . $cx . '&from_y=' . $cy ?>" class="btn btn-blue btn-sm">👁 Inspect</a>
                    <a href="<?= url('/attack.php') . '?x=' . (int)$v['x'] . '&y=' . (int)$v['y'] ?>" class="btn btn-red btn-sm">⚔ Attack</a>
                    <a href="<?= url('/player.php') . '?id=' . (int)$v['player_id'] ?>" class="btn btn-sm">Profile</a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <div style="margin-top:12px;display:flex;gap:16px;font-size:12px;flex-wrap:wrap;">
        <span><img src="<?= img_url('map/grass.png') ?>" width="20" height="20" alt="" style="vertical-align:middle;"> Grassland</span>
        <span><img src="<?= img_url('map/forest.png') ?>" width="20" height="20" alt="" style="vertical-align:middle;"> Forest</span>
        <span><img src="<?= img_url('map/mountain.png') ?>" width="20" height="20" alt="" style="vertical-align:middle;"> Mountain</span>
        <span><img src="<?= img_url('map/desert.png') ?>" width="20" height="20" alt="" style="vertical-align:middle;"> Desert</span>
        <span><img src="<?= img_url('map/water.png') ?>" width="20" height="20" alt="" style="vertical-align:middle;"> Water</span>
        <span><img src="<?= img_url('map/village.png') ?>" width="20" height="20" alt="" style="vertical-align:middle;"> Village</span>
    </div>

    <div style="margin-top:8px;display:flex;gap:16px;font-size:11px;flex-wrap:wrap;color:var(--c-text-soft);">
        <span><span style="display:inline-block;width:8px;height:8px;background:#4a7a3a;border-radius:50%;border:1px solid var(--c-outline);vertical-align:middle;margin-right:3px;"></span> Your village</span>
        <span><span style="display:inline-block;width:8px;height:8px;background:var(--c-red);border-radius:50%;border:1px solid var(--c-outline);vertical-align:middle;margin-right:3px;"></span> Enemy village</span>
        <span><span style="display:inline-block;width:8px;height:8px;background:rgba(240,195,75,0.6);border:1px solid var(--c-outline);vertical-align:middle;margin-right:3px;"></span> Your current location</span>
        <span style="margin-left:auto;">💡 Click any cell to inspect terrain, villages, players, and distance.</span>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
