<?php
/**
 * faq.php — Frequently Asked Questions
 *
 * A standalone help page organised into thematic sections:
 *   1. Getting Started
 *   2. Resources & Fields
 *   3. Buildings
 *   4. Troops & Combat
 *   5. Academy & Research
 *   6. Marketplace & Trade
 *   7. Map & Villages
 *   8. Hero
 *   9. Account & Server
 *
 * The page is reachable from:
 *   - The header nav bar (visible to logged-in players)
 *   - The landing page (visible to guests considering registration)
 *
 * The page itself is fully public — no login required — so prospective
 * players can read the FAQ before signing up.
 */
require_once __DIR__ . '/app/lib/helpers.php';
init_session();

// FAQ is public — no require_login() call here.

// Fetch server stats so we can show "Server speed: 5x" etc. in the answers
$server_speed = (int)GAME_SERVER_SPEED;
$start_res    = (int)STARTING_RESOURCES;
$max_field    = (int)MAX_RESOURCE_LEVEL;
$max_building = (int)MAX_BUILDING_LEVEL;
$queue_size   = (int)BUILD_QUEUE_SIZE;
$npc_cost     = (int)NPC_TRADE_GOLD_COST;

// Helper: tribe loot multipliers
$tribe_loot = [
    'teuton' => 100,
    'roman'  => 80,
    'gaul'   => 70,
];

$page_title = 'FAQ';
require __DIR__ . '/app/views/header.php';
?>

<style>
.faq-section {
    margin-bottom: 24px;
}
.faq-section h2 {
    color: var(--c-wood-dk);
    font-family: Georgia, serif;
    border-bottom: 3px solid var(--c-gold-dk);
    padding-bottom: 6px;
    margin-bottom: 12px;
    font-size: 22px;
}
.faq-item {
    background: #fff8d6;
    border: 2px solid var(--c-outline);
    border-radius: 6px;
    margin-bottom: 10px;
    overflow: hidden;
    box-shadow: 0 2px 0 var(--c-outline);
}
.faq-item summary {
    padding: 10px 14px;
    cursor: pointer;
    font-weight: bold;
    color: var(--c-wood-dk);
    font-size: 14px;
    list-style: none;
    position: relative;
    padding-left: 36px;
    user-select: none;
}
.faq-item summary::-webkit-details-marker { display: none; }
.faq-item summary::before {
    content: '➤';
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--c-gold-dk);
    transition: transform 0.2s;
    font-size: 14px;
}
.faq-item[open] summary::before {
    transform: translateY(-50%) rotate(90deg);
}
.faq-item summary:hover {
    background: rgba(240, 195, 75, 0.2);
}
.faq-answer {
    padding: 0 14px 12px 36px;
    font-size: 13px;
    line-height: 1.6;
    color: var(--c-text);
}
.faq-answer p { margin: 6px 0; }
.faq-answer ul { margin: 6px 0 6px 18px; padding: 0; }
.faq-answer li { margin-bottom: 4px; }
.faq-answer code {
    background: var(--c-panel, #f4ead5);
    padding: 1px 5px;
    border-radius: 3px;
    font-family: 'Courier New', monospace;
    font-size: 12px;
    color: var(--c-wood-dk);
    border: 1px solid var(--c-outline);
}
.faq-answer .tip {
    background: #e6f4e0;
    border-left: 4px solid #4a7a3a;
    padding: 8px 12px;
    margin: 8px 0;
    border-radius: 4px;
    font-size: 12px;
}
.faq-answer .warn {
    background: #fce4e4;
    border-left: 4px solid #8e2a26;
    padding: 8px 12px;
    margin: 8px 0;
    border-radius: 4px;
    font-size: 12px;
}
.faq-toc {
    background: #fff8d6;
    border: 2px solid var(--c-gold-dk);
    border-radius: 8px;
    padding: 14px 18px;
    margin-bottom: 20px;
}
.faq-toc h3 {
    margin: 0 0 8px;
    font-size: 14px;
    color: var(--c-wood-dk);
    text-transform: uppercase;
    letter-spacing: 1px;
}
.faq-toc ol {
    margin: 0;
    padding-left: 22px;
    columns: 2;
    column-gap: 20px;
    font-size: 13px;
}
.faq-toc ol li { margin-bottom: 4px; }
.faq-toc a { color: var(--c-wood-dk); text-decoration: none; }
.faq-toc a:hover { text-decoration: underline; }
</style>

<div class="card" style="max-width:900px;margin:0 auto;">
    <div class="card-header" style="text-align:center;">
        ❓ Frequently Asked Questions
    </div>
    <p style="text-align:center;font-size:13px;color:var(--c-text-soft);margin-bottom:16px;">
        Everything you need to know about <?= e(GAME_NAME) ?>. Click any question to expand the answer.
    </p>

    <!-- Table of contents -->
    <div class="faq-toc">
        <h3>📑 Sections</h3>
        <ol>
            <li><a href="#getting-started">Getting Started</a></li>
            <li><a href="#resources">Resources &amp; Fields</a></li>
            <li><a href="#buildings">Buildings</a></li>
            <li><a href="#troops">Troops &amp; Combat</a></li>
            <li><a href="#academy">Academy &amp; Research</a></li>
            <li><a href="#marketplace">Marketplace &amp; Trade</a></li>
            <li><a href="#map">Map &amp; Villages</a></li>
            <li><a href="#hero">Hero</a></li>
            <li><a href="#server">Account &amp; Server</a></li>
        </ol>
    </div>

    <!-- ============================================================
         1. GETTING STARTED
         ============================================================ -->
    <div class="faq-section" id="getting-started">
        <h2>1. 🌱 Getting Started</h2>

        <details class="faq-item" open>
            <summary>How do I start playing?</summary>
            <div class="faq-answer">
                <p>Simple three-step process:</p>
                <ul>
                    <li>Click <strong>Register</strong> on the landing page.</li>
                    <li>Pick a tribe (Romans, Gauls, or Teutons) and a starting quadrant (NE / NW / SE / SW).</li>
                    <li>Confirm — you'll be dropped into your new village with <?= number_format($start_res) ?> of each resource (wood, clay, iron, crop) and a Level 1 Main Building.</li>
                </ul>
                <div class="tip">💡 <strong>Tip:</strong> The tribe you pick is permanent for your account — choose based on your preferred play-style (see below).</div>
            </div>
        </details>

        <details class="faq-item">
            <summary>Which tribe should I pick?</summary>
            <div class="faq-answer">
                <p>Each tribe has different strengths:</p>
                <ul>
                    <li><strong>Romans</strong> — balanced attackers and defenders. Best for beginners. Loot multiplier: <?= $tribe_loot['roman'] ?>%.</li>
                    <li><strong>Gauls</strong> — fast cavalry and strong defense. Excellent merchants. Loot multiplier: <?= $tribe_loot['gaul'] ?>%.</li>
                    <li><strong>Teutons</strong> — aggressive raiders. Cheap infantry, strong early game. Best loot multiplier: <?= $tribe_loot['teuton'] ?>%.</li>
                </ul>
                <div class="tip">💡 If you're brand new, pick <strong>Romans</strong>. If you want to raid aggressively from day 1, pick <strong>Teutons</strong>.</div>
            </div>
        </details>

        <details class="faq-item">
            <summary>What are the quadrants for?</summary>
            <div class="faq-answer">
                <p>The world map is divided into four quadrants:</p>
                <ul>
                    <li><strong>NorthEast</strong> (positive X, positive Y)</li>
                    <li><strong>NorthWest</strong> (negative X, positive Y)</li>
                    <li><strong>SouthEast</strong> (positive X, negative Y)</li>
                    <li><strong>SouthWest</strong> (negative X, negative Y)</li>
                </ul>
                <p>Your starting quadrant determines where your first village is placed on the map. You can still see and interact with players in other quadrants — they're just further away (longer travel times).</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What should I do first?</summary>
            <div class="faq-answer">
                <p>Recommended first-hour checklist:</p>
                <ul>
                    <li>Open the <strong>Fields</strong> page and upgrade your <code>cropland</code> fields first (you need crop to feed your population).</li>
                    <li>Then upgrade <code>woodcutter</code>, <code>claypit</code>, and <code>ironmine</code> to roughly level 2-3.</li>
                    <li>Open the <strong>Village</strong> page and click an empty slot to build a <strong>Warehouse</strong> (so resources don't get wasted).</li>
                    <li>Build a <strong>Granary</strong> next (to store more crop).</li>
                    <li>Once your Main Building is Level 3, build a <strong>Barracks</strong> to start training basic infantry.</li>
                </ul>
                <div class="warn">⚠️ Don't build troops before you have enough crop production — they eat 1 crop per hour each!</div>
            </div>
        </details>
    </div>

    <!-- ============================================================
         2. RESOURCES & FIELDS
         ============================================================ -->
    <div class="faq-section" id="resources">
        <h2>2. 🌾 Resources &amp; Fields</h2>

        <details class="faq-item">
            <summary>What are the four resources for?</summary>
            <div class="faq-answer">
                <ul>
                    <li><strong>Wood</strong> 🌲 — used in nearly every building and infantry unit.</li>
                    <li><strong>Clay</strong> 🟫 — used heavily for warehouses, granaries, and marketplace.</li>
                    <li><strong>Iron</strong> ⛏️ — used for weapons, smithy, barracks, advanced units.</li>
                    <li><strong>Crop</strong> 🌾 — used to feed your population and troops. <em>Crop is consumed automatically</em> — if you run out, your troops will start starving!</li>
                </ul>
            </div>
        </details>

        <details class="faq-item">
            <summary>How does resource production work?</summary>
            <div class="faq-answer">
                <p>Each village has <strong>18 resource fields</strong> arranged around the village center:</p>
                <ul>
                    <li>4 × Woodcutter</li>
                    <li>4 × Clay Pit</li>
                    <li>4 × Iron Mine</li>
                    <li>6 × Cropland</li>
                </ul>
                <p>Each field produces resources per hour based on its level (Level 0 = 5/hour, Level 10 = 700/hour). The total is multiplied by the <strong>server speed</strong> (currently <code><?= $server_speed ?>x</code>).</p>
                <p>Resources accumulate in real time, even when you're offline — they're capped by your Warehouse (wood/clay/iron) and Granary (crop) capacity.</p>
                <div class="tip">💡 Upgrade your <strong>Main Building</strong> to reduce build time for everything else. Higher Main Building = faster village development.</div>
            </div>
        </details>

        <details class="faq-item">
            <summary>What's the max level for resource fields?</summary>
            <div class="faq-answer">
                <p>Resource fields max out at <strong>Level <?= $max_field ?></strong>. At max level with <?= $server_speed ?>x server speed, a single field produces <strong><?= number_format(700 * $server_speed) ?>/hour</strong>.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>My crop production is negative! What happens?</summary>
            <div class="faq-answer">
                <p>Crop is consumed by:</p>
                <ul>
                    <li>Each point of population (1 crop/hour per population)</li>
                    <li>Each troop stationed in the village (varies by unit)</li>
                </ul>
                <p>If your crop production goes negative, your stockpile will start draining. When it hits zero, your troops will start <strong>starving</strong> (they die one by one until production can sustain the rest).</p>
                <div class="warn">⚠️ Always keep crop production positive — build more <code>cropland</code> fields before training a big army.</div>
            </div>
        </details>
    </div>

    <!-- ============================================================
         3. BUILDINGS
         ============================================================ -->
    <div class="faq-section" id="buildings">
        <h2>3. 🏗️ Buildings</h2>

        <details class="faq-item">
            <summary>How many buildings can I have?</summary>
            <div class="faq-answer">
                <p>Each village has <strong>20 building slots</strong>. Slot 0 is always your Main Building (the village center). The remaining 19 slots can be filled with any of the 13 building types:</p>
                <ul>
                    <li><strong>Main Building</strong>, Warehouse, Granary, Barracks, Stable, Workshop, Marketplace, Embassy, Rally Point, Hero Mansion, Smithy, Academy, City Wall</li>
                </ul>
                <p>Some buildings are <strong>unique</strong> (only one per village): Barracks, Stable, Workshop, Marketplace, Embassy, Rally Point, Hero Mansion, Smithy, Academy, Wall, Main Building. Warehouse and Granary can be built multiple times for extra storage.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What does each building do?</summary>
            <div class="faq-answer">
                <ul>
                    <li><strong>Main Building</strong> — reduces build time for all other structures by 4% per level (max -50%).</li>
                    <li><strong>Warehouse</strong> — increases wood/clay/iron storage by 800 per level.</li>
                    <li><strong>Granary</strong> — increases crop storage by 800 per level.</li>
                    <li><strong>Barracks</strong> — train infantry (3% faster training per level).</li>
                    <li><strong>Stable</strong> — train cavalry.</li>
                    <li><strong>Workshop</strong> — build siege engines (coming soon).</li>
                    <li><strong>Marketplace</strong> — trade resources with other players. +1 merchant per level.</li>
                    <li><strong>Embassy</strong> — found or join alliances (coming soon).</li>
                    <li><strong>Rally Point</strong> — send and receive troop movements.</li>
                    <li><strong>Hero Mansion</strong> — recruit and manage your hero.</li>
                    <li><strong>Smithy</strong> — research unit upgrades (required to build the Academy).</li>
                    <li><strong>Academy</strong> — research advanced troop types before they can be trained.</li>
                    <li><strong>City Wall</strong> — boosts village defense significantly.</li>
                </ul>
            </div>
        </details>

        <details class="faq-item">
            <summary>Why is a building locked?</summary>
            <div class="faq-answer">
                <p>Buildings have <strong>prerequisites</strong>. For example:</p>
                <ul>
                    <li><strong>Barracks</strong> needs Main Building Level 3.</li>
                    <li><strong>Stable</strong> needs Main Building Level 3 + Barracks Level 1.</li>
                    <li><strong>Marketplace</strong> needs Main Building Level 3 + Warehouse Level 1 + Granary Level 1.</li>
                    <li><strong>Academy</strong> needs Main Building Level 5 + Barracks Level 3 + Smithy Level 1.</li>
                    <li><strong>Workshop</strong> needs Main Building Level 3 + Barracks Level 5.</li>
                </ul>
                <p>Upgrade the prerequisite buildings to unlock new ones.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How big is the build queue?</summary>
            <div class="faq-answer">
                <p>You can queue up to <strong><?= $queue_size ?> builds</strong> at a time per village. Each build's finish time is calculated and chained — the second build starts the moment the first finishes.</p>
                <p>Builds can be cancelled for a <strong>50% resource refund</strong> — useful if you change your mind.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What's the max building level?</summary>
            <div class="faq-answer">
                <p>Most buildings cap at <strong>Level <?= $max_building ?></strong>. Higher levels cost exponentially more resources and time (cost = base × 1.6<sup>level-1</sup>), so don't expect to max out everything quickly.</p>
            </div>
        </details>
    </div>

    <!-- ============================================================
         4. TROOPS & COMBAT
         ============================================================ -->
    <div class="faq-section" id="troops">
        <h2>4. ⚔️ Troops &amp; Combat</h2>

        <details class="faq-item">
            <summary>How do I train troops?</summary>
            <div class="faq-answer">
                <ol>
                    <li>Build a <strong>Barracks</strong> (for infantry) or <strong>Stable</strong> (for cavalry).</li>
                    <li>Open the <strong>Troops</strong> page from the top navigation.</li>
                    <li>Select how many units you want to train and click <strong>Train</strong>.</li>
                    <li>Training happens in real time — units appear in your village when their training finishes.</li>
                </ol>
                <div class="tip">💡 Higher Barracks/Stable level = faster training (3% per level, max -30%).</div>
            </div>
        </details>

        <details class="faq-item">
            <summary>Which units can I train?</summary>
            <div class="faq-answer">
                <p>Each tribe has 5 unit types. The <strong>basic infantry</strong> is available as soon as you build a Barracks. The other 4 units must be <strong>researched at the Academy</strong> first.</p>
                <p>Basic infantry (always available):</p>
                <ul>
                    <li>Roman — Legionnaire</li>
                    <li>Gaul — Phalanx</li>
                    <li>Teuton — Clubswinger</li>
                </ul>
                <p>For the full list of advanced units, see your <strong>Troops</strong> page (units marked "🔬 Research required" need Academy research first).</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How does combat work?</summary>
            <div class="faq-answer">
                <p>When your troops attack a village:</p>
                <ol>
                    <li>Each attacker unit contributes its <code>attack</code> stat. Total = sum of all attacking units' attack values.</li>
                    <li>Each defender unit contributes its <code>def_inf</code> stat. Total = sum of all defending units' def_inf values.</li>
                    <li>If <strong>attacker power &gt; defender power</strong>, the attacker wins. Attackers return home with 50% of their troops and loot resources (capped by their carry capacity × tribe loot multiplier).</li>
                    <li>If <strong>defender power ≥ attacker power</strong>, the defender wins. All attackers die. Defender keeps 50% of their troops.</li>
                </ol>
                <div class="tip">💡 Cavalry is fast but expensive. Infantry is cheap and slow. Use scouts (pathfinder/equites_legati/scout) to <em>scout</em> enemy villages before attacking.</div>
            </div>
        </details>

        <details class="faq-item">
            <summary>What is the loot multiplier?</summary>
            <div class="faq-answer">
                <p>Each tribe raids differently:</p>
                <ul>
                    <li><strong>Teutons</strong>: <?= $tribe_loot['teuton'] ?>% of carry capacity (best raiders)</li>
                    <li><strong>Romans</strong>: <?= $tribe_loot['roman'] ?>% of carry capacity</li>
                    <li><strong>Gauls</strong>: <?= $tribe_loot['gaul'] ?>% of carry capacity</li>
                </ul>
                <p>Example: 10 Legionnaires (carry 50 each = 500 total) raiding as Romans would steal up to <code>500 × <?= $tribe_loot['roman'] ?>% = <?= 500 * $tribe_loot['roman'] / 100 ?></code> resources.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How do I send troops to another village?</summary>
            <div class="faq-answer">
                <ol>
                    <li>Open the <strong>Troops</strong> page.</li>
                    <li>Scroll to <strong>Send Troops</strong>.</li>
                    <li>Enter target coordinates (X|Y) and choose <strong>Attack</strong> or <strong>Reinforcement</strong>.</li>
                    <li>Select how many of each unit to send.</li>
                    <li>Click <strong>Send Troops</strong> — they'll travel to the target. Travel time depends on distance and the slowest unit's speed.</li>
                </ol>
                <p>Alternatively, click any cell on the <strong>Map</strong> page to open its info panel — there you'll find direct Attack and Reinforce buttons.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What's the difference between Attack and Reinforcement?</summary>
            <div class="faq-answer">
                <ul>
                    <li><strong>Attack (raid)</strong> — your troops fight the defender. If you win, you steal resources and your survivors return home. If you lose, all attackers die.</li>
                    <li><strong>Reinforcement</strong> — your troops stay in the target village and add to its defense. They fight on the defender's side if the village is attacked. You can recall them later (or the village owner can send them back).</li>
                </ul>
                <div class="tip">💡 Reinforce your allies when they're under attack — a coordinated defense is much stronger than each player defending alone.</div>
            </div>
        </details>
    </div>

    <!-- ============================================================
         5. ACADEMY & RESEARCH
         ============================================================ -->
    <div class="faq-section" id="academy">
        <h2>5. 🔬 Academy &amp; Research</h2>

        <details class="faq-item">
            <summary>What does the Academy do?</summary>
            <div class="faq-answer">
                <p>The Academy is where scholars <strong>research new troop types</strong>. Without Academy research, you can only train your tribe's basic infantry (Legionnaire / Phalanx / Clubswinger). All other units must be researched first.</p>
                <p>To build the Academy, you need:</p>
                <ul>
                    <li>Main Building Level 5</li>
                    <li>Barracks Level 3</li>
                    <li>Smithy Level 1</li>
                </ul>
            </div>
        </details>

        <details class="faq-item">
            <summary>How does research work?</summary>
            <div class="faq-answer">
                <ol>
                    <li>Build an Academy.</li>
                    <li>Click the Academy in your village grid to open the <strong>Academy Research</strong> panel.</li>
                    <li>Each unit has a research cost (resources + time) and may require a previous research to be completed first.</li>
                    <li>Click <strong>Research</strong> to start the project. When the timer finishes, the unit is unlocked and can be trained at the Barracks or Stable.</li>
                </ol>
                <div class="tip">💡 Higher Academy level = faster research (5% per level, max -50%) and unlocks more advanced units.</div>
            </div>
        </details>

        <details class="faq-item">
            <summary>Do I need to research in every village?</summary>
            <div class="faq-answer">
                <p>Yes — research is <strong>per village</strong>. If you found a second village (coming soon), it must re-research its own troops. Each village needs its own Academy.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What's the research order for my tribe?</summary>
            <div class="faq-answer">
                <p><strong>Romans:</strong></p>
                <ul>
                    <li>Praetorian → Imperian → Equites Legati → Equites Imperatoris</li>
                </ul>
                <p><strong>Gauls:</strong></p>
                <ul>
                    <li>Swordsman → Pathfinder → Theutates Thunder → Druidrider</li>
                </ul>
                <p><strong>Teutons:</strong></p>
                <ul>
                    <li>Spearman → Axeman → Scout → Paladin</li>
                </ul>
            </div>
        </details>
    </div>

    <!-- ============================================================
         6. MARKETPLACE & TRADE
         ============================================================ -->
    <div class="faq-section" id="marketplace">
        <h2>6. 📦 Marketplace &amp; Trade</h2>

        <details class="faq-item">
            <summary>How do I trade resources?</summary>
            <div class="faq-answer">
                <p>Build a <strong>Marketplace</strong> (requires Main Building Lv 3 + Warehouse Lv 1 + Granary Lv 1). The Marketplace gives you several options:</p>
                <ul>
                    <li><strong>Send Resources</strong> — send wood/clay/iron/crop directly to another village (yours or another player's). Costs merchants based on amount.</li>
                    <li><strong>NPC Trade</strong> — redistribute your warehouse resources for a fee of <?= $npc_cost ?> gold. Useful when you have 5000 wood but 0 clay.</li>
                    <li><strong>Trade Offers</strong> — create offers like "offering 1000 wood, want 800 clay". Other players can accept — they send the wanted resource, you send the offered resource back.</li>
                </ul>
            </div>
        </details>

        <details class="faq-item">
            <summary>How many merchants do I have?</summary>
            <div class="faq-answer">
                <p>You get <strong>1 merchant per Marketplace level</strong>. Each merchant can carry <strong>500 resources</strong>.</p>
                <p>Example: Marketplace Level 5 = 5 merchants = 2,500 resources of total carrying capacity.</p>
                <p>Merchants currently on the road (delivering) count as "in use" — they come back when the shipment arrives.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How long does shipping take?</summary>
            <div class="faq-answer">
                <p>Merchants travel at <strong>12 fields/hour</strong>. Travel time depends on the distance between the source and target village.</p>
                <p>Example: 10 fields away = ~50 minutes one-way at <?= $server_speed ?>x server speed.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How do trade offers work?</summary>
            <div class="faq-answer">
                <ol>
                    <li>Create an offer: "I offer 1000 wood, I want 800 clay, max 24h transport."</li>
                    <li>The offered resources are held in <strong>escrow</strong> (removed from your warehouse immediately).</li>
                    <li>Other players see your offer on their Marketplace page. If they accept, they send you the wanted resource, you send them the offered resource.</li>
                    <li>Both shipments travel simultaneously and arrive at the same time.</li>
                    <li>Offers auto-expire after 48 hours if nobody accepts. Cancel any time for a full refund of the held resources.</li>
                </ol>
            </div>
        </details>
    </div>

    <!-- ============================================================
         7. MAP & VILLAGES
         ============================================================ -->
    <div class="faq-section" id="map">
        <h2>7. 🗺️ Map &amp; Villages</h2>

        <details class="faq-item">
            <summary>How does the world map work?</summary>
            <div class="faq-answer">
                <p>The world map is an infinite grid. Open the <strong>Map</strong> page to see a 13×13 view centered on your village (or any cell you click).</p>
                <p>Each cell has one of 5 terrain types:</p>
                <ul>
                    <li>🌾 <strong>Grassland</strong> — fertile, ideal for crops (+15% crop if settled)</li>
                    <li>🌲 <strong>Forest</strong> — rich in timber (+15% wood)</li>
                    <li>⛰️ <strong>Mountain</strong> — iron ore deposits (+15% iron)</li>
                    <li>🏜️ <strong>Desert</strong> — clay deposits (+15% clay)</li>
                    <li>💧 <strong>Water</strong> — impassable, cannot be settled</li>
                </ul>
                <p>Terrain is deterministic — the same (X, Y) always has the same terrain for every player.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What happens when I click a cell?</summary>
            <div class="faq-answer">
                <p>A detailed <strong>cell info page</strong> opens showing:</p>
                <ul>
                    <li>Terrain type + description + production bonus</li>
                    <li>Village name, owner, tribe, loyalty, population, villages, troops, hero (if occupied)</li>
                    <li>Distance from your village + travel times for merchants / infantry / cavalry</li>
                    <li>Direct action buttons: Attack, Reinforce, Send Resources, View Profile</li>
                    <li>List of nearby villages within 5 fields</li>
                </ul>
                <p>For empty (abandoned) cells, you'll see flavor text describing the terrain and a note that village founding is not yet implemented.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What do the colored dots on village cells mean?</summary>
            <div class="faq-answer">
                <ul>
                    <li>🟢 <strong>Green dot</strong> — your own village</li>
                    <li>🔴 <strong>Red dot</strong> — enemy village (owned by another player)</li>
                    <li>🟡 <strong>Gold overlay</strong> — your currently selected/centered village</li>
                </ul>
            </div>
        </details>

        <details class="faq-item">
            <summary>Can I found a new village?</summary>
            <div class="faq-answer">
                <p>Not yet — this feature is on the roadmap. Currently each player has exactly one village (their capital). Multiple villages per player will be added in a future update.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How is village loyalty used?</summary>
            <div class="faq-answer">
                <p>Each village starts with <strong>100% loyalty</strong>. Loyalty decreases when the village is successfully attacked (coming soon — this is a placeholder for the conquest system). If loyalty drops to 0, the village can be conquered by the attacker.</p>
                <p>For now, loyalty is just displayed — it doesn't affect gameplay yet.</p>
            </div>
        </details>
    </div>

    <!-- ============================================================
         8. HERO
         ============================================================ -->
    <div class="faq-section" id="hero">
        <h2>8. 🦸 Hero</h2>

        <details class="faq-item">
            <summary>What is the hero?</summary>
            <div class="faq-answer">
                <p>Each player has one <strong>hero</strong> — a unique unit with HP, XP, attack, and defense stats. Your hero is recruited at the <strong>Hero Mansion</strong> (requires Main Building Lv 3 + Rally Point Lv 1).</p>
                <p>Your hero starts at Level 1 with full HP. You can rename them from the Hero page.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How does my hero level up?</summary>
            <div class="faq-answer">
                <p>Heroes gain experience (XP) by participating in battles and adventures. When XP reaches the next level threshold, your hero levels up and gains stat boosts.</p>
                <div class="warn">⚠️ Hero combat and adventures are coming soon — for now, the hero is more of a vanity/identity unit.</div>
            </div>
        </details>

        <details class="faq-item">
            <summary>Can my hero die?</summary>
            <div class="faq-answer">
                <p>Yes — if your hero's HP reaches 0 in combat, they die. You can revive them at the Hero Mansion (coming soon).</p>
            </div>
        </details>
    </div>

    <!-- ============================================================
         9. ACCOUNT & SERVER
         ============================================================ -->
    <div class="faq-section" id="server">
        <h2>9. ⚙️ Account &amp; Server</h2>

        <details class="faq-item">
            <summary>What is server speed?</summary>
            <div class="faq-answer">
                <p>Server speed is a global multiplier (<code><?= $server_speed ?>x</code> on this server) applied to:</p>
                <ul>
                    <li>Resource production rates</li>
                    <li>Build times</li>
                    <li>Training times</li>
                    <li>Travel times</li>
                    <li>Research times</li>
                </ul>
                <p>At <?= $server_speed ?>x speed, everything happens <?= $server_speed ?> times faster than vanilla Travian. A build that would normally take 1 hour takes just <?= round(60/$server_speed) ?> minutes.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>What is gold and how do I get it?</summary>
            <div class="faq-answer">
                <p>Gold is a premium currency shown in the top-right of your header (₲ icon). Uses:</p>
                <ul>
                    <li><strong>NPC Trade</strong> — costs <?= $npc_cost ?> gold per use (redistribute warehouse resources).</li>
                    <li>More gold uses coming soon (instant build, resource boosts, etc.).</li>
                </ul>
                <p>Currently gold is awarded by admins (no in-game earning mechanism yet). New accounts start with 0 gold.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>How is the "Online Now" count calculated?</summary>
            <div class="faq-answer">
                <p>The server tracks each player's <strong>last activity</strong> — updated whenever an authenticated player loads any page (throttled to once per minute to avoid hammering the database).</p>
                <p>"Online now" = players who have been active within the last <strong>5 minutes</strong>. "Active today" = active within the last 24 hours. "Active this week" = active within the last 7 days.</p>
                <p>You can see the online player list on the landing page (when logged out) and on the Ranks page (when logged in).</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>Can I change my tribe or username?</summary>
            <div class="faq-answer">
                <p>No — tribe is permanent for the lifetime of your account. Username changes are not currently supported. If you want to switch tribes, you'll need to register a new account.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>Is my data safe? Can I delete my account?</summary>
            <div class="faq-answer">
                <p>Your account data is stored in the game's database (SQLite file or MySQL). Passwords are hashed with PHP's <code>password_hash()</code> — they are never stored in plain text.</p>
                <p>Account deletion is not yet implemented via the UI. Contact the server administrator if you need your account removed.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>The game feels slow / fast. Can I change the speed?</summary>
            <div class="faq-answer">
                <p>Server speed is set globally in <code>app/config/config.php</code> by the server administrator (constant <code>GAME_SERVER_SPEED</code>, currently <code><?= $server_speed ?></code>). Players cannot change it.</p>
                <p>If you're playing on a private server, edit the config file and reload — all production/build/travel times will adjust automatically.</p>
            </div>
        </details>

        <details class="faq-item">
            <summary>Where can I report bugs or suggest features?</summary>
            <div class="faq-answer">
                <p>This is a custom project — there's no official bug tracker. If you're playing on a friend's server, contact them directly. If you're running your own server, edit the code freely (the codebase is pure PHP, no framework).</p>
                <p>Check the <code>README.md</code> file in the project root for development notes and the roadmap of planned features.</p>
            </div>
        </details>
    </div>

    <!-- ============================================================
         Footer / contact
         ============================================================ -->
    <div style="margin-top:24px;padding:16px;background:#f4ead5;border:2px solid var(--c-outline);border-radius:8px;text-align:center;">
        <h3 style="color:var(--c-wood-dk);margin-bottom:6px;">📜 Still have questions?</h3>
        <p style="font-size:13px;color:var(--c-text-soft);margin-bottom:12px;">
            This FAQ covers the basics. The best way to learn <?= e(GAME_NAME) ?> is to play it — register, build your first village, and explore the world map.
        </p>
        <?php if (current_player_id()): ?>
        <a href="<?= url('/village.php') ?>" class="btn btn-green">🏠 Back to Village</a>
        <a href="<?= url('/map.php') ?>" class="btn btn-blue">🗺️ Open Map</a>
        <?php else: ?>
        <a href="<?= url('/register.php') ?>" class="btn btn-green btn-lg">Start Playing</a>
        <a href="<?= url('/login.php') ?>" class="btn btn-blue btn-lg">Login</a>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
