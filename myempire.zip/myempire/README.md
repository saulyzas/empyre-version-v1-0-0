# MYEMPIRE — A Travian-style browser strategy game in PHP + SQLite

A self-contained PHP port inspired by [Parabellum](https://github.com/andreapavoni/parabellum).
All artwork is original cartoon-style 2D, generated procedurally with Python/Pillow.

---

## ✨ Features

- **Authentication**: register / login / logout with tribe selection (Romans / Gauls / Teutons) and starting quadrant.
- **Resource fields**: 18 procedurally-laid-out fields (4 woodcutter + 4 clay pit + 4 iron mine + 6 cropland) around a village center. Upgrade them up to level 10 to boost production.
- **Village center**: 20 buildable slots. 13 building types (Main Building, Warehouse, Granary, Barracks, Stable, Workshop, Marketplace, Embassy, Rally Point, Hero Mansion, Smithy, **Academy**, City Wall).
- **Header with main navigation** — the top bar shows the brand, player info, gold, server time, and the resource bar. The main nav links (Fields, Village, Troops, Map, Ranks, Reports, Hero) let the player jump between screens; deeper actions take place inside each building's page.
- **Academy research** — advanced troops must be researched at the Academy before they can be trained. Each Academy level unlocks stronger units and speeds up research. Research is per-village.
- **Real-time production**: resources accumulate per second based on field levels × server speed (default 5×).
- **Build queue**: stack up to 2 builds; finishes_at times chain automatically. Cancel with 50 % refund.
- **World map**: 13×13 navigable map grid with deterministic terrain (grass/forest/mountain/desert/water) and player villages.
- **Stats**: server-wide ranking by population.
- **Reports**: welcome message + extensible reports system.
- **Hero**: per-player hero with HP / XP / attack / defense bars, renameable, tribe-specific portrait.
- **Cartoon UI**: warm stone/wood/gold palette, bold outlines, soft shadows — a clean take on the classic Travian look.

---

## 📁 Project structure

```
myempire/
├── index.php                  # Landing page (tribes showcase)
├── login.php                  # Login form
├── register.php               # Registration (tribe + quadrant picker)
├── logout.php                 # Destroy session
├── resources.php              # 18-field SVG map + queue + sidebar
├── field.php?id=N             # Single field upgrade dialog
├── village.php                # 20-slot village grid + queue
├── build.php?id=N             # "Build new structure" picker
├── building.php?id=N          # Building upgrade dialog
├── map.php?x=..&y=..          # 13×13 world map
├── stats.php                  # Player ranking
├── reports.php                # Reports inbox + detail
├── hero.php                   # Hero management
├── .htaccess                  # Apache rules (protects app/ and sql/)
│
├── app/
│   ├── config/config.php      # Branding, paths, game balance, units, costs
│   ├── lib/
│   │   ├── Database.php       # PDO SQLite/MySQL singleton + schema bootstrap
│   │   ├── helpers.php        # Auth, resources, build queue, terrain
│   │   └── error_handler.php  # Friendly DB error page
│   ├── views/
│   │   ├── header.php         # Header + nav + resource bar
│   │   └── footer.php         # Footer + JS includes
│   └── api/
│       ├── state.php          # JSON: current resources + queue
│       └── cancel_build.php   # JSON: cancel a build (50 % refund)
│
├── img/                       # 97 cartoon 2D PNGs (served directly)
│   ├── resources/             # woodcutter/claypit/ironmine/cropland × 3 levels
│   ├── buildings/             # 12 buildings + level variations
│   ├── troops/                # 3 tribe heroes + 15 unit sprites (5 per tribe)
│   ├── tribes/                # 3 tribe crests (small + large)
│       ├── ui/                # buttons, slots, level badges, flags, queue icon
│       ├── misc/              # wood/clay/iron/crop icons, pop/loyalty/capital, sprite sheet
│       ├── village/           # village_bg, hero_bg
│       └── map/               # 6 terrain tiles
│
├── assets/
│   ├── css/style.css          # Cartoon theme (stone/wood/gold palette)
│   └── js/main.js             # Live clock, resource ticker, queue countdown
│
├── db/                        # SQLite database file (auto-created on first run)
├── sql/schema.sql             # Full schema + triggers + views
└── README.md                  # This file
```

---

## 🚀 Installation

> **Choose your database**: By default the app uses `DB_DRIVER='auto'`, which tries SQLite first (zero-config) and falls back to MySQL/MariaDB if SQLite isn't available. So you don't need to do anything special — just make sure at least one of them is set up.
>
> If you want to force a specific driver, edit `app/config/config.php`:
> ```php
> define('DB_DRIVER', 'auto');   // default — try SQLite, fall back to MySQL
> define('DB_DRIVER', 'sqlite'); // force SQLite
> define('DB_DRIVER', 'mysql');  // force MySQL/MariaDB
> ```

### Option A — XAMPP + SQLite (easiest, recommended for local play)

1. Install [XAMPP](https://www.apachefriends.org/).
2. Copy the entire `myempire/` folder into `htdocs/`:
   - Windows: `C:\xampp\htdocs\myempire\`
   - macOS:   `/Applications/XAMPP/htdocs/myempire/`
   - Linux:   `/opt/lampp/htdocs/myempire/`
3. **Enable the SQLite extension in PHP** (one-time setup):
   1. Open `C:\xampp\php\php.ini` in Notepad (run as Administrator if needed).
   2. Press `Ctrl+F` and search for `pdo_sqlite`.
   3. Find the line: `;extension=pdo_sqlite` (or `;extension=sqlite3`)
   4. Remove the leading `;` so it becomes: `extension=pdo_sqlite` (and `extension=sqlite3`)
   5. Save the file and restart Apache from the XAMPP control panel (Stop → Start).
4. Make sure the `db/` directory is writable by the web server.
   - On Linux/macOS: `chmod -R 775 /opt/lampp/htdocs/myempire/db`
5. Start Apache from the XAMPP control panel.
6. Open `http://localhost/myempire/` in your browser.
7. The SQLite database is auto-created on first page load. Register your first account — done!

> **Tip**: If you see "could not find driver", the SQLite extension isn't enabled.
> Either complete step 3 above, or switch to MySQL (Option B).

### Option B — XAMPP + MySQL/MariaDB (recommended for production / shared hosting)

1. Install [XAMPP](https://www.apachefriends.org/) and start **Apache** + **MySQL** from the control panel.
2. Copy the entire `myempire/` folder into `htdocs/` (see paths above).
3. Open [phpMyAdmin](http://localhost/phpmyadmin/) and:
   1. Click **"New"** in the left sidebar.
   2. Create a database named **`myempire`** (collation: `utf8mb4_unicode_ci`).
   3. Select the `myempire` database in the left sidebar.
   4. Click the **"Import"** tab.
   5. Choose file: `myempire/sql/schema_mysql.sql`
   6. Click **"Go"** — all tables + triggers will be created.
4. Edit `myempire/app/config/config.php` and change the driver:
   ```php
   define('DB_DRIVER', 'mysql');   // was 'sqlite'
   define('DB_HOST',   '127.0.0.1');
   define('DB_NAME',   'myempire');
   define('DB_USER',   'root');    // your MySQL user
   define('DB_PASS',   '');        // your MySQL password
   ```
5. Open `http://localhost/myempire/` — register and play!

### Option C — PHP built-in server (PHP 7.4+ with pdo_sqlite or pdo_mysql)

```bash
cd myempire
php -S localhost:8000
# open http://localhost:8000/
```

### Option D — Any LAMP/WAMP/MAMP stack

- PHP 7.4 or newer with `pdo_sqlite` and/or `pdo_mysql` extension enabled.
- Document root = the `myempire/` directory.
- `db/` directory must be writable (only when using SQLite).
- For MySQL: import `sql/schema_mysql.sql` and edit config.

---

## 🎮 How to play

1. **Register** — pick a tribe (Romans / Gauls / Teutons) and a starting quadrant. You'll be dropped into your new village.
2. **Fields** — open the Fields tab. Click any tile to upgrade it. Each level boosts hourly production of that resource.
3. **Village** — open the Village tab. Click empty slots to build structures (Warehouse first to boost storage, then Barracks for troops, etc.). Click existing buildings to upgrade them.
4. **Queue** — up to 2 builds can be queued at once. Each finishes after its build time (visible on the upgrade dialog). Cancel for a 50 % refund.
5. **Map** — explore the world map. Other players' villages appear as houses; wilderness is color-coded by terrain.
6. **Hero** — your hero starts at level 1 with full HP. Rename it from the Hero tab. (Combat coming soon.)
7. **Academy** — once you have a Main Building Lv 5, Barracks Lv 3, and a Smithy, build the Academy. Research advanced troops (Praetorian, Imperian, Equites Legati, Equites Imperatoris for Romans; equivalent units for Gauls and Teutons) inside the Academy page. Basic infantry (Legionnaire / Phalanx / Clubswinger) is always trainable once the Barracks is built — no research required.
8. **Ranks & Reports** — see where you stand vs. other players; read system reports.

---

## ⚙️ Configuration

Edit `app/config/config.php`:

| Constant              | Default | Meaning                                  |
|-----------------------|---------|------------------------------------------|
| `GAME_NAME`           | MYEMPIRE | Your game's name (shown in header, footer, hero section) |
| `GAME_TAGLINE`        | "Rule the Ancient World" | Landing page subtitle |
| `GAME_SERVER_SPEED`   | 5       | Multiplier for production rates (1× = vanilla Travian) |
| `STARTING_RESOURCES`  | 800     | Initial wood/clay/iron/crop per village  |
| `MAX_RESOURCE_LEVEL`  | 10      | Max level for resource fields            |
| `MAX_BUILDING_LEVEL`  | 20      | Max level for village buildings          |
| `BUILD_QUEUE_SIZE`    | 2       | Max concurrent build queue items         |

Tribes, units, building costs, build-time formulas are all in the same file — feel free to rebalance.

---

## 🗃️ Database

Two drivers are supported — pick one in `app/config/config.php`:

### SQLite (default)
- **Engine**: SQLite (single file at `db/myempire.sqlite`)
- **Schema**: `sql/schema.sql` (auto-loaded on first run)
- **Triggers**: inserting a village auto-creates 18 resource fields, 1 main building, and a resource stockpile row
- **Views**: `v_player_resources` joins players → villages → resources for convenience
- To reset: delete `db/myempire.sqlite` and reload any page.

### MySQL / MariaDB
- **Engine**: MySQL 5.7+ / MariaDB 10.2+ (InnoDB, utf8mb4)
- **Schema**: `sql/schema_mysql.sql` — import via phpMyAdmin or CLI:
  ```bash
  mysql -u root -p myempire < sql/schema_mysql.sql
  ```
- **Triggers**: same atomic village initialization as SQLite version (`trg_init_village`)
- **View**: `v_player_resources` available
- To reset: drop all tables (or `DROP DATABASE myempire; CREATE DATABASE myempire;`) and re-import.

> **Why two schemas?** SQLite uses `INTEGER PRIMARY KEY AUTOINCREMENT` and `datetime('now')`; MySQL uses `INT AUTO_INCREMENT` and `CURRENT_TIMESTAMP`. They're not interchangeable — pick the right one for your DB.

---

## 🎨 Art assets

All 97 images are original cartoon-style 2D art, generated with Python + Pillow. The generator script lives at `scripts/generate_images.py` (in the source repo, not in this package). To regenerate or tweak:

```bash
python scripts/generate_images.py   # writes to public/img/
```

Categories:
- **Resources** (4): wood / clay / iron / crop icons (32×32)
- **Field tiles** (12): 4 types × 3 levels (128×128) with level badge
- **Buildings** (13 + 12 level variations): main_building, warehouse, granary, barracks, stable, workshop, marketplace, embassy, rally_point, hero_mansion, smithy, **academy**, wall
- **Tribes** (6): Roman / Gaul / Teuton shields (128 + 256 px crest)
- **Heroes** (4): one portrait per tribe + generic hero icon
- **Troops** (15): 5 units per tribe (legionnaire / praetorian / imperian / equites_legati / equites_imperatoris for Romans; phalanx / swordsman / pathfinder / theutates_thunder / druidrider for Gauls; clubswinger / spearman / axeman / scout / paladin for Teutons)
- **UI** (18): buttons (build / upgrade / cancel / login / register), panels, empty/built slots, level badges 1-5, queue icon, flags (red/blue/green), divider
- **Misc** (7): population, loyalty, capital, clock, coords icons + sprite sheet
- **Backgrounds** (2): village_bg, hero_bg
- **Map tiles** (6): grass, forest, mountain, water, desert, village (64×64 each)

---

## 🔧 Development notes

- **No framework** — pure vanilla PHP with PDO. Easy to read, easy to modify.
- **SQLite** means no separate DB server; perfect for personal projects, learning, and small communities.
- **Triggers** keep village setup atomic — registering a player creates a fully-initialized village in one transaction.
- **Live updates** — the resource bar ticks every second using client-side JS based on production rates sent from PHP. Queue countdowns update every second too.
- **API endpoints** under `app/api/` return JSON for future AJAX-driven features.

---

## 🗺️ Roadmap

Planned but not yet implemented:

- [x] Combat system (attacking other villages)
- [x] Unit training at Barracks/Stable
- [x] Academy research for advanced troops
- [x] Marketplace trades between players
- [ ] Alliance system (Embassy)
- [ ] Quests and adventures for heroes
- [ ] Village renaming UI
- [ ] Multiple villages per player (found new villages)
- [ ] NPC barbarian villages on the map
- [ ] Oases (capturable terrain bonuses)

---

## 📜 Credits

- **Original inspiration**: [Parabellum](https://github.com/andreapavoni/parabellum) by Andrea Pavoni — a Rust + Preact Travian clone. This PHP port reuses the high-level game design but shares no code.
- **Game design inspiration**: Travian (Travian Games GmbH) — this project is **not affiliated with Travian Games GmbH**.
- **Art**: All 2D images generated procedurally with Python + Pillow. No external assets used.

---

## 📄 License

MIT — see source repository for LICENSE file. Use it, fork it, mod it, ship it.

---

Built with ❤️ for browser-strategy fans. Have fun ruling your empire!
