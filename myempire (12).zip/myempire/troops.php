<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

$player = current_player();
$tribe = $player['tribe'];
$available_units = $UNITS[$tribe] ?? [];

// Find Barracks and Stable levels
$buildings = get_buildings($village['id']);
$buildings_by_pos = [];
foreach ($buildings as $b) $buildings_by_pos[$b['position']] = $b;

$barracks_level = 0;
$stable_level = 0;
foreach ($buildings as $b) {
    if ($b['building_type'] === 'barracks') $barracks_level = $b['level'];
    if ($b['building_type'] === 'stable')   $stable_level   = $b['level'];
}

// Categorize units: infantry (barracks) vs cavalry (stable)
$infantry_keys = ['legionnaire','praetorian','imperian','phalanx','swordsman','clubswinger','spearman','axeman'];
$cavalry_keys  = ['equites_legati','equites_imperatoris','pathfinder','theutates_thunder','druidrider','scout','paladin'];

// Handle training request
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $unit_type = $_POST['unit_type'] ?? '';
    $count = (int)($_POST['count'] ?? 0);
    
    if (!isset($available_units[$unit_type])) {
        $error = 'Invalid unit type for your tribe.';
    } elseif ($count <= 0) {
        $error = 'Count must be at least 1.';
    } else {
        // Check building exists
        $is_cavalry = in_array($unit_type, $cavalry_keys);
        $building_level = $is_cavalry ? $stable_level : $barracks_level;
        if ($building_level < 1) {
            $error = 'You need a ' . ($is_cavalry ? 'Stable' : 'Barracks') . ' to train this unit.';
        } else {
            $result = enqueue_training($village['id'], $unit_type, $count, $building_level);
            if ($result['ok']) {
                $success = ucfirst(str_replace('_',' ',$unit_type)) . " x$count added to training queue.";
                redirect('/troops.php');
            } else {
                $error = $result['error'];
            }
        }
    }
}

$troops = get_village_troops($village['id']);
$training_queue = get_training_queue($village['id']);

$page_title = 'Troops';
require __DIR__ . '/app/views/header.php';
?>

<div class="grid grid-2">
    <div>
        <div class="card">
            <div class="card-header">Train Troops (<?= e(ucfirst($tribe)) ?>)</div>
            
            <?php if ($error): ?>
            <div class="alert alert-error"><?= e($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
            <?php endif; ?>

            <?php if ($barracks_level < 1 && $stable_level < 1): ?>
            <div class="alert alert-info">
                You need to build a <strong>Barracks</strong> (for infantry) or <strong>Stable</strong> (for cavalry)
                before you can train troops. Visit the <a href="<?= url('/village.php') ?>">Village</a> page.
            </div>
            <?php endif; ?>

            <!-- Infantry (Barracks) -->
            <h3 style="color:var(--c-wood-dk);margin-bottom:8px;">⚔️ Infantry (Barracks Lv <?= $barracks_level ?>)</h3>
            <?php if ($barracks_level < 1): ?>
            <p style="color:var(--c-text-soft);font-size:13px;margin-bottom:16px;">Build a Barracks to train infantry units.</p>
            <?php else: ?>
            <table class="data">
                <thead>
                    <tr>
                        <th>Unit</th>
                        <th>Cost (each)</th>
                        <th>Time (each)</th>
                        <th>Have</th>
                        <th>Train</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($available_units as $key => $u):
                    if (!in_array($key, $infantry_keys)) continue;
                    $cost = $u['cost'];
                    $base_time = $UNIT_TRAIN_TIME[$key] ?? 240;
                    $time = training_time_seconds($base_time, $barracks_level);
                    $have_count = 0;
                    foreach ($troops as $t) {
                        if ($t['unit_type'] === $key) { $have_count = $t['count']; break; }
                    }
                    $can_afford_one = ($resources['wood'] >= $cost['wood'] && $resources['clay'] >= $cost['clay']
                                    && $resources['iron'] >= $cost['iron'] && $resources['crop'] >= $cost['crop']);
                ?>
                <tr>
                    <td style="display:flex;align-items:center;gap:6px;">
                        <img src="<?= img_url("troops/{$tribe}_{$key}.png") ?>" width="32" height="32" style="image-rendering:pixelated;" alt="">
                        <div>
                            <strong><?= e($u['name']) ?></strong><br>
                            <small>ATK <?= $u['attack'] ?> / DEF <?= $u['def_inf'] ?>/<?= $u['def_cav'] ?></small>
                        </div>
                    </td>
                    <td style="font-size:11px;">
                        <span class="res-icon res-wood"></span><?= $cost['wood'] ?><br>
                        <span class="res-icon res-clay"></span><?= $cost['clay'] ?><br>
                        <span class="res-icon res-iron"></span><?= $cost['iron'] ?><br>
                        <span class="res-icon res-crop"></span><?= $cost['crop'] ?>
                    </td>
                    <td style="font-size:11px;"><?= e(format_seconds($time)) ?></td>
                    <td><strong><?= $have_count ?></strong></td>
                    <td>
                        <form method="POST" style="display:flex;gap:4px;align-items:center;">
                            <input type="hidden" name="unit_type" value="<?= e($key) ?>">
                            <input type="number" name="count" value="1" min="1" max="100" style="width:50px;padding:2px;" class="form-control">
                            <button type="submit" class="btn btn-green btn-sm" <?= !$can_afford_one ? 'disabled' : '' ?>>Train</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>

            <hr style="margin:16px 0;">

            <!-- Cavalry (Stable) -->
            <h3 style="color:var(--c-wood-dk);margin-bottom:8px;">🐎 Cavalry (Stable Lv <?= $stable_level ?>)</h3>
            <?php if ($stable_level < 1): ?>
            <p style="color:var(--c-text-soft);font-size:13px;">Build a Stable to train cavalry units.</p>
            <?php else: ?>
            <table class="data">
                <thead>
                    <tr>
                        <th>Unit</th>
                        <th>Cost (each)</th>
                        <th>Time (each)</th>
                        <th>Have</th>
                        <th>Train</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($available_units as $key => $u):
                    if (!in_array($key, $cavalry_keys)) continue;
                    $cost = $u['cost'];
                    $base_time = $UNIT_TRAIN_TIME[$key] ?? 240;
                    $time = training_time_seconds($base_time, $stable_level);
                    $have_count = 0;
                    foreach ($troops as $t) {
                        if ($t['unit_type'] === $key) { $have_count = $t['count']; break; }
                    }
                    $can_afford_one = ($resources['wood'] >= $cost['wood'] && $resources['clay'] >= $cost['clay']
                                    && $resources['iron'] >= $cost['iron'] && $resources['crop'] >= $cost['crop']);
                ?>
                <tr>
                    <td style="display:flex;align-items:center;gap:6px;">
                        <img src="<?= img_url("troops/{$tribe}_{$key}.png") ?>" width="32" height="32" style="image-rendering:pixelated;" alt="">
                        <div>
                            <strong><?= e($u['name']) ?></strong><br>
                            <small>ATK <?= $u['attack'] ?> / SPD <?= $u['speed'] ?></small>
                        </div>
                    </td>
                    <td style="font-size:11px;">
                        <span class="res-icon res-wood"></span><?= $cost['wood'] ?><br>
                        <span class="res-icon res-clay"></span><?= $cost['clay'] ?><br>
                        <span class="res-icon res-iron"></span><?= $cost['iron'] ?><br>
                        <span class="res-icon res-crop"></span><?= $cost['crop'] ?>
                    </td>
                    <td style="font-size:11px;"><?= e(format_seconds($time)) ?></td>
                    <td><strong><?= $have_count ?></strong></td>
                    <td>
                        <form method="POST" style="display:flex;gap:4px;align-items:center;">
                            <input type="hidden" name="unit_type" value="<?= e($key) ?>">
                            <input type="number" name="count" value="1" min="1" max="100" style="width:50px;padding:2px;" class="form-control">
                            <button type="submit" class="btn btn-green btn-sm" <?= !$can_afford_one ? 'disabled' : '' ?>>Train</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="card-header">Training Queue</div>
            <?php if (empty($training_queue)): ?>
            <p style="color:var(--c-text-soft);">No troops in training.</p>
            <?php else: ?>
            <?php foreach ($training_queue as $item): ?>
            <div class="queue-item">
                <img src="<?= img_url("troops/{$tribe}_{$item['unit_type']}.png") ?>" width="24" height="24" alt="">
                <span class="queue-name">
                    <?= e(ucfirst(str_replace('_',' ',$item['unit_type']))) ?> x<?= (int)$item['count'] ?>
                </span>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($item['finishes_at']) ?>">...</span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="card-header">Send Troops</div>
            <?php if (empty($troops)): ?>
            <p style="color:var(--c-text-soft);">You have no troops to send. Train some first.</p>
            <?php else: ?>
            <form method="POST" action="<?= url('/send_troops.php') ?>">
                <div class="form-group">
                    <label>Target Coordinates (X|Y)</label>
                    <div style="display:flex;gap:4px;">
                        <input type="number" name="to_x" class="form-control" placeholder="X" required style="flex:1;">
                        <input type="number" name="to_y" class="form-control" placeholder="Y" required style="flex:1;">
                    </div>
                </div>
                <div class="form-group">
                    <label>Mission</label>
                    <select name="mission" class="form-control">
                        <option value="attack">Attack (raid)</option>
                        <option value="reinforcement">Reinforcement</option>
                    </select>
                </div>
                <table class="data" style="font-size:12px;">
                    <thead>
                        <tr><th>Unit</th><th>Have</th><th>Send</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($troops as $t): 
                        $u = $available_units[$t['unit_type']] ?? null;
                        if (!$u) continue;
                    ?>
                    <tr>
                        <td>
                            <img src="<?= img_url("troops/{$tribe}_{$t['unit_type']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                            <?= e($u['name']) ?>
                        </td>
                        <td><?= (int)$t['count'] ?></td>
                        <td>
                            <input type="number" name="troops[<?= e($t['unit_type']) ?>]" min="0" max="<?= (int)$t['count'] ?>" value="0" style="width:60px;padding:2px;" class="form-control">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-red" style="margin-top:8px;">Send Troops</button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <div class="panel">
            <div class="panel-title">Your Troops</div>
            <?php if (empty($troops)): ?>
            <p style="font-size:11px;color:var(--c-text-soft);">No troops stationed here.</p>
            <?php else: ?>
            <ul style="list-style:none;font-size:12px;">
                <?php foreach ($troops as $t): 
                    $u = $available_units[$t['unit_type']] ?? ['name' => $t['unit_type']];
                ?>
                <li style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
                    <img src="<?= img_url("troops/{$tribe}_{$t['unit_type']}.png") ?>" width="20" height="20" alt="" style="image-rendering:pixelated;">
                    <span><?= e($u['name']) ?></span>
                    <strong style="margin-left:auto;"><?= (int)$t['count'] ?></strong>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>

        <div class="panel">
            <div class="panel-title">Active Movements</div>
            <?php
            $movs = get_movements($village['id']);
            if (empty($movs['outgoing']) && empty($movs['incoming'])):
            ?>
            <p style="font-size:11px;color:var(--c-text-soft);">No active troop movements.</p>
            <?php else: ?>
            <?php if (!empty($movs['outgoing'])): ?>
            <h4 style="font-size:11px;color:var(--c-wood-dk);margin-top:8px;">OUTGOING</h4>
            <?php foreach ($movs['outgoing'] as $m): ?>
            <div class="queue-item">
                <span class="queue-name">
                    <?= ucfirst($m['type']) ?> → <?= e($m['target_name']) ?> (<?= e($m['target_player']) ?>)
                </span>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($m['arrives_at']) ?>">...</span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php if (!empty($movs['incoming'])): ?>
            <h4 style="font-size:11px;color:var(--c-red-dk);margin-top:8px;">INCOMING</h4>
            <?php foreach ($movs['incoming'] as $m): ?>
            <div class="queue-item">
                <span class="queue-name">
                    <?= ucfirst($m['type']) ?> ← <?= e($m['source_name']) ?> (<?= e($m['source_player']) ?>)
                </span>
                <span class="queue-timer" data-finishes-at="<?= js_timestamp($m['arrives_at']) ?>">...</span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="panel">
            <div class="panel-title">Tips</div>
            <ul style="font-size:11px;padding-left:14px;">
                <li>Build a <strong>Barracks</strong> to train infantry.</li>
                <li>Build a <strong>Stable</strong> to train cavalry.</li>
                <li>Higher building levels = faster training.</li>
                <li>Server speed (<?= GAME_SERVER_SPEED ?>x) applies to training time.</li>
                <li>Each unit has different attack / defense / speed stats.</li>
                <li>Cavalry is faster but more expensive.</li>
            </ul>
        </div>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
