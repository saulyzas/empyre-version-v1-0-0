<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

// Players ranking (by population)
$players = db()->fetchAll(
    "SELECT p.id, p.username, p.tribe, p.population, p.created_at,
            COUNT(v.id) AS village_count
     FROM players p
     LEFT JOIN villages v ON v.player_id = p.id
     GROUP BY p.id
     ORDER BY p.population DESC, p.created_at ASC
     LIMIT 100"
);

// Get loot multiplier per tribe for display
$loot_pct = [
    'teuton' => 100,
    'roman'  => 80,
    'gaul'   => 70,
];

$page_title = 'Ranks';
require __DIR__ . '/app/views/header.php';
?>

<div class="card">
    <div class="card-header">Player Rankings</div>
    <p style="font-size:12px;color:var(--c-text-soft);margin-bottom:12px;">
        Click a player name to view their profile — attack them or send resources.
    </p>
    <table class="data">
        <thead>
            <tr>
                <th>Rank</th>
                <th>Player</th>
                <th>Tribe</th>
                <th>Loot</th>
                <th>Population</th>
                <th>Villages</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($players as $i => $p): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td>
                <a href="<?= url('/player.php') . '?id=' . (int)$p['id'] ?>" style="font-weight:bold;">
                    <img src="<?= img_url("tribes/{$p['tribe']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                    <?= e($p['username']) ?>
                </a>
            </td>
            <td><?= e(ucfirst($p['tribe'])) ?></td>
            <td><?= $loot_pct[$p['tribe']] ?? 70 ?>%</td>
            <td><?= (int)$p['population'] ?></td>
            <td><?= (int)$p['village_count'] ?></td>
            <td>
                <a href="<?= url('/player.php') . '?id=' . (int)$p['id'] ?>" class="btn btn-sm btn-blue">View</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($players)): ?>
        <tr><td colspan="7" style="text-align:center;color:var(--c-text-soft);">No players yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
