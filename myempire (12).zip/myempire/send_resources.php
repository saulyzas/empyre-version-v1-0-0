<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/village.php');
}

$village = current_village();
$to_village_id = (int)($_POST['to_village_id'] ?? 0);
$wood = (int)($_POST['wood'] ?? 0);
$clay = (int)($_POST['clay'] ?? 0);
$iron = (int)($_POST['iron'] ?? 0);
$crop = (int)($_POST['crop'] ?? 0);

// Get target village to find player_id for redirect
$to_vil = db()->fetch("SELECT * FROM villages WHERE id = ?", [$to_village_id]);
if (!$to_vil) {
    $_SESSION['error'] = 'Target village not found.';
    redirect('/village.php');
}

$target_player_id = $to_vil['player_id'];

$result = send_resources($village['id'], $to_village_id, $wood, $clay, $iron, $crop);

if (!$result['ok']) {
    $_SESSION['error'] = $result['error'];
} else {
    $_SESSION['success'] = 'Resources sent! Merchants will arrive at ' . $result['arrives_at'];
}

redirect('/player.php?id=' . $target_player_id);
