<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

// Find the building
$pos = (int)($_GET['id'] ?? -1);
$buildings = get_buildings($village['id']);
$buildings_by_pos = [];
foreach ($buildings as $b) $buildings_by_pos[$b['position']] = $b;

$building = $buildings_by_pos[$pos] ?? null;
if (!$building) {
    redirect('/village.php');
}

// Max level check (use per-building limit if defined)
global $BUILDING_MAX_LEVEL;
$max_level = $BUILDING_MAX_LEVEL[$building['building_type']] ?? MAX_BUILDING_LEVEL;
$next_level = $building['level'] + 1;
$cost = calc_building_cost($building['building_type'], $next_level);
$time_sec = calc_building_time($building['building_type'], $next_level, $buildings_by_pos[0]['level'] ?? 1);
$can_afford = ($resources['wood'] >= $cost['wood'] && $resources['clay'] >= $cost['clay']
            && $resources['iron'] >= $cost['iron'] && $resources['crop'] >= $cost['crop']);
$is_max = $building['level'] >= $max_level;

// Prerequisites for upgrading (re-check)
$prereq = check_building_prerequisites($building['building_type'], $village['id']);
$prereq_ok = $prereq['ok'];

// Handle upgrade
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_max && $can_afford && $prereq_ok) {
    $result = enqueue_build($village['id'], 'building', $building['building_type'], $building['position'], $next_level, $cost, $time_sec);
    if ($result['ok']) {
        redirect('/village.php');
    } else {
        $error = $result['error'];
    }
}
$error = $error ?? '';

$building_descriptions = [
    'main_building' => 'The heart of your village. Higher levels reduce build times for all other structures.',
    'warehouse'     => 'Stores wood, clay, and iron. Each level increases storage capacity by 800.',
    'granary'       => 'Stores crop. Each level increases crop storage capacity by 800.',
    'barracks'      => 'Train infantry units. Higher levels train troops faster.',
    'stable'        => 'Train cavalry units. Higher levels train mounts faster.',
    'workshop'      => 'Build siege engines. Higher levels reduce production time.',
    'marketplace'   => 'Trade resources with other villages. Higher levels allow more merchants.',
    'embassy'       => 'Found or join alliances. Higher levels support larger alliances.',
    'rally_point'   => 'Send and receive troops. Rallies reinforcements here.',
    'hero_mansion'  => 'Recruit and manage your hero. Higher levels unlock more hero slots.',
    'smithy'        => 'Research unit upgrades. Higher levels unlock stronger troops.',
    'wall'          => 'Defensive structure that boosts village defense significantly.',
];

$page_title = 'Building';
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:600px;margin:0 auto;">
    <div class="card-header">
        <?= e(ucfirst(str_replace('_', ' ', $building['building_type']))) ?> (Level <?= (int)$building['level'] ?>)
    </div>

    <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;">
        <img src="<?= img_url("buildings/{$building['building_type']}.png") ?>"
             alt="<?= e($building['building_type']) ?>" style="width:128px;height:128px;image-rendering:pixelated;border:3px solid var(--c-outline);border-radius:8px;">
        <div style="flex:1;">
            <h3 style="color:var(--c-wood-dk);margin-bottom:4px;">
                <?= e(ucfirst(str_replace('_', ' ', $building['building_type']))) ?>
            </h3>
            <p style="font-size:13px;color:var(--c-text-soft);">
                <?= e($building_descriptions[$building['building_type']] ?? 'A useful village structure.') ?>
            </p>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($is_max): ?>
    <div class="alert alert-info">This building has reached the maximum level (Lv <?= (int)$building['level'] ?>/<?= $max_level ?>).</div>
    <?php elseif (!$prereq_ok): ?>
    <div class="alert alert-error">Cannot upgrade: <?= e($prereq['error']) ?></div>
    <?php else: ?>
    <table class="data">
        <tr>
            <th>Current Level</th>
            <td><?= (int)$building['level'] ?> / <?= $max_level ?></td>
        </tr>
        <tr>
            <th>Upgrade to Level</th>
            <td><?= $next_level ?></td>
        </tr>
        <tr>
            <th>Cost</th>
            <td>
                <span class="res-icon res-wood"></span> <?= format_number($cost['wood']) ?> &nbsp;
                <span class="res-icon res-clay"></span> <?= format_number($cost['clay']) ?> &nbsp;
                <span class="res-icon res-iron"></span> <?= format_number($cost['iron']) ?> &nbsp;
                <span class="res-icon res-crop"></span> <?= format_number($cost['crop']) ?>
            </td>
        </tr>
        <tr>
            <th>Build Time</th>
            <td><?= e(format_seconds($time_sec)) ?></td>
        </tr>
        <tr>
            <th>You have</th>
            <td>
                <span class="res-icon res-wood"></span> <?= format_number($resources['wood']) ?> &nbsp;
                <span class="res-icon res-clay"></span> <?= format_number($resources['clay']) ?> &nbsp;
                <span class="res-icon res-iron"></span> <?= format_number($resources['iron']) ?> &nbsp;
                <span class="res-icon res-crop"></span> <?= format_number($resources['crop']) ?>
            </td>
        </tr>
    </table>

    <form method="POST" style="margin-top:16px;text-align:center;">
        <button type="submit" class="btn btn-gold btn-lg" <?= !$can_afford ? 'disabled' : '' ?>>
            <?= $can_afford ? "Upgrade to Level $next_level" : 'Not Enough Resources' ?>
        </button>
    </form>
    <?php endif; ?>

    <p style="text-align:center;margin-top:16px;">
        <a href="<?= url('/village.php') ?>">← Back to Village</a>
    </p>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
