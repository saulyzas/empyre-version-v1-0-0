<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
session_destroy();
redirect('/');
