-- ============================================================
-- MYEMPIRE - SQLite Schema Dump
-- Compatible with PHP PDO SQLite driver
-- File: sql/schema.sql
-- ============================================================

-- Players (users)
CREATE TABLE IF NOT EXISTS players (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT NOT NULL UNIQUE,
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    tribe           TEXT NOT NULL CHECK(tribe IN ('roman','gaul','teuton')),
    quadrant        TEXT NOT NULL DEFAULT 'NorthEast',
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    last_login      TEXT,
    population      INTEGER NOT NULL DEFAULT 2,
    gold            INTEGER NOT NULL DEFAULT 0
);

-- World map cells (one row per coordinate pair)
CREATE TABLE IF NOT EXISTS map_cells (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    x               INTEGER NOT NULL,
    y               INTEGER NOT NULL,
    terrain         TEXT NOT NULL DEFAULT 'grass',  -- grass, forest, mountain, water, desert
    village_id      INTEGER,
    occupied        INTEGER NOT NULL DEFAULT 0,
    UNIQUE(x, y)
);

-- Villages
CREATE TABLE IF NOT EXISTS villages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    player_id       INTEGER NOT NULL,
    name            TEXT NOT NULL,
    x               INTEGER NOT NULL,
    y               INTEGER NOT NULL,
    is_capital      INTEGER NOT NULL DEFAULT 0,
    loyalty         REAL NOT NULL DEFAULT 100.0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
);

-- Resource stockpile per village
CREATE TABLE IF NOT EXISTS resources (
    village_id      INTEGER PRIMARY KEY,
    wood            REAL NOT NULL DEFAULT 800,
    clay            REAL NOT NULL DEFAULT 800,
    iron            REAL NOT NULL DEFAULT 800,
    crop            REAL NOT NULL DEFAULT 800,
    wood_cap        INTEGER NOT NULL DEFAULT 4000,
    clay_cap        INTEGER NOT NULL DEFAULT 4000,
    iron_cap        INTEGER NOT NULL DEFAULT 4000,
    crop_cap        INTEGER NOT NULL DEFAULT 4000,
    last_update     TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE
);

-- Resource fields (18 per village: 4 wood + 4 clay + 4 iron + 6 crop)
CREATE TABLE IF NOT EXISTS resource_fields (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    village_id      INTEGER NOT NULL,
    field_type      TEXT NOT NULL CHECK(field_type IN ('woodcutter','claypit','ironmine','cropland')),
    position        INTEGER NOT NULL,  -- 0..17
    level           INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE,
    UNIQUE(village_id, position)
);

-- Buildings in village center (positions 0..19, one is the Village Center)
CREATE TABLE IF NOT EXISTS buildings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    village_id      INTEGER NOT NULL,
    position        INTEGER NOT NULL,  -- 0..19
    building_type   TEXT NOT NULL,     -- main_building, warehouse, granary, barracks, etc.
    level           INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE,
    UNIQUE(village_id, position)
);

-- Building / upgrade queue
CREATE TABLE IF NOT EXISTS build_queue (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    village_id      INTEGER NOT NULL,
    target_type     TEXT NOT NULL,        -- building_type or field_type
    target_kind     TEXT NOT NULL,        -- 'building' or 'field'
    position        INTEGER NOT NULL,
    target_level    INTEGER NOT NULL,
    started_at      TEXT NOT NULL DEFAULT (datetime('now')),
    finishes_at     TEXT NOT NULL,
    FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE
);

-- Heroes (one per player)
CREATE TABLE IF NOT EXISTS heroes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    player_id       INTEGER NOT NULL UNIQUE,
    village_id      INTEGER NOT NULL,
    name            TEXT NOT NULL,
    level           INTEGER NOT NULL DEFAULT 1,
    experience      INTEGER NOT NULL DEFAULT 0,
    health          INTEGER NOT NULL DEFAULT 100,
    attack          INTEGER NOT NULL DEFAULT 10,
    defense         INTEGER NOT NULL DEFAULT 10,
    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
);

-- Troops per village
CREATE TABLE IF NOT EXISTS troops (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    village_id      INTEGER NOT NULL,
    unit_type       TEXT NOT NULL,
    count           INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE,
    UNIQUE(village_id, unit_type)
);

-- Training queue (troops being trained at barracks/stable)
CREATE TABLE IF NOT EXISTS training_queue (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    village_id      INTEGER NOT NULL,
    unit_type       TEXT NOT NULL,
    count           INTEGER NOT NULL,
    finishes_at     TEXT NOT NULL,
    FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE
);

-- Troop movements (attacks, reinforcements, returns)
CREATE TABLE IF NOT EXISTS movements (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    from_village_id INTEGER NOT NULL,
    to_village_id   INTEGER NOT NULL,
    type            TEXT NOT NULL CHECK(type IN ('attack','reinforcement','return')),
    troops_json     TEXT NOT NULL DEFAULT '{}',
    loot_json       TEXT NOT NULL DEFAULT '{}',
    started_at      TEXT NOT NULL,
    arrives_at      TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'in_progress' CHECK(status IN ('in_progress','completed')),
    FOREIGN KEY(from_village_id) REFERENCES villages(id) ON DELETE CASCADE,
    FOREIGN KEY(to_village_id)   REFERENCES villages(id) ON DELETE CASCADE
);

-- Reports (battle / operation reports)
CREATE TABLE IF NOT EXISTS reports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    player_id       INTEGER NOT NULL,
    title           TEXT NOT NULL,
    body            TEXT NOT NULL,
    category        TEXT NOT NULL DEFAULT 'general', -- general, combat, trade, reinforcement
    is_read         INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
);

-- Messages between players
CREATE TABLE IF NOT EXISTS messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id       INTEGER NOT NULL,
    recipient_id    INTEGER NOT NULL,
    subject         TEXT NOT NULL,
    body            TEXT NOT NULL,
    is_read         INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY(sender_id) REFERENCES players(id) ON DELETE CASCADE,
    FOREIGN KEY(recipient_id) REFERENCES players(id) ON DELETE CASCADE
);

-- ============================================================
-- Seed data
-- ============================================================

-- Map cells: generate a 200x200 grid around origin (-100..+100)
-- (We don't pre-populate all cells; we use terrain generation on demand.
--  We seed only village center positions on registration.)

-- Unit statistics per tribe
-- Roman
INSERT INTO troops (village_id, unit_type, count) VALUES (0, 'legionnaire', 0);
-- (these are templates only; real troops are inserted per village)

-- Default reports for new players
INSERT INTO reports (player_id, title, body, category) VALUES (0, 'Welcome!', 'Welcome to MYEMPIRE. Start by upgrading your resource fields to gather more resources.', 'general');

-- ============================================================
-- Views for convenience
-- ============================================================
CREATE VIEW IF NOT EXISTS v_player_resources AS
SELECT
    p.id AS player_id,
    p.username,
    v.id AS village_id,
    v.name AS village_name,
    r.wood, r.clay, r.iron, r.crop,
    r.wood_cap, r.clay_cap, r.iron_cap, r.crop_cap
FROM players p
JOIN villages v ON v.player_id = p.id
JOIN resources r ON r.village_id = v.id;

-- ============================================================
-- Triggers: ensure village has 18 fields and 1 main building on insert
-- ============================================================
CREATE TRIGGER IF NOT EXISTS trg_init_village
AFTER INSERT ON villages
BEGIN
    -- Initial resources
    INSERT INTO resources (village_id, wood, clay, iron, crop) VALUES (NEW.id, 800, 800, 800, 800);

    -- 18 resource fields: 4 wood + 4 clay + 4 iron + 6 crop
    INSERT INTO resource_fields (village_id, field_type, position, level)
    VALUES (NEW.id, 'woodcutter', 0, 0), (NEW.id, 'woodcutter', 1, 0),
           (NEW.id, 'woodcutter', 2, 0), (NEW.id, 'woodcutter', 3, 0),
           (NEW.id, 'claypit', 4, 0), (NEW.id, 'claypit', 5, 0),
           (NEW.id, 'claypit', 6, 0), (NEW.id, 'claypit', 7, 0),
           (NEW.id, 'ironmine', 8, 0), (NEW.id, 'ironmine', 9, 0),
           (NEW.id, 'ironmine', 10, 0), (NEW.id, 'ironmine', 11, 0),
           (NEW.id, 'cropland', 12, 0), (NEW.id, 'cropland', 13, 0),
           (NEW.id, 'cropland', 14, 0), (NEW.id, 'cropland', 15, 0),
           (NEW.id, 'cropland', 16, 0), (NEW.id, 'cropland', 17, 0);

    -- Main building at position 0 (village center)
    INSERT INTO buildings (village_id, position, building_type, level)
    VALUES (NEW.id, 0, 'main_building', 1);
END;
