-- ============================================================
-- MYEMPIRE - MySQL/MariaDB Schema Dump
-- Compatible with MySQL 5.7+ / MariaDB 10.2+
-- File: sql/schema_mysql.sql
--
-- Import in phpMyAdmin:
--   1. Create database "myempire" (collation: utf8mb4_unicode_ci)
--   2. Import this file
--   3. Update app/config/config.php to use MySQL (see README)
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET sql_mode = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION';

-- ============================================================
-- Players (users)
-- ============================================================
DROP TABLE IF EXISTS `players`;
CREATE TABLE `players` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `username`        VARCHAR(20) NOT NULL,
    `email`           VARCHAR(255) NOT NULL,
    `password_hash`   VARCHAR(255) NOT NULL,
    `tribe`           ENUM('roman','gaul','teuton') NOT NULL DEFAULT 'roman',
    `quadrant`        VARCHAR(20) NOT NULL DEFAULT 'NorthEast',
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_login`      DATETIME NULL,
    `population`      INT NOT NULL DEFAULT 2,
    `gold`            INT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_players_username` (`username`),
    UNIQUE KEY `uq_players_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- World map cells
-- ============================================================
DROP TABLE IF EXISTS `map_cells`;
CREATE TABLE `map_cells` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `x`               INT NOT NULL,
    `y`               INT NOT NULL,
    `terrain`         ENUM('grass','forest','mountain','water','desert') NOT NULL DEFAULT 'grass',
    `village_id`      INT UNSIGNED NULL,
    `occupied`        TINYINT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_map_cells_xy` (`x`, `y`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Villages
-- ============================================================
DROP TABLE IF EXISTS `villages`;
CREATE TABLE `villages` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `player_id`       INT UNSIGNED NOT NULL,
    `name`            VARCHAR(60) NOT NULL,
    `x`               INT NOT NULL,
    `y`               INT NOT NULL,
    `is_capital`      TINYINT NOT NULL DEFAULT 0,
    `loyalty`         DECIMAL(5,2) NOT NULL DEFAULT 100.00,
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_villages_player` (`player_id`),
    CONSTRAINT `fk_villages_player` FOREIGN KEY (`player_id`)
        REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Resource stockpile per village
-- ============================================================
DROP TABLE IF EXISTS `resources`;
CREATE TABLE `resources` (
    `village_id`      INT UNSIGNED NOT NULL,
    `wood`            DECIMAL(12,2) NOT NULL DEFAULT 800.00,
    `clay`            DECIMAL(12,2) NOT NULL DEFAULT 800.00,
    `iron`            DECIMAL(12,2) NOT NULL DEFAULT 800.00,
    `crop`            DECIMAL(12,2) NOT NULL DEFAULT 800.00,
    `wood_cap`        INT NOT NULL DEFAULT 4000,
    `clay_cap`        INT NOT NULL DEFAULT 4000,
    `iron_cap`        INT NOT NULL DEFAULT 4000,
    `crop_cap`        INT NOT NULL DEFAULT 4000,
    `last_update`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`village_id`),
    CONSTRAINT `fk_resources_village` FOREIGN KEY (`village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Resource fields (18 per village)
-- ============================================================
DROP TABLE IF EXISTS `resource_fields`;
CREATE TABLE `resource_fields` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `village_id`      INT UNSIGNED NOT NULL,
    `field_type`      ENUM('woodcutter','claypit','ironmine','cropland') NOT NULL,
    `position`        TINYINT UNSIGNED NOT NULL,
    `level`           TINYINT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_rf_village_pos` (`village_id`, `position`),
    CONSTRAINT `fk_rf_village` FOREIGN KEY (`village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Buildings in village center
-- ============================================================
DROP TABLE IF EXISTS `buildings`;
CREATE TABLE `buildings` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `village_id`      INT UNSIGNED NOT NULL,
    `position`        TINYINT UNSIGNED NOT NULL,
    `building_type`   VARCHAR(30) NOT NULL,
    `level`           TINYINT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_b_village_pos` (`village_id`, `position`),
    CONSTRAINT `fk_b_village` FOREIGN KEY (`village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Building / upgrade queue
-- ============================================================
DROP TABLE IF EXISTS `build_queue`;
CREATE TABLE `build_queue` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `village_id`      INT UNSIGNED NOT NULL,
    `target_type`     VARCHAR(30) NOT NULL,
    `target_kind`     ENUM('building','field') NOT NULL,
    `position`        TINYINT UNSIGNED NOT NULL,
    `target_level`    TINYINT NOT NULL,
    `started_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `finishes_at`     DATETIME NOT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_bq_village` (`village_id`),
    KEY `idx_bq_finishes` (`finishes_at`),
    CONSTRAINT `fk_bq_village` FOREIGN KEY (`village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Heroes
-- ============================================================
DROP TABLE IF EXISTS `heroes`;
CREATE TABLE `heroes` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `player_id`       INT UNSIGNED NOT NULL,
    `village_id`      INT UNSIGNED NOT NULL,
    `name`            VARCHAR(30) NOT NULL,
    `level`           INT NOT NULL DEFAULT 1,
    `experience`      INT NOT NULL DEFAULT 0,
    `health`          INT NOT NULL DEFAULT 100,
    `attack`          INT NOT NULL DEFAULT 10,
    `defense`         INT NOT NULL DEFAULT 10,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_heroes_player` (`player_id`),
    CONSTRAINT `fk_heroes_player` FOREIGN KEY (`player_id`)
        REFERENCES `players` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_heroes_village` FOREIGN KEY (`village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Troops per village
-- ============================================================
DROP TABLE IF EXISTS `troops`;
CREATE TABLE `troops` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `village_id`      INT UNSIGNED NOT NULL,
    `unit_type`       VARCHAR(40) NOT NULL,
    `count`           INT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_troops_village_unit` (`village_id`, `unit_type`),
    CONSTRAINT `fk_troops_village` FOREIGN KEY (`village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Training queue (troops being trained at barracks/stable)
-- ============================================================
DROP TABLE IF EXISTS `training_queue`;
CREATE TABLE `training_queue` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `village_id`      INT UNSIGNED NOT NULL,
    `unit_type`       VARCHAR(40) NOT NULL,
    `count`           INT NOT NULL,
    `finishes_at`     DATETIME NOT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_tq_village` (`village_id`),
    KEY `idx_tq_finishes` (`finishes_at`),
    CONSTRAINT `fk_tq_village` FOREIGN KEY (`village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Troop movements (attacks, reinforcements, returns)
-- ============================================================
DROP TABLE IF EXISTS `movements`;
CREATE TABLE `movements` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `from_village_id` INT UNSIGNED NOT NULL,
    `to_village_id`   INT UNSIGNED NOT NULL,
    `type`            ENUM('attack','reinforcement','return') NOT NULL,
    `troops_json`     TEXT NOT NULL,
    `loot_json`       TEXT NOT NULL DEFAULT '{}',
    `started_at`      DATETIME NOT NULL,
    `arrives_at`      DATETIME NOT NULL,
    `status`          ENUM('in_progress','completed') NOT NULL DEFAULT 'in_progress',
    PRIMARY KEY (`id`),
    KEY `idx_mov_from` (`from_village_id`),
    KEY `idx_mov_to` (`to_village_id`),
    KEY `idx_mov_arrives` (`arrives_at`),
    CONSTRAINT `fk_mov_from` FOREIGN KEY (`from_village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_mov_to` FOREIGN KEY (`to_village_id`)
        REFERENCES `villages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Reports
-- ============================================================
DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `player_id`       INT UNSIGNED NOT NULL,
    `title`           VARCHAR(120) NOT NULL,
    `body`            TEXT NOT NULL,
    `category`        ENUM('general','combat','trade','reinforcement') NOT NULL DEFAULT 'general',
    `is_read`         TINYINT NOT NULL DEFAULT 0,
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_reports_player` (`player_id`),
    CONSTRAINT `fk_reports_player` FOREIGN KEY (`player_id`)
        REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Messages between players
-- ============================================================
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sender_id`       INT UNSIGNED NOT NULL,
    `recipient_id`    INT UNSIGNED NOT NULL,
    `subject`         VARCHAR(120) NOT NULL,
    `body`            TEXT NOT NULL,
    `is_read`         TINYINT NOT NULL DEFAULT 0,
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_messages_recipient` (`recipient_id`),
    KEY `idx_messages_sender` (`sender_id`),
    CONSTRAINT `fk_messages_sender` FOREIGN KEY (`sender_id`)
        REFERENCES `players` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_messages_recipient` FOREIGN KEY (`recipient_id`)
        REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Triggers (MySQL syntax) — keep village initialization atomic
-- ============================================================
DELIMITER //

DROP TRIGGER IF EXISTS trg_init_village //
CREATE TRIGGER trg_init_village
AFTER INSERT ON `villages`
FOR EACH ROW
BEGIN
    -- Initial resources
    INSERT INTO `resources` (`village_id`, `wood`, `clay`, `iron`, `crop`)
    VALUES (NEW.id, 800, 800, 800, 800);

    -- 18 resource fields: 4 wood + 4 clay + 4 iron + 6 crop
    INSERT INTO `resource_fields` (`village_id`, `field_type`, `position`, `level`) VALUES
        (NEW.id, 'woodcutter', 0,  0),
        (NEW.id, 'woodcutter', 1,  0),
        (NEW.id, 'woodcutter', 2,  0),
        (NEW.id, 'woodcutter', 3,  0),
        (NEW.id, 'claypit',    4,  0),
        (NEW.id, 'claypit',    5,  0),
        (NEW.id, 'claypit',    6,  0),
        (NEW.id, 'claypit',    7,  0),
        (NEW.id, 'ironmine',   8,  0),
        (NEW.id, 'ironmine',   9,  0),
        (NEW.id, 'ironmine',   10, 0),
        (NEW.id, 'ironmine',   11, 0),
        (NEW.id, 'cropland',   12, 0),
        (NEW.id, 'cropland',   13, 0),
        (NEW.id, 'cropland',   14, 0),
        (NEW.id, 'cropland',   15, 0),
        (NEW.id, 'cropland',   16, 0),
        (NEW.id, 'cropland',   17, 0);

    -- Main building at position 0 (village center)
    INSERT INTO `buildings` (`village_id`, `position`, `building_type`, `level`)
    VALUES (NEW.id, 0, 'main_building', 1);
END//

DELIMITER ;

-- ============================================================
-- View (MySQL-compatible)
-- ============================================================
DROP VIEW IF EXISTS `v_player_resources`;
CREATE VIEW `v_player_resources` AS
SELECT
    p.id AS player_id,
    p.username,
    v.id AS village_id,
    v.name AS village_name,
    r.wood, r.clay, r.iron, r.crop,
    r.wood_cap, r.clay_cap, r.iron_cap, r.crop_cap
FROM players p
JOIN villages v ON v.player_id = p.id
JOIN resources r ON r.village_id = v.id;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- End of schema
-- ============================================================
