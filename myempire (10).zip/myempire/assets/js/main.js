/* MYEMPIRE - main JavaScript */

// Live clock
function updateClock() {
    const el = document.getElementById('server-time');
    if (!el) return;
    const now = new Date();
    el.textContent = now.toLocaleTimeString('en-GB');
}
setInterval(updateClock, 1000);

// Live resource ticker
function updateResources() {
    const rates = {
        wood: parseFloat(document.getElementById('prod-wood')?.textContent || 0) / 3600,
        clay: parseFloat(document.getElementById('prod-clay')?.textContent || 0) / 3600,
        iron: parseFloat(document.getElementById('prod-iron')?.textContent || 0) / 3600,
        crop: parseFloat(document.getElementById('prod-crop')?.textContent || 0) / 3600,
    };
    const caps = {
        wood: parseInt(document.querySelector('[data-res="wood"]')?.nextElementSibling?.textContent.replace(/\D/g,'') || 0),
        clay: parseInt(document.querySelector('[data-res="clay"]')?.nextElementSibling?.textContent.replace(/\D/g,'') || 0),
        iron: parseInt(document.querySelector('[data-res="iron"]')?.nextElementSibling?.textContent.replace(/\D/g,'') || 0),
        crop: parseInt(document.querySelector('[data-res="crop"]')?.nextElementSibling?.textContent.replace(/\D/g,'') || 0),
    };
    Object.keys(rates).forEach(res => {
        const el = document.querySelector(`[data-res="${res}"]`);
        if (!el) return;
        const cur = parseFloat(el.textContent) || 0;
        const next = Math.min(caps[res], cur + rates[res]);
        el.textContent = Math.floor(next).toLocaleString('en-US');
    });
}
setInterval(updateResources, 1000);

// Build queue countdown
function updateBuildTimers() {
    document.querySelectorAll('[data-finishes-at]').forEach(el => {
        let finishes = el.dataset.finishesAt;
        // Parse the timestamp robustly. PHP gives us 'Y-m-d H:i:s' in server timezone.
        // We convert it to a Date by replacing space with 'T' and adding the server
        // timezone offset (we read this from the data attribute 'data-tz-offset' if present,
        // otherwise we treat it as local time).
        let finishMs;
        if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}/.test(finishes)) {
            // ISO-ish: 'Y-m-d H:i:s' or 'Y-m-d\TH:i:s'
            // Replace space with T for ISO compatibility, treat as local time.
            const iso = finishes.replace(' ', 'T');
            finishMs = new Date(iso).getTime();
        } else {
            // Fallback: assume it's already an epoch-ms string
            finishMs = parseInt(finishes, 10);
        }
        const now = Date.now();
        const remaining = Math.max(0, Math.floor((finishMs - now) / 1000));
        if (remaining === 0) {
            // Reload to reflect completion (but only every 3s to avoid spamming)
            if (!el.dataset.reloading) {
                el.dataset.reloading = '1';
                setTimeout(() => location.reload(), 3000);
            }
            el.textContent = 'Done!';
        } else {
            const h = Math.floor(remaining / 3600);
            const m = Math.floor((remaining % 3600) / 60);
            const s = remaining % 60;
            el.textContent = h > 0 ? `${h}h ${m}m ${s}s` : `${m}m ${s}s`;
        }
    });
}
setInterval(updateBuildTimers, 1000);

// Toast helper
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// AJAX helper
async function apiCall(url, method = 'POST', data = {}) {
    const formData = new FormData();
    Object.keys(data).forEach(k => formData.append(k, data[k]));
    const resp = await fetch(url, { method, body: formData });
    return resp.json();
}

// Tribe selection on register
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.tribe-card').forEach(card => {
        card.addEventListener('click', () => {
            document.querySelectorAll('.tribe-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            const input = document.getElementById('tribe-input');
            if (input) input.value = card.dataset.tribe;
        });
    });
});
