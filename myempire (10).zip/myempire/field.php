<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

// Find the field
$pos = (int)($_GET['id'] ?? -1);
$fields = get_resource_fields($village['id']);
$fields_by_pos = [];
foreach ($fields as $f) $fields_by_pos[$f['position']] = $f;

$field = $fields_by_pos[$pos] ?? null;
if (!$field) {
    redirect('/resources.php');
}

$next_level = $field['level'] + 1;
$cost = calc_field_cost($field['field_type'], $next_level);
$time_sec = calc_field_time($next_level, 1);
$can_afford = ($resources['wood'] >= $cost['wood'] && $resources['clay'] >= $cost['clay']
            && $resources['iron'] >= $cost['iron'] && $resources['crop'] >= $cost['crop']);
$is_max = $field['level'] >= MAX_RESOURCE_LEVEL;

// Handle upgrade
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_max && $can_afford) {
    $result = enqueue_build($village['id'], 'field', $field['field_type'], $field['position'], $next_level, $cost, $time_sec);
    if ($result['ok']) {
        redirect('/resources.php');
    } else {
        $error = $result['error'];
    }
}
$error = $error ?? '';

$page_title = 'Upgrade Field';
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:600px;margin:0 auto;">
    <div class="card-header"><?= e(ucfirst(str_replace('_', ' ', $field['field_type']))) ?> (Level <?= (int)$field['level'] ?>)</div>

    <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;">
        <img src="<?= img_url("resources/{$field['field_type']}_{$field['level']}.png") ?>"
             alt="<?= e($field['field_type']) ?>" style="width:128px;height:128px;image-rendering:pixelated;border:3px solid var(--c-outline);border-radius:8px;">
        <div style="flex:1;">
            <?php
            $field_names = [
                'woodcutter' => 'Woodcutter',
                'claypit'    => 'Clay Pit',
                'ironmine'   => 'Iron Mine',
                'cropland'   => 'Cropland',
            ];
            $produces = [
                'woodcutter' => 'Wood',
                'claypit'    => 'Clay',
                'ironmine'   => 'Iron',
                'cropland'   => 'Crop',
            ];
            $name = $field_names[$field['field_type']];
            $prod_resource = $produces[$field['field_type']];
            ?>
            <h3 style="color:var(--c-wood-dk);margin-bottom:4px;"><?= e($name) ?></h3>
            <p style="font-size:13px;color:var(--c-text-soft);">
                Produces <strong><?= e($prod_resource) ?></strong> for your village.
                Current production at level <?= (int)$field['level'] ?>:
                <strong><?= (int)(($GLOBALS['FIELD_PRODUCTION'][$field['level']] ?? 0) * GAME_SERVER_SPEED) ?>/hour</strong>
            </p>
            <?php if (!$is_max): ?>
            <p style="font-size:13px;margin-top:8px;">
                At level <?= $next_level ?>: 
                <strong><?= (int)(($GLOBALS['FIELD_PRODUCTION'][$next_level] ?? 0) * GAME_SERVER_SPEED) ?>/hour</strong>
                (+<?= (int)((($GLOBALS['FIELD_PRODUCTION'][$next_level] ?? 0) - ($GLOBALS['FIELD_PRODUCTION'][$field['level']] ?? 0)) * GAME_SERVER_SPEED) ?>/hour)
            </p>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($is_max): ?>
    <div class="alert alert-info">This field has reached the maximum level.</div>
    <?php else: ?>
    <table class="data">
        <tr>
            <th>Upgrade to Level</th>
            <td><?= $next_level ?></td>
        </tr>
        <tr>
            <th>Cost</th>
            <td>
                <span class="res-icon res-wood"></span> <?= format_number($cost['wood']) ?> &nbsp;
                <span class="res-icon res-clay"></span> <?= format_number($cost['clay']) ?> &nbsp;
                <span class="res-icon res-iron"></span> <?= format_number($cost['iron']) ?> &nbsp;
                <span class="res-icon res-crop"></span> <?= format_number($cost['crop']) ?>
            </td>
        </tr>
        <tr>
            <th>Build Time</th>
            <td><?= e(format_seconds($time_sec)) ?></td>
        </tr>
        <tr>
            <th>You have</th>
            <td>
                <span class="res-icon res-wood"></span> <?= format_number($resources['wood']) ?> &nbsp;
                <span class="res-icon res-clay"></span> <?= format_number($resources['clay']) ?> &nbsp;
                <span class="res-icon res-iron"></span> <?= format_number($resources['iron']) ?> &nbsp;
                <span class="res-icon res-crop"></span> <?= format_number($resources['crop']) ?>
            </td>
        </tr>
    </table>

    <form method="POST" style="margin-top:16px;text-align:center;">
        <button type="submit" class="btn btn-gold btn-lg" <?= !$can_afford ? 'disabled' : '' ?>>
            <?= $can_afford ? "Upgrade to Level $next_level" : 'Not Enough Resources' ?>
        </button>
    </form>
    <?php endif; ?>

    <p style="text-align:center;margin-top:16px;">
        <a href="<?= url('/resources.php') ?>">← Back to Fields</a>
    </p>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
