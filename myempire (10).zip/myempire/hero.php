<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$player = current_player();
$village = current_village();
$hero = db()->fetch("SELECT * FROM heroes WHERE player_id = ?", [$player['id']]);

// Hero name change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hero_name'])) {
    $new_name = trim($_POST['hero_name']);
    if (strlen($new_name) >= 2 && strlen($new_name) <= 30) {
        db()->update('heroes', ['name' => $new_name], 'id = :hid', ['hid' => $hero['id']]);
        redirect('/hero.php');
    }
}

// Hero stats
$xp_for_next = $hero['level'] * 100;
$xp_pct = min(100, ($hero['experience'] / $xp_for_next) * 100);
$hp_pct = $hero['health'];

$tribe = $player['tribe'];
$available_units = $GLOBALS['UNITS'][$tribe] ?? [];

$page_title = 'Hero';
require __DIR__ . '/app/views/header.php';
?>

<div class="grid grid-2">
    <div>
        <div class="card" style="background:linear-gradient(135deg,#5a4a80 0%,#324d80 100%);color:#fff;">
            <div class="card-header" style="background:rgba(0,0,0,0.3);color:#fff;border-color:#231612;">
                <?= e($hero['name']) ?> — Hero (Level <?= (int)$hero['level'] ?>)
            </div>
            <div style="display:flex;gap:16px;align-items:center;">
                <img src="<?= img_url("troops/hero_{$tribe}.png") ?>" alt="Hero"
                     style="width:128px;height:128px;border:3px solid #fff;border-radius:8px;background:#8a5faf;image-rendering:pixelated;">
                <div style="flex:1;">
                    <p style="margin-bottom:8px;">
                        <strong>Tribe:</strong> <?= e(ucfirst($tribe)) ?><br>
                        <strong>Village:</strong> <?= e($village['name']) ?>
                    </p>
                    <div style="margin-bottom:6px;">
                        <div style="font-size:11px;margin-bottom:2px;">Health: <?= (int)$hero['health'] ?>/100</div>
                        <div class="stat-bar"><div class="stat-bar-fill" style="width: <?= $hp_pct ?>%;background:linear-gradient(90deg,#c84541,#8e2a26);"></div></div>
                    </div>
                    <div style="margin-bottom:6px;">
                        <div style="font-size:11px;margin-bottom:2px;">Experience: <?= (int)$hero['experience'] ?>/<?= $xp_for_next ?></div>
                        <div class="stat-bar"><div class="stat-bar-fill" style="width: <?= $xp_pct ?>%;background:linear-gradient(90deg,#f0c34b,#b88e28);"></div></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">Hero Attributes</div>
            <table class="data">
                <tr>
                    <th>Level</th>
                    <td><?= (int)$hero['level'] ?></td>
                </tr>
                <tr>
                    <th>Experience</th>
                    <td><?= (int)$hero['experience'] ?> / <?= $xp_for_next ?></td>
                </tr>
                <tr>
                    <th>Attack</th>
                    <td><?= (int)$hero['attack'] ?></td>
                </tr>
                <tr>
                    <th>Defense</th>
                    <td><?= (int)$hero['defense'] ?></td>
                </tr>
                <tr>
                    <th>Health</th>
                    <td><?= (int)$hero['health'] ?> / 100</td>
                </tr>
            </table>
        </div>

        <div class="card">
            <div class="card-header">Rename Hero</div>
            <form method="POST">
                <div class="form-group">
                    <label>New Hero Name</label>
                    <input type="text" name="hero_name" class="form-control" maxlength="30" value="<?= e($hero['name']) ?>">
                </div>
                <button type="submit" class="btn btn-gold">Rename</button>
            </form>
        </div>
    </div>

    <div>
        <div class="panel">
            <div class="panel-title">Tribe Units</div>
            <p style="font-size:11px;color:var(--c-text-soft);margin-bottom:8px;">
                Train these units at your Barracks (infantry) or Stable (cavalry).
            </p>
            <table class="data" style="font-size:11px;">
                <thead>
                    <tr>
                        <th>Unit</th>
                        <th>Atk</th>
                        <th>Def</th>
                        <th>Spd</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($available_units as $key => $u): ?>
                <tr>
                    <td style="display:flex;align-items:center;gap:4px;">
                        <img src="<?= img_url("troops/{$tribe}_{$key}.png") ?>" width="24" height="24" style="image-rendering:pixelated;" alt="">
                        <span title="<?= e($u['name']) ?>"><?= e($u['name']) ?></span>
                    </td>
                    <td><?= (int)$u['attack'] ?></td>
                    <td><?= (int)$u['def_inf'] ?>/<?= (int)$u['def_cav'] ?></td>
                    <td><?= (int)$u['speed'] ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="panel">
            <div class="panel-title">Hero Tip</div>
            <p style="font-size:12px;">
                Your hero leads armies into battle and gains experience from victories. Build a 
                <strong>Hero Mansion</strong> to manage your hero's equipment and abilities.
                Higher mansion levels unlock more hero slots and quests.
            </p>
        </div>

        <div class="panel">
            <div class="panel-title">Available Buildings</div>
            <ul style="list-style:none;font-size:12px;">
                <li><a href="<?= url('/build.php?id=9') ?>">🏛 Hero Mansion (slot 9)</a></li>
                <li><a href="<?= url('/build.php?id=3') ?>">⚔ Barracks</a></li>
                <li><a href="<?= url('/build.php?id=4') ?>">🐎 Stable</a></li>
                <li><a href="<?= url('/build.php?id=10') ?>">🔨 Smithy</a></li>
            </ul>
        </div>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
