<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);
$production = production_per_hour($village['id']);
$fields = get_resource_fields($village['id']);
$queue = get_build_queue($village['id']);

// Build a lookup of fields by position
$fields_by_pos = [];
foreach ($fields as $f) $fields_by_pos[$f['position']] = $f;

global $FIELD_LAYOUT;

$page_title = 'Resource Fields';
require __DIR__ . '/app/views/header.php';
?>

<div class="grid grid-2">
    <div>
        <div class="card">
            <div class="card-header">
                <?= e($village['name']) ?> 
                <span style="font-weight:normal;color:var(--c-text-soft);font-size:13px;">(<?= (int)$village['x'] ?>|<?= (int)$village['y'] ?>)</span>
            </div>

            <div style="display:flex;gap:12px;font-size:12px;color:var(--c-text-soft);margin-bottom:12px;">
                <span><img src="<?= img_url('misc/loyalty.png') ?>" width="14" height="14" alt=""> Loyalty: <?= (int)$village['loyalty'] ?>%</span>
                <?php if ($village['is_capital']): ?>
                <span><img src="<?= img_url('misc/capital.png') ?>" width="14" height="14" alt=""> Capital</span>
                <?php endif; ?>
            </div>

            <!-- SVG resource map -->
            <div class="resources-map">
                <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
                    <!-- Background terrain -->
                    <defs>
                        <radialGradient id="bg-grad" cx="50%" cy="50%" r="60%">
                            <stop offset="0%" stop-color="#a8c87a"/>
                            <stop offset="100%" stop-color="#6a9550"/>
                        </radialGradient>
                    </defs>
                    <rect x="0" y="0" width="100" height="100" fill="url(#bg-grad)" rx="4"/>

                    <!-- Village Center in the middle -->
                    <g transform="translate(50, 50)">
                        <circle r="6" fill="#8c5532" stroke="#231612" stroke-width="1"/>
                        <polygon points="-5,-3 0,-7 5,-3" fill="#c84541" stroke="#231612" stroke-width="0.5"/>
                        <text y="2" text-anchor="middle" font-size="3" fill="#fff" font-weight="bold">HQ</text>
                    </g>

                    <!-- Resource fields -->
                    <?php foreach ($FIELD_LAYOUT as $pos => [$type, $x, $y]):
                        $field = $fields_by_pos[$pos] ?? null;
                        $level = $field['level'] ?? 0;
                        $img = "resources/{$type}_{$level}.png";
                        // Determine color based on type
                        $color = [
                            'woodcutter' => '#6a8d3e',
                            'claypit'    => '#c87348',
                            'ironmine'   => '#7d7d8e',
                            'cropland'   => '#d8a83a',
                        ][$type];
                    ?>
                    <a href="<?= url('/field.php') . '?id=' . (int)$pos ?>" class="field-tile">
                        <g transform="translate(<?= $x ?>, <?= $y ?>)">
                            <circle r="6" fill="<?= $color ?>" stroke="#231612" stroke-width="0.8" opacity="0.95"/>
                            <circle r="4" fill="#fff" opacity="0.3"/>
                            <!-- Field-type glyph -->
                            <text y="1.5" text-anchor="middle" font-size="4" fill="#fff" font-weight="bold">
                                <?= strtoupper(substr($type, 0, 1)) ?>
                            </text>
                            <!-- Level badge -->
                            <circle cx="4" cy="4" r="2.2" fill="#f0c34b" stroke="#231612" stroke-width="0.4"/>
                            <text x="4" y="5" text-anchor="middle" font-size="2.5" fill="#231612" font-weight="bold"><?= $level ?></text>
                        </g>
                    </a>
                    <?php endforeach; ?>
                </svg>
            </div>
        </div>

        <div class="card">
            <div class="card-header">Building Queue</div>
            <?php if (empty($queue)): ?>
            <p style="color:var(--c-text-soft);">The queue is currently empty.</p>
            <?php else: ?>
            <?php foreach ($queue as $item): ?>
            <div class="queue-item">
                <img src="<?= img_url('ui/queue_icon.png') ?>" width="20" height="20" alt="">
                <span class="queue-name">
                    <?= e(ucfirst(str_replace('_', ' ', $item['target_type']))) ?> → Level <?= (int)$item['target_level'] ?>
                </span>
                <span class="queue-timer" data-finishes-at="<?= e($item['finishes_at']) ?>">...</span>
                <a href="<?= url('/cancel_build.php') ?>?id=<?= (int)$item['id'] ?>" class="queue-cancel" onclick="return confirm('Cancel this build?')">✕</a>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Sidebar -->
    <div>
        <div class="panel">
            <div class="panel-title">Villages</div>
            <ul style="list-style:none;">
                <li>
                    <a href="<?= url('/village.php') ?>"><?= e($village['name']) ?></a><br>
                    <span style="font-size:11px;color:var(--c-text-soft);"><?= (int)$village['x'] ?>|<?= (int)$village['y'] ?></span>
                </li>
            </ul>
        </div>

        <div class="panel">
            <div class="panel-title">Production / hour</div>
            <div style="display:flex;justify-content:space-between;font-size:13px;">
                <span><span class="res-icon res-wood"></span> Wood</span>
                <strong><?= (int)$production['wood'] ?></strong>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:13px;">
                <span><span class="res-icon res-clay"></span> Clay</span>
                <strong><?= (int)$production['clay'] ?></strong>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:13px;">
                <span><span class="res-icon res-iron"></span> Iron</span>
                <strong><?= (int)$production['iron'] ?></strong>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:13px;">
                <span><span class="res-icon res-crop"></span> Crop</span>
                <strong><?= (int)$production['crop'] ?></strong>
            </div>
        </div>

        <div class="panel">
            <div class="panel-title">Current Troops</div>
            <?php
            $hero = db()->fetch("SELECT * FROM heroes WHERE village_id = ?", [$village['id']]);
            if ($hero):
                $player = current_player();
            ?>
            <div style="display:flex;align-items:center;gap:8px;">
                <img src="<?= img_url("troops/hero_{$player['tribe']}.png") ?>" alt="Hero" width="32" height="32" style="image-rendering:pixelated;">
                <strong><?= e($hero['name']) ?></strong> (Hero, Lvl <?= (int)$hero['level'] ?>)
            </div>
            <?php else: ?>
            <p style="font-size:11px;color:var(--c-text-soft);">No troops stationed here.</p>
            <?php endif; ?>
        </div>

        <div class="panel">
            <div class="panel-title">Field Guide</div>
            <table class="data" style="font-size:11px;">
                <tr><th>Tile</th><th>Produces</th></tr>
                <tr><td><strong>W</strong> Woodcutter</td><td>Wood</td></tr>
                <tr><td><strong>C</strong> Clay Pit</td><td>Clay</td></tr>
                <tr><td><strong>I</strong> Iron Mine</td><td>Iron</td></tr>
                <tr><td><strong>D</strong> Cropland</td><td>Crop</td></tr>
            </table>
            <p style="font-size:11px;margin-top:8px;color:var(--c-text-soft);">Click any tile on the map to upgrade it.</p>
        </div>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
