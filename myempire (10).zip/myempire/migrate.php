<?php
/**
 * MYEMPIRE - Migration script.
 *
 * Run this once after updating from a previous version.
 * It adds new tables (training_queue, movements) without touching existing data.
 *
 * Usage:
 *   - Open http://localhost/myempire/migrate.php in your browser, OR
 *   - Run from CLI:  php migrate.php
 *
 * After successful migration, you can delete this file.
 */
require_once __DIR__ . '/app/lib/helpers.php';
init_session();

echo "<!DOCTYPE html><html><head><title>MYEMPIRE Migration</title>";
echo "<style>body{font-family:sans-serif;padding:40px;background:#f4ead5;color:#2a1f15;}";
echo ".ok{color:#4a7a3a;font-weight:bold;} .err{color:#8e2a26;font-weight:bold;}";
echo "pre{background:#2a1f15;color:#fdf6e3;padding:8px;border-radius:4px;}</style></head><body>";
echo "<h1>MYEMPIRE Migration</h1>";

$db = db();

// Detect driver
$driver = $db->pdo()->getAttribute(PDO::ATTR_DRIVER_NAME);
echo "<p>Database driver: <strong>$driver</strong></p>";

// List of new tables to add (idempotent — uses CREATE TABLE IF NOT EXISTS)
$migrations = [];

if ($driver === 'sqlite') {
    $migrations = [
        'training_queue' => "CREATE TABLE IF NOT EXISTS training_queue (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            village_id      INTEGER NOT NULL,
            unit_type       TEXT NOT NULL,
            count           INTEGER NOT NULL,
            finishes_at     TEXT NOT NULL,
            FOREIGN KEY(village_id) REFERENCES villages(id) ON DELETE CASCADE
        )",
        'movements' => "CREATE TABLE IF NOT EXISTS movements (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            from_village_id INTEGER NOT NULL,
            to_village_id   INTEGER NOT NULL,
            type            TEXT NOT NULL CHECK(type IN ('attack','reinforcement','return')),
            troops_json     TEXT NOT NULL DEFAULT '{}',
            loot_json       TEXT NOT NULL DEFAULT '{}',
            started_at      TEXT NOT NULL,
            arrives_at      TEXT NOT NULL,
            status          TEXT NOT NULL DEFAULT 'in_progress' CHECK(status IN ('in_progress','completed')),
            FOREIGN KEY(from_village_id) REFERENCES villages(id) ON DELETE CASCADE,
            FOREIGN KEY(to_village_id)   REFERENCES villages(id) ON DELETE CASCADE
        )",
    ];
} elseif ($driver === 'mysql') {
    $migrations = [
        'training_queue' => "CREATE TABLE IF NOT EXISTS `training_queue` (
            `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `village_id`      INT UNSIGNED NOT NULL,
            `unit_type`       VARCHAR(40) NOT NULL,
            `count`           INT NOT NULL,
            `finishes_at`     DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_tq_village` (`village_id`),
            CONSTRAINT `fk_tq_village` FOREIGN KEY (`village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'movements' => "CREATE TABLE IF NOT EXISTS `movements` (
            `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `from_village_id` INT UNSIGNED NOT NULL,
            `to_village_id`   INT UNSIGNED NOT NULL,
            `type`            ENUM('attack','reinforcement','return') NOT NULL,
            `troops_json`     TEXT NOT NULL,
            `loot_json`       TEXT NOT NULL,
            `started_at`      DATETIME NOT NULL,
            `arrives_at`      DATETIME NOT NULL,
            `status`          ENUM('in_progress','completed') NOT NULL DEFAULT 'in_progress',
            PRIMARY KEY (`id`),
            KEY `idx_mov_from` (`from_village_id`),
            KEY `idx_mov_to` (`to_village_id`),
            CONSTRAINT `fk_mov_from` FOREIGN KEY (`from_village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_mov_to` FOREIGN KEY (`to_village_id`)
                REFERENCES `villages` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
}

$ok_count = 0;
$err_count = 0;

foreach ($migrations as $name => $sql) {
    echo "<h3>Table: $name</h3>";
    try {
        $db->pdo()->exec($sql);
        echo "<p class='ok'>✓ Created (or already exists).</p>";
        $ok_count++;
    } catch (Throwable $e) {
        echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<pre>" . htmlspecialchars($sql) . "</pre>";
        $err_count++;
    }
}

// Also recalculate population for all existing villages
echo "<h3>Recalculate Population</h3>";
try {
    $villages = $db->fetchAll("SELECT id, player_id FROM villages");
    foreach ($villages as $v) {
        $pop = recalculate_population($v['id']);
        echo "<p class='ok'>✓ Village #{$v['id']}: population set to $pop</p>";
    }
    $ok_count++;
} catch (Throwable $e) {
    echo "<p class='err'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    $err_count++;
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p class='ok'>$ok_count OK</p>";
if ($err_count > 0) echo "<p class='err'>$err_count errors</p>";

echo "<p style='margin-top:24px;'><a href='" . url('/') . "'>← Back to game</a></p>";
echo "<p style='font-size:12px;color:#5a4a30;margin-top:16px;'>You can now safely delete migrate.php.</p>";
echo "</body></html>";
