<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);

// Find slot
$pos = (int)($_GET['id'] ?? -1);
$buildings = get_buildings($village['id']);
$buildings_by_pos = [];
foreach ($buildings as $b) $buildings_by_pos[$b['position']] = $b;

// Don't allow building on existing slot
if (isset($buildings_by_pos[$pos]) && $buildings_by_pos[$pos]['building_type']) {
    redirect('/building.php?id=' . $pos);
}

$available = available_buildings();
$main_level = $buildings_by_pos[0]['level'] ?? 1;

// Handle build request
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['building_type'] ?? '';
    if (!isset($available[$type])) {
        $error = 'Invalid building type.';
    } else {
        // Check prerequisites
        $prereq = check_building_prerequisites($type, $village['id']);
        if (!$prereq['ok']) {
            $error = $prereq['error'];
        } elseif (building_already_exists($type, $village['id'], $pos)) {
            // Check uniqueness
            $error = 'You already have a ' . e($available[$type]) . ' in this village. Each village can have only one.';
        } else {
            $cost = calc_building_cost($type, 1);
            $time_sec = calc_building_time($type, 1, $main_level);
            $result = enqueue_build($village['id'], 'building', $type, $pos, 1, $cost, $time_sec);
            if ($result['ok']) {
                redirect('/village.php');
            } else {
                $error = $result['error'];
            }
        }
    }
}

$page_title = 'Build';
require __DIR__ . '/app/views/header.php';
?>

<div class="card" style="max-width:760px;margin:0 auto;">
    <div class="card-header">Choose Building to Construct (Slot <?= $pos ?>)</div>

    <?php if ($error): ?>
    <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php
    // Get current building levels for prerequisite checks
    $current_levels = [];
    foreach ($buildings as $b) {
        $current_levels[$b['building_type']] = max($current_levels[$b['building_type']] ?? 0, (int)$b['level']);
    }
    ?>

    <table class="data">
        <thead>
            <tr>
                <th>Building</th>
                <th>Requires</th>
                <th>Cost</th>
                <th>Time</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $shown_any = false;
        foreach ($available as $type => $name):
            // Skip if already built (unique buildings)
            $already_built = building_already_exists($type, $village['id'], $pos);
            if ($already_built) continue;

            $shown_any = true;
            $cost = calc_building_cost($type, 1);
            $time = calc_building_time($type, 1, $main_level);
            $prereq = check_building_prerequisites($type, $village['id']);
            $prereq_ok = $prereq['ok'];

            $can_afford = ($resources['wood'] >= $cost['wood'] && $resources['clay'] >= $cost['clay']
                        && $resources['iron'] >= $cost['iron'] && $resources['crop'] >= $cost['crop']);
            $can_build = $prereq_ok && $can_afford;

            // Format prerequisites text
            global $BUILDING_PREREQUISITES;
            $reqs = $BUILDING_PREREQUISITES[$type] ?? [];
            $req_text = '';
            if (empty($reqs)) {
                $req_text = '<span style="color:#4a7a3a;">None</span>';
            } else {
                $req_parts = [];
                foreach ($reqs as $req_b => $req_l) {
                    $have = $current_levels[$req_b] ?? 0;
                    $ok = $have >= $req_l;
                    $color = $ok ? '#4a7a3a' : '#8e2a26';
                    $sym = $ok ? '✓' : '✗';
                    $req_parts[] = "<span style='color:$color;'>$sym " . ucfirst(str_replace('_',' ',$req_b)) . " Lv$req_l <small>(have $have)</small></span>";
                }
                $req_text = implode('<br>', $req_parts);
            }
        ?>
        <tr <?= !$prereq_ok ? 'style="opacity:0.6;"' : '' ?>>
            <td style="display:flex;align-items:center;gap:8px;">
                <img src="<?= img_url("buildings/{$type}.png") ?>" width="40" height="40" style="image-rendering:pixelated;" alt="">
                <strong><?= e($name) ?></strong>
            </td>
            <td style="font-size:11px;"><?= $req_text ?></td>
            <td style="font-size:11px;">
                <span class="res-icon res-wood"></span><?= format_number($cost['wood']) ?><br>
                <span class="res-icon res-clay"></span><?= format_number($cost['clay']) ?><br>
                <span class="res-icon res-iron"></span><?= format_number($cost['iron']) ?><br>
                <span class="res-icon res-crop"></span><?= format_number($cost['crop']) ?>
            </td>
            <td style="font-size:12px;"><?= e(format_seconds($time)) ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="building_type" value="<?= e($type) ?>">
                    <?php if ($can_build): ?>
                    <button type="submit" class="btn btn-green btn-sm">Build</button>
                    <?php elseif (!$prereq_ok): ?>
                    <span style="font-size:11px;color:#8e2a26;" title="<?= e($prereq['error']) ?>">Locked</span>
                    <?php else: ?>
                    <button type="submit" class="btn btn-green btn-sm" disabled title="Not enough resources">Build</button>
                    <?php endif; ?>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$shown_any): ?>
        <tr>
            <td colspan="5" style="text-align:center;color:var(--c-text-soft);padding:24px;">
                All available buildings have already been constructed in this village.
            </td>
        </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div style="margin-top:16px;padding:12px;background:#fff8d6;border-left:4px solid #f0c34b;font-size:12px;">
        <strong>ℹ️ Building Rules:</strong>
        <ul style="margin:6px 0 0 18px;">
            <li>Unique buildings (Barracks, Stable, Main Building, etc.) can only be built once per village.</li>
            <li>Some buildings require other buildings to be at a certain level first.</li>
            <li>Upgrade your <strong>Main Building</strong> to unlock more options.</li>
            <li>Warehouse and Granary can be built multiple times for extra storage.</li>
        </ul>
    </div>

    <p style="text-align:center;margin-top:16px;">
        <a href="<?= url('/village.php') ?>">← Back to Village</a>
    </p>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
