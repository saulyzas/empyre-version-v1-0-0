<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/troops.php');
}

$village = current_village();
$to_x = (int)($_POST['to_x'] ?? 0);
$to_y = (int)($_POST['to_y'] ?? 0);
$mission = $_POST['mission'] ?? 'attack';
$troops_input = $_POST['troops'] ?? [];

if (!in_array($mission, ['attack','reinforcement'])) {
    $mission = 'attack';
}

// Filter troops: only positive numbers
$troops_to_send = [];
foreach ($troops_input as $type => $n) {
    $n = (int)$n;
    if ($n > 0) $troops_to_send[$type] = $n;
}

if (empty($troops_to_send)) {
    $_SESSION['error'] = 'No troops selected.';
    redirect('/troops.php');
}

$result = send_movement($village['id'], $to_x, $to_y, $mission, $troops_to_send);

if (!$result['ok']) {
    $_SESSION['error'] = $result['error'];
} else {
    $_SESSION['success'] = 'Troops sent! They will arrive at ' . $result['arrives_at'];
}

redirect('/troops.php');
