<?php
/**
 * MYEMPIRE - Cancel a build (public endpoint).
 *
 * Called via GET with ?id=N from village.php / resources.php.
 * Cancels the build, refunds 50% of resources, redirects back to referer.
 */
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$village = current_village();
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    redirect('/village.php');
}

$item = db()->fetch(
    "SELECT * FROM build_queue WHERE id = ? AND village_id = ?",
    [$id, $village['id']]
);

if ($item) {
    // Refund 50% of resources
    global $FIELD_BASE_COST, $BUILDING_BASE_COST;
    $next_level = $item['target_level'];
    if ($item['target_kind'] === 'field') {
        $base = $FIELD_BASE_COST[$item['target_type']] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
    } else {
        $base = $BUILDING_BASE_COST[$item['target_type']] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
    }
    $cost = build_cost($base, $next_level);

    $res = update_resources($village['id']);
    db()->update('resources', [
        'wood' => $res['wood'] + ($cost['wood'] ?? 0) * 0.5,
        'clay' => $res['clay'] + ($cost['clay'] ?? 0) * 0.5,
        'iron' => $res['iron'] + ($cost['iron'] ?? 0) * 0.5,
        'crop' => $res['crop'] + ($cost['crop'] ?? 0) * 0.5,
    ], 'village_id = :wv', ['wv' => $village['id']]);

    db()->query("DELETE FROM build_queue WHERE id = ?", [$id]);
}

// Redirect back to where we came from (referer), or default to village
$referer = $_SERVER['HTTP_REFERER'] ?? null;
if ($referer) {
    // Use the referer directly (it's already a full URL with the right base path)
    header("Location: " . $referer);
} else {
    redirect('/village.php');
}
exit;
