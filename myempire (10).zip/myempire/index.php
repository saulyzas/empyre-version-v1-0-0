<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();

// If already logged in, redirect to village
if (current_player_id()) {
    redirect('/village.php');
}

global $TRIBES;
$page_title = 'Home';
require __DIR__ . '/app/views/header.php';
?>
<style>
.landing-hero {
    background: linear-gradient(135deg, #8e5eaf 0%, #4a6da8 50%, #2d3e5e 100%);
    color: #fff;
    padding: 60px 20px;
    text-align: center;
    border-bottom: 4px solid #231612;
    margin: -16px -16px 24px;
}
.landing-hero h1 {
    font-family: Georgia, serif;
    font-size: 56px;
    letter-spacing: 6px;
    text-shadow: 3px 3px 0 #231612;
    margin-bottom: 12px;
}
.landing-hero p { font-size: 18px; opacity: 0.95; margin-bottom: 24px; }
.landing-cta {
    display: inline-block;
    padding: 12px 32px;
    background: #f0c34b;
    color: #231612;
    border: 3px solid #231612;
    border-radius: 6px;
    font-size: 18px;
    font-weight: bold;
    box-shadow: 0 4px 0 #231612;
    text-decoration: none;
    margin: 0 8px;
}
.landing-cta:hover { transform: translateY(-2px); text-decoration: none; }
.landing-cta:active { transform: translateY(2px); box-shadow: none; }
.landing-cta.alt { background: #6aa555; color: #fff; }
</style>

<div class="landing-hero">
    <h1><?= e(GAME_NAME) ?></h1>
    <p><?= e(GAME_TAGLINE) ?>. Forge alliances, build mighty armies, and conquer the ancient world.</p>
    <a href="<?= url('/register.php') ?>" class="landing-cta">PLAY FOR FREE</a>
    <a href="<?= url('/login.php') ?>" class="landing-cta alt">LOGIN</a>
</div>

<div class="grid grid-3">
    <?php foreach ($TRIBES as $key => $tribe): ?>
    <div class="card" style="text-align:center;">
        <img src="<?= img_url("tribes/{$key}_crest.png") ?>" alt="<?= e($tribe['name']) ?>" style="width:120px;height:120px;image-rendering:pixelated;">
        <h3 style="color: var(--c-wood-dk); margin: 8px 0; font-family: Georgia, serif;">The <?= e($tribe['name']) ?></h3>
        <p style="font-size: 13px; color: var(--c-text-soft);"><?= e($tribe['desc']) ?></p>
    </div>
    <?php endforeach; ?>
</div>

<div class="card">
    <div class="card-header">Build Your Empire</div>
    <p>Start with a single village in the wilderness. Develop 18 resource fields (woodcutter, clay pit, iron mine, cropland) to fuel your growth. Construct barracks, stables, smithies, and marketplaces. Train armies unique to your tribe and march them across a vast world map of player villages and uncharted terrain.</p>
    <p style="margin-top:8px;">Resources accumulate in real time. Build queues let you stack upgrades while you sleep. Hero units gain experience. Forge alliances via embassies. The strategic depth of classic browser strategy—now in your own PHP-powered package.</p>
</div>

<div class="card">
    <div class="card-header">Strategic Infrastructure</div>
    <div class="grid grid-3" style="margin-top: 8px;">
        <div style="text-align:center;">
            <img src="<?= img_url('buildings/warehouse.png') ?>" alt="Warehouse" style="width:80px;height:80px;image-rendering:pixelated;">
            <div style="font-weight:bold;margin-top:4px;">Warehouse</div>
            <div style="font-size:11px;color:var(--c-text-soft);">Store wood, clay, iron</div>
        </div>
        <div style="text-align:center;">
            <img src="<?= img_url('buildings/barracks.png') ?>" alt="Barracks" style="width:80px;height:80px;image-rendering:pixelated;">
            <div style="font-weight:bold;margin-top:4px;">Barracks</div>
            <div style="font-size:11px;color:var(--c-text-soft);">Train infantry units</div>
        </div>
        <div style="text-align:center;">
            <img src="<?= img_url('buildings/hero_mansion.png') ?>" alt="Hero Mansion" style="width:80px;height:80px;image-rendering:pixelated;">
            <div style="font-weight:bold;margin-top:4px;">Hero Mansion</div>
            <div style="font-size:11px;color:var(--c-text-soft);">Recruit & level up heroes</div>
        </div>
    </div>
</div>

<div class="card" style="text-align:center;">
    <div class="card-header">Ready to make history?</div>
    <p style="margin: 12px 0;">Claim your quadrant, raise your banner, and write your name into the chronicles of <?= e(GAME_NAME) ?>.</p>
    <a href="<?= url('/register.php') ?>" class="btn btn-green btn-lg">Start Now</a>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
