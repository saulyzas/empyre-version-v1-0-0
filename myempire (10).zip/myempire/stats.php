<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

// Players ranking (by population)
$players = db()->fetchAll(
    "SELECT p.id, p.username, p.tribe, p.population, p.created_at,
            COUNT(v.id) AS village_count
     FROM players p
     LEFT JOIN villages v ON v.player_id = p.id
     GROUP BY p.id
     ORDER BY p.population DESC, p.created_at ASC
     LIMIT 100"
);

$page_title = 'Ranks';
require __DIR__ . '/app/views/header.php';
?>

<div class="card">
    <div class="card-header">Player Rankings</div>
    <table class="data">
        <thead>
            <tr>
                <th>Rank</th>
                <th>Player</th>
                <th>Tribe</th>
                <th>Population</th>
                <th>Villages</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($players as $i => $p): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td>
                <img src="<?= img_url("tribes/{$p['tribe']}.png") ?>" width="20" height="20" alt="" style="vertical-align:middle;image-rendering:pixelated;">
                <strong><?= e($p['username']) ?></strong>
            </td>
            <td><?= e(ucfirst($p['tribe'])) ?></td>
            <td><?= (int)$p['population'] ?></td>
            <td><?= (int)$p['village_count'] ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($players)): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--c-text-soft);">No players yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
