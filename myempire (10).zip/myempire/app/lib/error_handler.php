<?php
/**
 * MYEMPIRE - Global error handler for database connection issues.
 *
 * Instead of showing a raw PHP fatal error stack trace, we render a friendly
 * HTML page with the actionable message from Database.php exceptions.
 */

require_once __DIR__ . '/../config/config.php';

set_exception_handler(function (Throwable $e) {
    // Only intercept database-related RuntimeExceptions
    $msg = $e->getMessage();
    $is_db_error = (
        strpos($msg, 'driver is not enabled') !== false
        || strpos($msg, 'connection failed') !== false
        || strpos($msg, 'Could not connect to any database') !== false
        || strpos($msg, 'SQLSTATE') !== false
        || $e instanceof PDOException
    );

    if (!$is_db_error) {
        // For other exceptions, fall through to default PHP handling
        http_response_code(500);
        echo "Fatal error: " . htmlspecialchars($msg);
        return;
    }

    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');

    // Detect which scenario we're in
    $sqlite_enabled = in_array('sqlite', PDO::getAvailableDrivers());
    $mysql_enabled  = in_array('mysql', PDO::getAvailableDrivers());

    $msg_html = htmlspecialchars($msg);
    $msg_html = nl2br($msg_html);

    // Determine the recommended next step
    if (!$sqlite_enabled && $mysql_enabled) {
        $recommendation = '
            <div class="callout callout-do">
                <h3>✅ Greičiausias sprendimas — naudokite MySQL</h3>
                <p>Kadangi jūsų PHP turi įjungtą MySQL driver (bet ne SQLite),
                geriausias sprendimas yra perjungti į MySQL:</p>
                <ol>
                    <li>Atidarykite <code>' . htmlspecialchars(ROOT_DIR) . '\\app\\config\\config.php</code></li>
                    <li>Raskite eilutę: <code>define(\'DB_DRIVER\', \'auto\');</code></li>
                    <li>Pakeiskite į: <code>define(\'DB_DRIVER\', \'mysql\');</code></li>
                    <li>Išsaugokite failą</li>
                    <li>Įsitikinkite, kad MySQL paleistas XAMPP control panel</li>
                    <li>Įsitikinkite, kad sukūrėte DB <code>myempire</code> phpMyAdmin ir importavote <code>sql/schema_mysql.sql</code></li>
                    <li>Perkraukite šį puslapį</li>
                </ol>
            </div>';
    } elseif (!$sqlite_enabled && !$mysql_enabled) {
        $recommendation = '
            <div class="callout callout-warn">
                <h3>⚠️ Nėra jokio DB driver</h3>
                <p>Jūsų PHP neturi įjungto nei SQLite, nei MySQL driver. Reikia įjungti bent vieną.</p>
                <p><strong>Rekomenduojama:</strong> atidarykite <code>C:\\xampp\\php\\php.ini</code>,
                nuimkite kabliataškį (<code>;</code>) nuo šių eilučių ir perpaleiskite Apache:</p>
                <pre>;extension=pdo_sqlite   →   extension=pdo_sqlite
;extension=sqlite3       →   extension=sqlite3
;extension=pdo_mysql     →   extension=pdo_mysql</pre>
            </div>';
    } else {
        $recommendation = '
            <div class="callout callout-info">
                <h3>ℹ️ Detalės</h3>
                <p>Patikrinkite klaidos pranešimą aukščiau — jame nurodyta, kuris driveris nepavyko ir kodėl.</p>
            </div>';
    }

    echo '<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>' . htmlspecialchars(GAME_NAME) . ' — Duomenų bazės klaida</title>
    <style>
        body {
            font-family: "Trebuchet MS", "Segoe UI", Tahoma, sans-serif;
            background: #f4ead5;
            color: #2a1f15;
            padding: 40px 20px;
            line-height: 1.5;
            margin: 0;
        }
        .container {
            max-width: 760px;
            margin: 0 auto;
            background: #fdf6e3;
            border: 3px solid #231612;
            border-radius: 8px;
            padding: 24px;
            box-shadow: 0 4px 0 rgba(35,22,18,0.3), 0 6px 12px rgba(0,0,0,0.1);
        }
        h1 {
            color: #8e2a26;
            font-family: Georgia, serif;
            margin-bottom: 8px;
        }
        .subtitle {
            color: #5a4a30;
            margin-bottom: 16px;
            font-size: 14px;
        }
        .error-box {
            background: #ffe0e0;
            border: 2px solid #8e2a26;
            border-radius: 6px;
            padding: 16px;
            font-family: "Consolas", "Courier New", monospace;
            font-size: 12px;
            white-space: normal;
            color: #2a1f15;
            margin: 16px 0;
            word-wrap: break-word;
        }
        .driver-status {
            background: #fff8d6;
            border: 1px solid #b88e28;
            border-radius: 4px;
            padding: 8px 12px;
            font-size: 13px;
            margin: 12px 0;
        }
        .driver-status .ok { color: #4a7a3a; font-weight: bold; }
        .driver-status .no { color: #8e2a26; font-weight: bold; }
        .callout {
            border-radius: 6px;
            padding: 16px;
            margin: 16px 0;
            border-left: 4px solid;
        }
        .callout-do    { background: #e0ffe0; border-color: #4a7a3a; }
        .callout-warn  { background: #ffe8d0; border-color: #c87348; }
        .callout-info  { background: #e0e5ff; border-color: #324d80; }
        .callout h3 { margin: 0 0 8px 0; }
        .callout p { margin: 4px 0; font-size: 14px; }
        .callout ol, .callout ul { margin: 8px 0 8px 24px; font-size: 14px; }
        .callout li { margin: 4px 0; }
        code {
            background: #fff8d6;
            border: 1px solid #b88e28;
            padding: 1px 6px;
            border-radius: 3px;
            font-family: "Consolas", "Courier New", monospace;
            font-size: 13px;
        }
        pre {
            background: #2a1f15;
            color: #fdf6e3;
            padding: 12px;
            border-radius: 4px;
            overflow-x: auto;
            font-family: "Consolas", "Courier New", monospace;
            font-size: 12px;
        }
        .hint {
            margin-top: 16px;
            font-size: 13px;
            color: #5a4a30;
            padding-top: 12px;
            border-top: 1px solid #d4c89a;
        }
        .hint a { color: #324d80; }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚠️ Duomenų bazės klaida</h1>
        <p class="subtitle">' . htmlspecialchars(GAME_NAME) . ' negalėjo prisijungti prie duomenų bazės. Nesijaudinkite — tai lengva pataisyti.</p>

        <div class="driver-status">
            <strong>Driverių būsena:</strong>
            SQLite: <span class="' . ($sqlite_enabled ? 'ok' : 'no') . '">' . ($sqlite_enabled ? '✓ Įjungtas' : '✗ Neįjungtas') . '</span>
            &nbsp;|&nbsp;
            MySQL: <span class="' . ($mysql_enabled ? 'ok' : 'no') . '">' . ($mysql_enabled ? '✓ Įjungtas' : '✗ Neįjungtas') . '</span>
        </div>

        <div class="error-box">' . $msg_html . '</div>

        ' . $recommendation . '

        <div class="hint">
            <p>Pilnas aprašymas — <code>README.md</code> → „Installation“ skyrius.</p>
            <p>Galite taip pat tiesiogiai pakeisti driverį faile <code>app/config/config.php</code>:</p>
            <pre>// Po šios eilutės:
define(\'DB_DRIVER\', \'auto\');

// Pakeiskite į vieną iš:
define(\'DB_DRIVER\', \'sqlite\');  // SQLite (reikia įjungti pdo_sqlite)
define(\'DB_DRIVER\', \'mysql\');   // MySQL/MariaDB (XAMPP turi parengtą)</pre>
        </div>
    </div>
</body>
</html>';
    exit;
});
