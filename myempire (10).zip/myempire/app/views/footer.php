</main>

<footer class="game-footer">
    <p>A custom project | <?= e(GAME_COPYRIGHT) ?> | <?= e(GAME_VERSION) ?></p>
    <p class="footer-note">Not affiliated with Travian Games GmbH. Inspired by <a href="https://github.com/andreapavoni/parabellum" target="_blank" rel="noopener">Parabellum</a>.</p>
</footer>

<script src="<?= JS_URL ?>/main.js?v=<?= GAME_VERSION ?>"></script>
<?php if (isset($page_js)): ?>
<script src="<?= JS_URL ?>/<?= $page_js ?>?v=<?= GAME_VERSION ?>"></script>
<?php endif; ?>
</body>
</html>
