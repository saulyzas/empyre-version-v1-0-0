<?php
require_once __DIR__ . '/../../app/lib/helpers.php';
init_session();
require_login();

header('Content-Type: application/json');

$village = current_village();
process_build_queue($village['id']);
$resources = update_resources($village['id']);
$production = production_per_hour($village['id']);
$queue = get_build_queue($village['id']);

$queue_data = array_map(function($item) {
    return [
        'id'          => (int)$item['id'],
        'name'        => ucfirst(str_replace('_', ' ', $item['target_type'])),
        'level'       => (int)$item['target_level'],
        'finishes_at' => $item['finishes_at'],
        'remaining'   => max(0, strtotime($item['finishes_at']) - time()),
    ];
}, $queue);

json_response([
    'ok' => true,
    'resources' => [
        'wood' => (float)$resources['wood'],
        'clay' => (float)$resources['clay'],
        'iron' => (float)$resources['iron'],
        'crop' => (float)$resources['crop'],
        'wood_cap' => (int)$resources['wood_cap'],
        'clay_cap' => (int)$resources['clay_cap'],
        'iron_cap' => (int)$resources['iron_cap'],
        'crop_cap' => (int)$resources['crop_cap'],
    ],
    'production' => $production,
    'queue' => $queue_data,
    'server_time' => date('Y-m-d H:i:s'),
]);
