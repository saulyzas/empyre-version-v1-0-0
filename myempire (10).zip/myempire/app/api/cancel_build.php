<?php
require_once __DIR__ . '/../../app/lib/helpers.php';
init_session();
require_login();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'POST required'], 405);
}

$id = (int)($_POST['id'] ?? 0);
$village = current_village();

$item = db()->fetch("SELECT * FROM build_queue WHERE id = ? AND village_id = ?", [$id, $village['id']]);
if (!$item) {
    json_response(['ok' => false, 'error' => 'Build item not found'], 404);
}

// Refund 50% of resources (simple penalty)
global $FIELD_BASE_COST, $BUILDING_BASE_COST;
$next_level = $item['target_level'];
if ($item['target_kind'] === 'field') {
    $base = $FIELD_BASE_COST[$item['target_type']] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
} else {
    $base = $BUILDING_BASE_COST[$item['target_type']] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
}
$cost = build_cost($base, $next_level);
$refund = ['wood' => $cost['wood'] * 0.5, 'clay' => $cost['clay'] * 0.5,
           'iron' => $cost['iron'] * 0.5, 'crop' => $cost['crop'] * 0.5];

$res = update_resources($village['id']);
db()->update('resources', [
    'wood' => $res['wood'] + $refund['wood'],
    'clay' => $res['clay'] + $refund['clay'],
    'iron' => $res['iron'] + $refund['iron'],
    'crop' => $res['crop'] + $refund['crop'],
], 'village_id = :wv', ['wv' => $village['id']]);

db()->query("DELETE FROM build_queue WHERE id = ?", [$id]);

json_response(['ok' => true]);
