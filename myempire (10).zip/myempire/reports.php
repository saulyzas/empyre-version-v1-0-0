<?php
require_once __DIR__ . '/app/lib/helpers.php';
init_session();
require_login();

$player = current_player();

// Mark all as read on visit
if (isset($_GET['mark_read'])) {
    db()->query("UPDATE reports SET is_read = 1 WHERE player_id = ?", [$player['id']]);
    redirect('/reports.php');
}

// Get reports
$reports = db()->fetchAll(
    "SELECT * FROM reports WHERE player_id = ? ORDER BY created_at DESC",
    [$player['id']]
);

// Get selected report
$sel_id = (int)($_GET['id'] ?? 0);
$selected = null;
if ($sel_id) {
    $selected = db()->fetch("SELECT * FROM reports WHERE id = ? AND player_id = ?", [$sel_id, $player['id']]);
    if ($selected) {
        db()->query("UPDATE reports SET is_read = 1 WHERE id = ?", [$sel_id]);
    }
}

$page_title = 'Reports';
require __DIR__ . '/app/views/header.php';
?>

<div class="grid grid-2">
    <div class="card">
        <div class="card-header">
            Reports
            <a href="<?= url('/reports.php?mark_read=1') ?>" class="btn btn-sm" style="float:right;">Mark all read</a>
        </div>
        <?php if (empty($reports)): ?>
        <p style="color:var(--c-text-soft);text-align:center;padding:24px;">No reports yet.</p>
        <?php else: ?>
        <table class="data">
            <thead>
                <tr>
                    <th></th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($reports as $r): ?>
            <tr style="<?= !$r['is_read'] ? 'font-weight:bold;' : '' ?>">
                <td>
                    <?php if (!$r['is_read']): ?>
                    <span style="display:inline-block;width:8px;height:8px;background:var(--c-red);border-radius:50%;"></span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?= url('/reports.php') . '?id=' . (int)$r['id'] ?>"><?= e($r['title']) ?></a>
                </td>
                <td style="font-size:11px;text-transform:uppercase;"><?= e($r['category']) ?></td>
                <td style="font-size:11px;"><?= e($r['created_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header">Report Details</div>
        <?php if ($selected): ?>
        <h3 style="color:var(--c-wood-dk);margin-bottom:8px;"><?= e($selected['title']) ?></h3>
        <p style="font-size:11px;color:var(--c-text-soft);margin-bottom:12px;">
            Category: <strong><?= e($selected['category']) ?></strong> | Date: <?= e($selected['created_at']) ?>
        </p>
        <div style="background:var(--c-white);padding:12px;border:2px solid var(--c-stone-dk);border-radius:6px;white-space:pre-wrap;font-size:13px;"><?= e($selected['body']) ?></div>
        <?php else: ?>
        <p style="color:var(--c-text-soft);text-align:center;padding:24px;">Select a report to view its content.</p>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/app/views/footer.php'; ?>
