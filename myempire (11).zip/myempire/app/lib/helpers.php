<?php
/**
 * MYEMPIRE - Helper functions
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/error_handler.php';

// ---- Session & Auth ----
function init_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_set_cookie_params(['lifetime' => SESSION_LIFETIME, 'path' => '/', 'httponly' => true]);
        session_start();
    }
}

function current_player_id() {
    return $_SESSION['player_id'] ?? null;
}

function current_player() {
    $pid = current_player_id();
    if (!$pid) return null;
    static $cache = null;
    if ($cache === null || $cache['id'] != $pid) {
        $cache = db()->fetch("SELECT * FROM players WHERE id = ?", [$pid]);
    }
    return $cache;
}

function current_village() {
    $pid = current_player_id();
    if (!$pid) return null;
    static $cache = null;
    if ($cache === null || $cache['player_id'] != $pid) {
        $cache = db()->fetch("SELECT * FROM villages WHERE player_id = ? ORDER BY is_capital DESC, id ASC LIMIT 1", [$pid]);
    }
    return $cache;
}

function require_login() {
    if (!current_player_id()) {
        redirect('/login.php');
    }
}

// ---- Output helpers ----
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    // Auto-prefix with BASE_PATH so it works in subdirectories (e.g. /myempire/)
    if (defined('BASE_PATH') && strpos($path, '/') === 0 && strpos($path, '//') !== 0) {
        $path = BASE_PATH . $path;
    }
    header("Location: $path");
    exit;
}

/**
 * Generate a URL with the BASE_PATH prefix.
 * Example: url('/login.php') -> '/myempire/login.php'
 */
function url($path = '') {
    if (empty($path)) return BASE_PATH ?: '/';
    // Already absolute URL (http://...) — return as-is
    if (preg_match('#^https?://#', $path)) return $path;
    // Ensure leading slash
    if ($path[0] !== '/') $path = '/' . $path;
    return BASE_PATH . $path;
}

function json_response($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function img_url($path) {
    return IMG_URL . '/' . ltrim($path, '/');
}

// ---- Resource production ----
function production_per_hour($village_id) {
    global $FIELD_PRODUCTION;
    $fields = db()->fetchAll(
        "SELECT field_type, level FROM resource_fields WHERE village_id = ?",
        [$village_id]
    );
    $prod = ['wood' => 0, 'clay' => 0, 'iron' => 0, 'crop' => 0];
    foreach ($fields as $f) {
        $level = min(MAX_RESOURCE_LEVEL, max(0, $f['level']));
        $rate = $FIELD_PRODUCTION[$level] ?? 0;
        $rate *= GAME_SERVER_SPEED;
        switch ($f['field_type']) {
            case 'woodcutter': $prod['wood']  += $rate; break;
            case 'claypit':    $prod['clay']  += $rate; break;
            case 'ironmine':   $prod['iron']  += $rate; break;
            case 'cropland':   $prod['crop']  += $rate; break;
        }
    }
    // Subtract population consumption (1 crop per population per hour).
    // This is the standard Travian mechanic — every villager eats 1 crop/hour.
    $village = db()->fetch("SELECT player_id FROM villages WHERE id = ?", [$village_id]);
    $player = db()->fetch("SELECT population FROM players WHERE id = ?", [$village['player_id']]);
    $prod['crop'] = max(0, $prod['crop'] - ($player['population'] ?? 0));
    return $prod;
}

// ---- Update resource stockpile based on time elapsed ----
function update_resources($village_id) {
    $res = db()->fetch("SELECT * FROM resources WHERE village_id = ?", [$village_id]);
    if (!$res) return null;

    $now = new DateTime('now');
    $last = new DateTime($res['last_update']);
    $diff = $now->getTimestamp() - $last->getTimestamp();
    if ($diff <= 0) return $res;

    $prod = production_per_hour($village_id);
    $per_second = [
        'wood' => $prod['wood'] / 3600.0,
        'clay' => $prod['clay'] / 3600.0,
        'iron' => $prod['iron'] / 3600.0,
        'crop' => $prod['crop'] / 3600.0,
    ];

    $new = [
        'wood' => min($res['wood_cap'], $res['wood'] + $per_second['wood'] * $diff),
        'clay' => min($res['clay_cap'], $res['clay'] + $per_second['clay'] * $diff),
        'iron' => min($res['iron_cap'], $res['iron'] + $per_second['iron'] * $diff),
        'crop' => min($res['crop_cap'], $res['crop'] + $per_second['crop'] * $diff),
    ];

    db()->update('resources', [
        'wood' => $new['wood'],
        'clay' => $new['clay'],
        'iron' => $new['iron'],
        'crop' => $new['crop'],
        'last_update' => $now->format('Y-m-d H:i:s'),
    ], 'village_id = :wv', ['wv' => $village_id]);

    $res['wood'] = $new['wood'];
    $res['clay'] = $new['clay'];
    $res['iron'] = $new['iron'];
    $res['crop'] = $new['crop'];
    return $res;
}

// ---- Process build queue (finish items whose time has come) ----
function process_build_queue($village_id) {
    $now = date('Y-m-d H:i:s');
    $finished = db()->fetchAll(
        "SELECT * FROM build_queue WHERE village_id = ? AND finishes_at <= ? ORDER BY finishes_at ASC",
        [$village_id, $now]
    );
    foreach ($finished as $item) {
        if ($item['target_kind'] === 'field') {
            // Update resource_fields
            db()->query(
                "UPDATE resource_fields SET level = ? WHERE village_id = ? AND position = ?",
                [$item['target_level'], $village_id, $item['position']]
            );
        } else {
            // Update buildings
            $existing = db()->fetch(
                "SELECT id FROM buildings WHERE village_id = ? AND position = ?",
                [$village_id, $item['position']]
            );
            if ($existing) {
                db()->query(
                    "UPDATE buildings SET level = ?, building_type = ? WHERE id = ?",
                    [$item['target_level'], $item['target_type'], $existing['id']]
                );
            } else {
                db()->insert('buildings', [
                    'village_id' => $village_id,
                    'position' => $item['position'],
                    'building_type' => $item['target_type'],
                    'level' => $item['target_level'],
                ]);
            }
        }
        db()->query("DELETE FROM build_queue WHERE id = ?", [$item['id']]);

        // Recalculate population after each completed build
        recalculate_population($village_id);
    }

    // Also process training queue (troops)
    process_training_queue($village_id);

    // And process troop movements
    process_movements($village_id);

    // And process resource shipments (marketplace)
    process_resource_movements($village_id);
}

// ---- Recalculate village population based on fields + buildings ----
function recalculate_population($village_id) {
    global $BUILDING_POPULATION, $FIELD_POPULATION_PER_LEVEL;

    // Sum field levels × field population cost
    $field_pop = (int)db()->fetchColumn(
        "SELECT COALESCE(SUM(level * ?), 0) FROM resource_fields WHERE village_id = ?",
        [$FIELD_POPULATION_PER_LEVEL, $village_id]
    );

    // Sum building levels × building population cost
    $buildings = db()->fetchAll(
        "SELECT building_type, level FROM buildings WHERE village_id = ?",
        [$village_id]
    );
    $building_pop = 0;
    foreach ($buildings as $b) {
        $per_level = $BUILDING_POPULATION[$b['building_type']] ?? 1;
        $building_pop += $b['level'] * $per_level;
    }

    $total = $field_pop + $building_pop;

    // Update players table (population is stored per player, not per village — but we use player's first village here for simplicity)
    $village = db()->fetch("SELECT player_id FROM villages WHERE id = ?", [$village_id]);
    if ($village) {
        db()->query("UPDATE players SET population = ? WHERE id = ?", [$total, $village['player_id']]);
    }
    return $total;
}

// ---- Get current build queue ----
function get_build_queue($village_id) {
    return db()->fetchAll(
        "SELECT * FROM build_queue WHERE village_id = ? ORDER BY finishes_at ASC",
        [$village_id]
    );
}

// ---- Get current resource fields ----
function get_resource_fields($village_id) {
    return db()->fetchAll(
        "SELECT * FROM resource_fields WHERE village_id = ? ORDER BY position ASC",
        [$village_id]
    );
}

// ---- Get current buildings ----
function get_buildings($village_id) {
    return db()->fetchAll(
        "SELECT * FROM buildings WHERE village_id = ? ORDER BY position ASC",
        [$village_id]
    );
}

// ---- Calculate build cost ----
function calc_field_cost($field_type, $next_level) {
    global $FIELD_BASE_COST;
    $base = $FIELD_BASE_COST[$field_type] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
    return build_cost($base, $next_level);
}

function calc_building_cost($building_type, $next_level) {
    global $BUILDING_BASE_COST;
    $base = $BUILDING_BASE_COST[$building_type] ?? ['wood'=>100,'clay'=>100,'iron'=>100,'crop'=>50];
    return build_cost($base, $next_level);
}

function calc_field_time($next_level, $main_building_level = 1) {
    global $FIELD_BASE_TIME;
    $base = $FIELD_BASE_TIME ?? 60;
    return build_time_seconds($base, $next_level, $main_building_level);
}

function calc_building_time($building_type, $next_level, $main_building_level = 1) {
    global $BUILDING_BASE_TIME;
    $base = $BUILDING_BASE_TIME[$building_type] ?? 600;
    return build_time_seconds($base, $next_level, $main_building_level);
}

// ---- Terrain generation for map ----
function terrain_for_cell($x, $y) {
    // Deterministic terrain based on coordinates
    $hash = crc32(serialize([$x, $y])) % 100;
    if ($hash < 50) return 'grass';
    if ($hash < 70) return 'forest';
    if ($hash < 85) return 'mountain';
    if ($hash < 95) return 'desert';
    return 'water';
}

// ---- Format helpers ----
function format_seconds($sec) {
    $sec = (int)$sec;
    $h = intdiv($sec, 3600);
    $m = intdiv($sec % 3600, 60);
    $s = $sec % 60;
    if ($h > 0) return sprintf('%dh %02dm %02ds', $h, $m, $s);
    if ($m > 0) return sprintf('%dm %02ds', $m, $s);
    return sprintf('%ds', $s);
}

function format_number($n) {
    return number_format((int)$n, 0, ',', '.');
}

// ---- Enqueue build ----
function enqueue_build($village_id, $kind, $target_type, $position, $target_level, $cost, $time_sec) {
    // Check queue size
    $queue_count = db()->fetchColumn(
        "SELECT COUNT(*) FROM build_queue WHERE village_id = ?",
        [$village_id]
    );
    if ($queue_count >= BUILD_QUEUE_SIZE) {
        return ['ok' => false, 'error' => 'Build queue is full'];
    }

    // For buildings, check prerequisites and uniqueness
    if ($kind === 'building') {
        // Prerequisites
        $prereq = check_building_prerequisites($target_type, $village_id);
        if (!$prereq['ok']) {
            return ['ok' => false, 'error' => $prereq['error']];
        }

        // Uniqueness: if this is a new building (target_level == 1) and it's a unique
        // building type, check that no other slot has the same type.
        // (If target_level > 1, this is an upgrade of an existing building — allow it.)
        if ($target_level === 1 && building_already_exists($target_type, $village_id, $position)) {
            $name = ucfirst(str_replace('_', ' ', $target_type));
            return ['ok' => false, 'error' => "You already have a $name in this village. Each village can have only one."];
        }

        // Check max level
        global $BUILDING_MAX_LEVEL;
        $max_level = $BUILDING_MAX_LEVEL[$target_type] ?? MAX_BUILDING_LEVEL;
        if ($target_level > $max_level) {
            return ['ok' => false, 'error' => 'Maximum level reached'];
        }
    }

    // Check resources
    $res = update_resources($village_id);
    foreach ($cost as $r => $amt) {
        if ($res[$r] < $amt) {
            return ['ok' => false, 'error' => 'Not enough ' . $r];
        }
    }

    // Deduct resources
    db()->update('resources', [
        'wood' => max(0, $res['wood'] - ($cost['wood'] ?? 0)),
        'clay' => max(0, $res['clay'] - ($cost['clay'] ?? 0)),
        'iron' => max(0, $res['iron'] - ($cost['iron'] ?? 0)),
        'crop' => max(0, $res['crop'] - ($cost['crop'] ?? 0)),
    ], 'village_id = :wv', ['wv' => $village_id]);

    // Compute finish time.
    // We use DateTime so the timestamp stays in PHP's configured timezone
    // (date_default_timezone_set in config.php) — this avoids strtotime()
    // misinterpreting the stored string as UTC.
    $last = db()->fetchColumn(
        "SELECT MAX(finishes_at) FROM build_queue WHERE village_id = ?",
        [$village_id]
    );
    $now_ts = time();
    if ($last) {
        // Parse stored timestamp as a wall-clock time in the current PHP timezone.
        $last_dt = DateTime::createFromFormat('Y-m-d H:i:s', $last);
        $base = $last_dt ? max($last_dt->getTimestamp(), $now_ts) : $now_ts;
    } else {
        $base = $now_ts;
    }
    $finishes = date('Y-m-d H:i:s', $base + $time_sec);

    db()->insert('build_queue', [
        'village_id' => $village_id,
        'target_kind' => $kind,
        'target_type' => $target_type,
        'position' => $position,
        'target_level' => $target_level,
        'finishes_at' => $finishes,
    ]);

    return ['ok' => true];
}

// ============================================================
// TROOP TRAINING QUEUE
// ============================================================

function get_training_queue($village_id) {
    return db()->fetchAll(
        "SELECT * FROM training_queue WHERE village_id = ? ORDER BY finishes_at ASC",
        [$village_id]
    );
}

function process_training_queue($village_id) {
    $now = date('Y-m-d H:i:s');
    $finished = db()->fetchAll(
        "SELECT * FROM training_queue WHERE village_id = ? AND finishes_at <= ? ORDER BY finishes_at ASC",
        [$village_id, $now]
    );
    foreach ($finished as $item) {
        // Add troops to village
        $existing = db()->fetch(
            "SELECT id, count FROM troops WHERE village_id = ? AND unit_type = ?",
            [$village_id, $item['unit_type']]
        );
        if ($existing) {
            db()->query(
                "UPDATE troops SET count = count + ? WHERE id = ?",
                [$item['count'], $existing['id']]
            );
        } else {
            db()->insert('troops', [
                'village_id' => $village_id,
                'unit_type'  => $item['unit_type'],
                'count'      => $item['count'],
            ]);
        }
        db()->query("DELETE FROM training_queue WHERE id = ?", [$item['id']]);
    }
}

// Enqueue training of N units of a type.
// Returns ['ok' => true] or ['ok' => false, 'error' => '...'].
function enqueue_training($village_id, $unit_type, $count, $building_level = 1) {
    global $UNITS, $UNIT_TRAIN_TIME;
    $player = current_player();
    if (!$player) return ['ok' => false, 'error' => 'Not logged in'];
    $tribe = $player['tribe'];

    // Validate unit type for this tribe
    if (!isset($UNITS[$tribe][$unit_type])) {
        return ['ok' => false, 'error' => 'Invalid unit for your tribe'];
    }
    $unit = $UNITS[$tribe][$unit_type];

    $count = max(1, (int)$count);
    $base_time = $UNIT_TRAIN_TIME[$unit_type] ?? 240;
    $per_unit_time = training_time_seconds($base_time, $building_level);
    $total_time = $per_unit_time * $count;

    // Check resources
    $res = update_resources($village_id);
    $cost = [];
    foreach (['wood','clay','iron','crop'] as $r) {
        $cost[$r] = ($unit['cost'][$r] ?? 0) * $count;
        if ($res[$r] < $cost[$r]) {
            return ['ok' => false, 'error' => 'Not enough ' . $r];
        }
    }

    // Deduct
    db()->update('resources', [
        'wood' => max(0, $res['wood'] - $cost['wood']),
        'clay' => max(0, $res['clay'] - $cost['clay']),
        'iron' => max(0, $res['iron'] - $cost['iron']),
        'crop' => max(0, $res['crop'] - $cost['crop']),
    ], 'village_id = :wv', ['wv' => $village_id]);

    // Compute finish time (chain after last training in this village)
    $last = db()->fetchColumn(
        "SELECT MAX(finishes_at) FROM training_queue WHERE village_id = ?",
        [$village_id]
    );
    $now_ts = time();
    if ($last) {
        $last_dt = DateTime::createFromFormat('Y-m-d H:i:s', $last);
        $base = $last_dt ? max($last_dt->getTimestamp(), $now_ts) : $now_ts;
    } else {
        $base = $now_ts;
    }
    $finishes = date('Y-m-d H:i:s', $base + $total_time);

    db()->insert('training_queue', [
        'village_id'  => $village_id,
        'unit_type'   => $unit_type,
        'count'       => $count,
        'finishes_at' => $finishes,
    ]);

    return ['ok' => true];
}

// ============================================================
// TROOP MOVEMENTS (attacks + reinforcements)
// ============================================================

function get_village_troops($village_id) {
    return db()->fetchAll(
        "SELECT * FROM troops WHERE village_id = ? AND count > 0 ORDER BY unit_type",
        [$village_id]
    );
}

function get_movements($village_id) {
    // Outgoing + incoming
    $outgoing = db()->fetchAll(
        "SELECT m.*, v.name AS target_name, p.username AS target_player
         FROM movements m
         JOIN villages v ON v.id = m.to_village_id
         JOIN players p ON p.id = v.player_id
         WHERE m.from_village_id = ?
         ORDER BY m.arrives_at ASC",
        [$village_id]
    );
    $incoming = db()->fetchAll(
        "SELECT m.*, v.name AS source_name, p.username AS source_player
         FROM movements m
         JOIN villages v ON v.id = m.from_village_id
         JOIN players p ON p.id = v.player_id
         WHERE m.to_village_id = ?
         ORDER BY m.arrives_at ASC",
        [$village_id]
    );
    return ['outgoing' => $outgoing, 'incoming' => $incoming];
}

function process_movements($village_id) {
    $now = date('Y-m-d H:i:s');
    // Find all movements that have arrived (limited to this village as source or target)
    $arrived = db()->fetchAll(
        "SELECT * FROM movements
         WHERE (from_village_id = ? OR to_village_id = ?)
         AND arrives_at <= ? AND status = 'in_progress'
         ORDER BY arrives_at ASC",
        [$village_id, $village_id, $now]
    );
    foreach ($arrived as $move) {
        // Decode troops JSON
        $troops = json_decode($move['troops_json'], true) ?: [];
        if ($move['type'] === 'attack') {
            // Simple resolution: attacker wins if total attack > defender's total defense
            // For now: just send all attackers home with whatever survives (50%)
            // and add 50% of defender losses.
            $defender_troops = get_village_troops($move['to_village_id']);
            // Resolve combat (very simplified)
            $attacker_power = 0;
            foreach ($troops as $type => $n) {
                $stats = find_unit_stats($type);
                $attacker_power += $stats['attack'] * $n;
            }
            $defender_power = 0;
            foreach ($defender_troops as $dt) {
                $stats = find_unit_stats($dt['unit_type']);
                $defender_power += $stats['def_inf'] * $dt['count'];
            }
            // Winner keeps 50%, loser loses all
            if ($attacker_power > $defender_power) {
                // Attacker wins — return with 50% troops, steal loot
                $survivors = [];
                $total_carry = 0;
                foreach ($troops as $type => $n) {
                    $survivors[$type] = (int)ceil($n * 0.5);
                    // Add carry capacity of survivors
                    $carry_per_unit = $GLOBALS['UNIT_CARRY_CAPACITY'][$type] ?? 0;
                    $total_carry += $survivors[$type] * $carry_per_unit;
                }

                // Get attacker's tribe for loot multiplier
                $from_vil_tribe = db()->fetch(
                    "SELECT p.tribe FROM villages v JOIN players p ON p.id = v.player_id WHERE v.id = ?",
                    [$move['from_village_id']]
                );
                $tribe = $from_vil_tribe['tribe'] ?? 'roman';
                $loot_mult = $GLOBALS['TRIBE_LOOT_MULTIPLIER'][$tribe] ?? 0.7;
                $max_loot = (int)round($total_carry * $loot_mult);

                // Steal resources up to max_loot total, distributed evenly
                $res = update_resources($move['to_village_id']);
                $available = $res['wood'] + $res['clay'] + $res['iron'] + $res['crop'];
                $actual_loot_total = min($max_loot, $available);

                if ($actual_loot_total > 0 && $available > 0) {
                    $ratio = $actual_loot_total / $available;
                    $loot = [
                        'wood' => floor($res['wood'] * $ratio),
                        'clay' => floor($res['clay'] * $ratio),
                        'iron' => floor($res['iron'] * $ratio),
                        'crop' => floor($res['crop'] * $ratio),
                    ];
                } else {
                    $loot = ['wood' => 0, 'clay' => 0, 'iron' => 0, 'crop' => 0];
                }

                db()->update('resources', [
                    'wood' => max(0, $res['wood'] - $loot['wood']),
                    'clay' => max(0, $res['clay'] - $loot['clay']),
                    'iron' => max(0, $res['iron'] - $loot['iron']),
                    'crop' => max(0, $res['crop'] - $loot['crop']),
                ], 'village_id = :wv', ['wv' => $move['to_village_id']]);
                // Remove all defender troops (they lost)
                db()->query("DELETE FROM troops WHERE village_id = ?", [$move['to_village_id']]);
                // Create return movement
                $travel_time = strtotime($move['arrives_at']) - strtotime($move['started_at']);
                $return_at = date('Y-m-d H:i:s', time() + $travel_time);
                db()->insert('movements', [
                    'from_village_id' => $move['to_village_id'],
                    'to_village_id'   => $move['from_village_id'],
                    'type'            => 'return',
                    'troops_json'     => json_encode($survivors),
                    'loot_json'       => json_encode($loot),
                    'started_at'      => $now,
                    'arrives_at'      => $return_at,
                    'status'          => 'in_progress',
                ]);
                // Send report to attacker
                $from_vil = db()->fetch("SELECT player_id, name FROM villages WHERE id = ?", [$move['from_village_id']]);
                $to_vil   = db()->fetch("SELECT player_id, name FROM villages WHERE id = ?", [$move['to_village_id']]);
                $loot_total = $loot['wood'] + $loot['clay'] + $loot['iron'] + $loot['crop'];
                db()->insert('reports', [
                    'player_id' => $from_vil['player_id'],
                    'title'     => 'Victory at ' . $to_vil['name'],
                    'body'      => "Your attack on " . $to_vil['name'] . " was victorious!\n\nTribe: " . ucfirst($tribe) . " (loot multiplier: " . ($loot_mult * 100) . "%)\nLoot capacity: $max_loot\nLooted: Wood=" . $loot['wood'] . " Clay=" . $loot['clay'] . " Iron=" . $loot['iron'] . " Crop=" . $loot['crop'] . " (total: $loot_total)",
                    'category'  => 'combat',
                ]);
                if ($to_vil['player_id'] != $from_vil['player_id']) {
                    db()->insert('reports', [
                        'player_id' => $to_vil['player_id'],
                        'title'     => 'Defeat at ' . $to_vil['name'],
                        'body'      => "Your village " . $to_vil['name'] . " was attacked and lost. All defending troops perished.\n\nLost: " . json_encode($loot),
                        'category'  => 'combat',
                    ]);
                }
            } else {
                // Defender wins — all attackers die
                // Remove all attacker troops (they were already removed when movement started)
                // Defender keeps 50%
                foreach ($defender_troops as $dt) {
                    $survivors = (int)ceil($dt['count'] * 0.5);
                    db()->query("UPDATE troops SET count = ? WHERE id = ?", [$survivors, $dt['id']]);
                }
                $from_vil = db()->fetch("SELECT player_id, name FROM villages WHERE id = ?", [$move['from_village_id']]);
                $to_vil   = db()->fetch("SELECT player_id, name FROM villages WHERE id = ?", [$move['to_village_id']]);
                db()->insert('reports', [
                    'player_id' => $from_vil['player_id'],
                    'title'     => 'Defeat at ' . $to_vil['name'],
                    'body'      => "Your attack on " . $to_vil['name'] . " failed. All attacking troops perished.",
                    'category'  => 'combat',
                ]);
                if ($to_vil['player_id'] != $from_vil['player_id']) {
                    db()->insert('reports', [
                        'player_id' => $to_vil['player_id'],
                        'title'     => 'Defense of ' . $to_vil['name'],
                        'body'      => "Your village " . $to_vil['name'] . " was attacked but you defended successfully. 50% of troops survived.",
                        'category'  => 'combat',
                    ]);
                }
            }
        } elseif ($move['type'] === 'reinforcement') {
            // Add troops to target village
            foreach ($troops as $type => $n) {
                $existing = db()->fetch(
                    "SELECT id, count FROM troops WHERE village_id = ? AND unit_type = ?",
                    [$move['to_village_id'], $type]
                );
                if ($existing) {
                    db()->query("UPDATE troops SET count = count + ? WHERE id = ?", [$n, $existing['id']]);
                } else {
                    db()->insert('troops', [
                        'village_id' => $move['to_village_id'],
                        'unit_type'  => $type,
                        'count'      => $n,
                    ]);
                }
            }
        } elseif ($move['type'] === 'return') {
            // Troops come home; add loot to source village
            $loot = json_decode($move['loot_json'] ?? '{}', true) ?: [];
            $res = update_resources($move['to_village_id']);
            db()->update('resources', [
                'wood' => $res['wood'] + ($loot['wood'] ?? 0),
                'clay' => $res['clay'] + ($loot['clay'] ?? 0),
                'iron' => $res['iron'] + ($loot['iron'] ?? 0),
                'crop' => $res['crop'] + ($loot['crop'] ?? 0),
            ], 'village_id = :wv', ['wv' => $move['to_village_id']]);
            // Add troops back
            foreach ($troops as $type => $n) {
                $existing = db()->fetch(
                    "SELECT id, count FROM troops WHERE village_id = ? AND unit_type = ?",
                    [$move['to_village_id'], $type]
                );
                if ($existing) {
                    db()->query("UPDATE troops SET count = count + ? WHERE id = ?", [$n, $existing['id']]);
                } else {
                    db()->insert('troops', [
                        'village_id' => $move['to_village_id'],
                        'unit_type'  => $type,
                        'count'      => $n,
                    ]);
                }
            }
        }
        // Mark movement as completed
        db()->query("UPDATE movements SET status = 'completed' WHERE id = ?", [$move['id']]);
    }
}

function find_unit_stats($unit_type) {
    global $UNITS;
    foreach ($UNITS as $tribe => $units) {
        if (isset($units[$unit_type])) return $units[$unit_type];
    }
    return ['attack' => 0, 'def_inf' => 0, 'def_cav' => 0, 'speed' => 6];
}

// Send a movement (attack or reinforcement) from one village to another.
function send_movement($from_village_id, $to_x, $to_y, $type, $troops_to_send) {
    global $UNITS, $UNIT_TRAIN_TIME;

    // Find target village
    $target = db()->fetch("SELECT * FROM villages WHERE x = ? AND y = ?", [$to_x, $to_y]);
    if (!$target) return ['ok' => false, 'error' => 'No village at those coordinates'];

    // Validate troops and calculate speed (slowest unit)
    $source = db()->fetch("SELECT * FROM villages WHERE id = ?", [$from_village_id]);
    $player = db()->fetch("SELECT * FROM players WHERE id = ?", [$source['player_id']]);
    $tribe = $player['tribe'];

    $slowest_speed = PHP_INT_MAX;
    $troops_json = [];
    $total_troops = 0;
    foreach ($troops_to_send as $type => $n) {
        $n = (int)$n;
        if ($n <= 0) continue;
        $stats = find_unit_stats($type);
        if (!$stats) return ['ok' => false, 'error' => 'Unknown unit: ' . $type];
        // Check we have this many
        $have = db()->fetch(
            "SELECT count FROM troops WHERE village_id = ? AND unit_type = ?",
            [$from_village_id, $type]
        );
        if (!$have || $have['count'] < $n) {
            return ['ok' => false, 'error' => 'Not enough ' . $type . ' (have ' . ($have['count'] ?? 0) . ', want ' . $n . ')'];
        }
        $slowest_speed = min($slowest_speed, $stats['speed']);
        $troops_json[$type] = $n;
        $total_troops += $n;
    }
    if ($total_troops === 0) return ['ok' => false, 'error' => 'No troops selected'];

    // Deduct troops from source village
    foreach ($troops_json as $type => $n) {
        db()->query(
            "UPDATE troops SET count = count - ? WHERE village_id = ? AND unit_type = ?",
            [$n, $from_village_id, $type]
        );
        // Delete rows with 0 count to keep table clean
        db()->query("DELETE FROM troops WHERE count <= 0");
    }

    // Calculate travel time
    $dist = distance_between($source['x'], $source['y'], $to_x, $to_y);
    $travel = movement_time_seconds($dist, $slowest_speed);

    $now_ts = time();
    $started = date('Y-m-d H:i:s', $now_ts);
    $arrives = date('Y-m-d H:i:s', $now_ts + $travel);

    db()->insert('movements', [
        'from_village_id' => $from_village_id,
        'to_village_id'   => $target['id'],
        'type'            => $type,  // 'attack' or 'reinforcement'
        'troops_json'     => json_encode($troops_json),
        'loot_json'       => '{}',
        'started_at'      => $started,
        'arrives_at'      => $arrives,
        'status'          => 'in_progress',
    ]);

    return ['ok' => true, 'arrives_at' => $arrives];
}

// ============================================================
// RESOURCE MOVEMENTS (Marketplace trades)
// ============================================================

function get_resource_movements($village_id) {
    $outgoing = db()->fetchAll(
        "SELECT rm.*, v.name AS target_name, p.username AS target_player
         FROM resource_movements rm
         JOIN villages v ON v.id = rm.to_village_id
         JOIN players p ON p.id = v.player_id
         WHERE rm.from_village_id = ? AND rm.status = 'in_progress'
         ORDER BY rm.arrives_at ASC",
        [$village_id]
    );
    $incoming = db()->fetchAll(
        "SELECT rm.*, v.name AS source_name, p.username AS source_player
         FROM resource_movements rm
         JOIN villages v ON v.id = rm.from_village_id
         JOIN players p ON p.id = v.player_id
         WHERE rm.to_village_id = ? AND rm.status = 'in_progress'
         ORDER BY rm.arrives_at ASC",
        [$village_id]
    );
    return ['outgoing' => $outgoing, 'incoming' => $incoming];
}

function process_resource_movements($village_id) {
    $now = date('Y-m-d H:i:s');
    $arrived = db()->fetchAll(
        "SELECT * FROM resource_movements
         WHERE (from_village_id = ? OR to_village_id = ?)
         AND arrives_at <= ? AND status = 'in_progress'
         ORDER BY arrives_at ASC",
        [$village_id, $village_id, $now]
    );
    foreach ($arrived as $ship) {
        // Add resources to target village
        $res = update_resources($ship['to_village_id']);
        db()->update('resources', [
            'wood' => $res['wood'] + $ship['wood'],
            'clay' => $res['clay'] + $ship['clay'],
            'iron' => $res['iron'] + $ship['iron'],
            'crop' => $res['crop'] + $ship['crop'],
        ], 'village_id = :wv', ['wv' => $ship['to_village_id']]);
        db()->query("UPDATE resource_movements SET status = 'completed' WHERE id = ?", [$ship['id']]);
    }
}

// Send resources from one village to another via marketplace.
// Returns ['ok' => true] or ['ok' => false, 'error' => '...']
function send_resources($from_village_id, $to_village_id, $wood, $clay, $iron, $crop) {
    global $MARKETPLACE_MERCHANTS_PER_LEVEL, $MARKETPLACE_MERCHANT_CAPACITY;

    // Find marketplace level in source village
    $buildings = get_buildings($from_village_id);
    $market_level = 0;
    foreach ($buildings as $b) {
        if ($b['building_type'] === 'marketplace') $market_level = max($market_level, (int)$b['level']);
    }
    if ($market_level < 1) {
        return ['ok' => false, 'error' => 'You need a Marketplace to send resources.'];
    }

    $wood = max(0, (int)$wood);
    $clay = max(0, (int)$clay);
    $iron = max(0, (int)$iron);
    $crop = max(0, (int)$crop);
    $total = $wood + $clay + $iron + $crop;
    if ($total <= 0) {
        return ['ok' => false, 'error' => 'No resources selected to send.'];
    }

    // Check merchant capacity
    $merchants_have = merchants_available($market_level);
    // Also subtract merchants currently on the road
    $merchants_in_use = (int)db()->fetchColumn(
        "SELECT COALESCE(SUM(merchants_used), 0) FROM resource_movements
         WHERE from_village_id = ? AND status = 'in_progress'",
        [$from_village_id]
    );
    $merchants_free = $merchants_have - $merchants_in_use;
    $capacity = merchant_total_capacity($merchants_free);
    if ($total > $capacity) {
        return ['ok' => false, 'error' => "Not enough merchant capacity. Need to send $total, can carry $capacity (free merchants: $merchants_free)."];
    }
    $merchants_needed = (int)ceil($total / $MARKETPLACE_MERCHANT_CAPACITY);
    if ($merchants_needed > $merchants_free) {
        return ['ok' => false, 'error' => "Not enough free merchants (need $merchants_needed, have $merchants_free free)."];
    }

    // Check resources available
    $res = update_resources($from_village_id);
    if ($res['wood'] < $wood || $res['clay'] < $clay || $res['iron'] < $iron || $res['crop'] < $crop) {
        return ['ok' => false, 'error' => 'Not enough resources in source village.'];
    }

    // Deduct from source
    db()->update('resources', [
        'wood' => max(0, $res['wood'] - $wood),
        'clay' => max(0, $res['clay'] - $clay),
        'iron' => max(0, $res['iron'] - $iron),
        'crop' => max(0, $res['crop'] - $crop),
    ], 'village_id = :wv', ['wv' => $from_village_id]);

    // Calculate travel time (merchants travel at 1 field/hour by default, modified by server speed)
    $from = db()->fetch("SELECT * FROM villages WHERE id = ?", [$from_village_id]);
    $to   = db()->fetch("SELECT * FROM villages WHERE id = ?", [$to_village_id]);
    if (!$to) return ['ok' => false, 'error' => 'Target village not found.'];

    $dist = distance_between($from['x'], $from['y'], $to['x'], $to['y']);
    if ($dist == 0) $dist = 1;  // same village edge case
    // Merchants travel at 12 fields/hour base (Travian default)
    $travel = movement_time_seconds($dist, 12);

    $now_ts = time();
    $started = date('Y-m-d H:i:s', $now_ts);
    $arrives = date('Y-m-d H:i:s', $now_ts + $travel);

    db()->insert('resource_movements', [
        'from_village_id' => $from_village_id,
        'to_village_id'   => $to_village_id,
        'wood'            => $wood,
        'clay'            => $clay,
        'iron'            => $iron,
        'crop'            => $crop,
        'merchants_used'  => $merchants_needed,
        'started_at'      => $started,
        'arrives_at'      => $arrives,
        'status'          => 'in_progress',
    ]);

    return ['ok' => true, 'arrives_at' => $arrives, 'merchants_used' => $merchants_needed];
}
